# Discord Public Moderasyon Botu

Bu proje **discord.js v18** kullanılarak geliştirilmiş,  
**public sunucular** için tasarlanmış **gelişmiş moderasyon botudur**.

Bot, **hem Slash (`/`) hem de Prefix (`.`)** komutlarını destekler  
ve **Modal / Button / SelectMenu** tabanlı modern Discord etkileşimlerini kullanır.

---

## 🚀 Özellikler

### 🔒 Moderasyon
- Ban / Unban
- Mute / Unmute
- Jail sistemi
- Otomatik ceza logları
- Yetkili işlem takibi

### 🛡️ Güvenlik & Otomod
- Reklam engelleyici
- Küfür / kelime filtresi
- Yeni hesap tespiti
- Anti-spam
- Anti-raid
- Tag / kelime kontrolü

### 👋 Sunucu Sistemleri
- Hoşgeldin sistemi (etiket + gif)
- Otomatik rol verme
- Invite tracker
- Seviye (level) sistemi
- Level’e göre rol verme

### 🛂 Yetkili Başvuru Sistemi (Gelişmiş)
- Butonlu başvuru paneli
- **Modal form** ile başvuru
- Otomatik ön eleme:
  - Hesap yaşı
  - Level
  - Ceza geçmişi
- Kabul / Red / Beklet butonları
- Red sebebi için ayrı modal
- Başvuru geçmişi ve log sistemi

---

## 🧠 Komut Sistemi

Bot **hybrid komut sistemi** kullanır:

- `/ban`
- `.ban`

Tüm komutlar **tek execute()** fonksiyonuyla çalışır.

---

## 📁 Proje Yapısı

src/
├─ commands/
├─ events/
├─ handlers/
├─ systems/
├─ interactions/
│ ├─ buttons/
│ ├─ modals/
│ └─ selects/
├─ models/
├─ utils/
├─ config/
└─ index.js