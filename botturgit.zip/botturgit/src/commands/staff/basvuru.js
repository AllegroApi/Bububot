const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const embedUtil = require('../../utils/embed');
const config = require('../../config/config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('basvuru')
        .setDescription('Yetkili başvuru sistemi')
        .addSubcommand(subcommand =>
            subcommand
                .setName('panel')
                .setDescription('Başvuru panelini gönder'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('bilgi')
                .setDescription('Başvuru sistemi bilgisi'))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    name: 'basvuru',
    description: 'Yetkili başvuru sistemi',

    async executeSlash(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'panel') {
            const embed = embedUtil.panel('basvuru');
            
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('basvuru_ac')
                        .setLabel('📝 Başvuru Yap')
                        .setStyle(ButtonStyle.Success)
                );

            await interaction.channel.send({ embeds: [embed], components: [row] });
            await interaction.reply({ content: '✅ Başvuru paneli gönderildi!', flags: 64 });

        } else if (subcommand === 'bilgi') {
            const embed = embedUtil.info('Başvuru Sistemi', 
                `**Durum:** ${config.staffApplication?.enabled ? '✅ Aktif' : '❌ Devre Dışı'}\n` +
                `**Başvuru Kanalı:** <#${config.staffApplication?.channelId || 'Ayarlanmamış'}>\n` +
                `**İnceleme Kanalı:** <#${config.staffApplication?.reviewChannelId || 'Ayarlanmamış'}>`
            );
            await interaction.reply({ embeds: [embed], flags: 64 });
        }
    },

    async executePrefix(message, args, client) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply({ embeds: [embedUtil.error('Yetki Hatası', 'Bu komutu kullanmak için yönetici yetkisi gerekli!')] });
        }

        const subcommand = args[0]?.toLowerCase();

        if (subcommand === 'panel') {
            const embed = embedUtil.panel('basvuru');
            
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('basvuru_ac')
                        .setLabel('📝 Başvuru Yap')
                        .setStyle(ButtonStyle.Success)
                );

            await message.channel.send({ embeds: [embed], components: [row] });
            await message.reply('✅ Başvuru paneli gönderildi!');
        } else {
            await message.reply('Kullanım: `.basvuru panel`');
        }
    }
};
