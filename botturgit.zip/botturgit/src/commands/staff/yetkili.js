const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const embedUtil = require('../../utils/embed');
const ApplicationModel = require('../../models/Application');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('yetkili')
        .setDescription('Yetkili yönetim komutları')
        .addSubcommand(subcommand =>
            subcommand
                .setName('listele')
                .setDescription('Bekleyen başvuruları listele'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('istatistik')
                .setDescription('Başvuru istatistiklerini göster'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    name: 'yetkili',
    description: 'Yetkili yönetim komutları',

    async executeSlash(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'listele') {
            await interaction.deferReply({ flags: 64 });

            const pendingApps = ApplicationModel.getByStatus('pending');
            
            if (pendingApps.length === 0) {
                return interaction.editReply({
                    embeds: [embedUtil.info('Başvurular', '📭 Bekleyen başvuru bulunmuyor.')]
                });
            }

            const embed = new EmbedBuilder()
                .setTitle('📋 Bekleyen Başvurular')
                .setColor('#5865F2')
                .setDescription(pendingApps.slice(0, 10).map((app, i) => 
                    `**${i + 1}.** <@${app.userId}> - ${new Date(app.createdAt).toLocaleDateString('tr-TR')}`
                ).join('\n'))
                .setFooter({ text: `Toplam ${pendingApps.length} bekleyen başvuru` });

            await interaction.editReply({ embeds: [embed] });

        } else if (subcommand === 'istatistik') {
            const allApps = ApplicationModel.getAll();
            const pending = allApps.filter(a => a.status === 'pending').length;
            const approved = allApps.filter(a => a.status === 'approved').length;
            const rejected = allApps.filter(a => a.status === 'rejected').length;

            const embed = embedUtil.info('Başvuru İstatistikleri',
                `📊 **Toplam Başvuru:** ${allApps.length}\n\n` +
                `⏳ **Bekleyen:** ${pending}\n` +
                `✅ **Onaylanan:** ${approved}\n` +
                `❌ **Reddedilen:** ${rejected}`
            );

            await interaction.reply({ embeds: [embed], flags: 64 });
        }
    },

    async executePrefix(message, args, client) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.reply({ embeds: [embedUtil.error('Yetki Hatası', 'Bu komutu kullanmak için yetkiniz yok!')] });
        }

        const subcommand = args[0]?.toLowerCase();

        if (subcommand === 'listele') {
            const pendingApps = ApplicationModel.getByStatus('pending');
            
            if (pendingApps.length === 0) {
                return message.reply({ embeds: [embedUtil.info('Başvurular', '📭 Bekleyen başvuru bulunmuyor.')] });
            }

            const embed = new EmbedBuilder()
                .setTitle('📋 Bekleyen Başvurular')
                .setColor('#5865F2')
                .setDescription(pendingApps.slice(0, 10).map((app, i) => 
                    `**${i + 1}.** <@${app.userId}> - ${new Date(app.createdAt).toLocaleDateString('tr-TR')}`
                ).join('\n'))
                .setFooter({ text: `Toplam ${pendingApps.length} bekleyen başvuru` });

            await message.reply({ embeds: [embed] });

        } else if (subcommand === 'istatistik') {
            const allApps = ApplicationModel.getAll();
            const pending = allApps.filter(a => a.status === 'pending').length;
            const approved = allApps.filter(a => a.status === 'approved').length;
            const rejected = allApps.filter(a => a.status === 'rejected').length;

            const embed = embedUtil.info('Başvuru İstatistikleri',
                `📊 **Toplam Başvuru:** ${allApps.length}\n\n` +
                `⏳ **Bekleyen:** ${pending}\n` +
                `✅ **Onaylanan:** ${approved}\n` +
                `❌ **Reddedilen:** ${rejected}`
            );

            await message.reply({ embeds: [embed] });
        } else {
            await message.reply('Kullanım: `.yetkili listele` veya `.yetkili istatistik`');
        }
    }
};
