const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const musicSystem = require('../../systems/musicSystem');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('müzik')
        .setDescription('Müzik komutları')
        .addSubcommand(sub =>
            sub.setName('çal')
                .setDescription('Şarkı çal veya kuyruğa ekle')
                .addStringOption(opt =>
                    opt.setName('şarkı')
                        .setDescription('Şarkı adı veya YouTube linki')
                        .setRequired(true)
                )
        )
        .addSubcommand(sub =>
            sub.setName('ara')
                .setDescription('YouTube\'da şarkı ara')
                .addStringOption(opt =>
                    opt.setName('sorgu')
                        .setDescription('Aranacak şarkı')
                        .setRequired(true)
                )
        )
        .addSubcommand(sub =>
            sub.setName('geç')
                .setDescription('Şu anki şarkıyı geç')
        )
        .addSubcommand(sub =>
            sub.setName('durdur')
                .setDescription('Müziği duraklat')
        )
        .addSubcommand(sub =>
            sub.setName('devam')
                .setDescription('Müziği devam ettir')
        )
        .addSubcommand(sub =>
            sub.setName('kuyruk')
                .setDescription('Şarkı kuyruğunu göster')
        )
        .addSubcommand(sub =>
            sub.setName('ses')
                .setDescription('Ses seviyesini ayarla')
                .addIntegerOption(opt =>
                    opt.setName('seviye')
                        .setDescription('Ses seviyesi (1-100)')
                        .setRequired(true)
                        .setMinValue(1)
                        .setMaxValue(100)
                )
        )
        .addSubcommand(sub =>
            sub.setName('karıştır')
                .setDescription('Kuyruğu karıştır')
        )
        .addSubcommand(sub =>
            sub.setName('tekrar')
                .setDescription('Tekrar modunu değiştir')
                .addStringOption(opt =>
                    opt.setName('mod')
                        .setDescription('Tekrar modu')
                        .setRequired(true)
                        .addChoices(
                            { name: '🔂 Tek Şarkı', value: 'single' },
                            { name: '🔁 Kuyruk', value: 'queue' },
                            { name: '▶️ Kapalı', value: 'off' }
                        )
                )
        )
        .addSubcommand(sub =>
            sub.setName('temizle')
                .setDescription('Kuyruğu temizle')
        )
        .addSubcommand(sub =>
            sub.setName('çıkış')
                .setDescription('Ses kanalından çık')
        )
        .addSubcommand(sub =>
            sub.setName('şimdi')
                .setDescription('Şu an çalan şarkıyı göster')
        ),

    name: 'müzik',
    aliases: ['m', 'music', 'play', 'p', 'çal', 'skip', 'geç', 'stop', 'dur', 'queue', 'kuyruk', 'leave', 'çık'],
    description: 'Müzik sistemi',

    async executeSlash(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'çal':
                await this.play(interaction, client, false);
                break;
            case 'ara':
                await this.search(interaction, client, false);
                break;
            case 'geç':
                await this.skip(interaction, client, false);
                break;
            case 'durdur':
                await this.pause(interaction, client, false);
                break;
            case 'devam':
                await this.resume(interaction, client, false);
                break;
            case 'kuyruk':
                await this.queue(interaction, client, false);
                break;
            case 'ses':
                await this.volume(interaction, client, false);
                break;
            case 'karıştır':
                await this.shuffle(interaction, client, false);
                break;
            case 'tekrar':
                await this.loop(interaction, client, false);
                break;
            case 'temizle':
                await this.clear(interaction, client, false);
                break;
            case 'çıkış':
                await this.leave(interaction, client, false);
                break;
            case 'şimdi':
                await this.nowPlaying(interaction, client, false);
                break;
        }
    },

    async executePrefix(message, args, client) {
        const cmd = args[0]?.toLowerCase();
        const query = args.slice(1).join(' ');

        // Alias handling
        const commandName = message.content.split(' ')[0].slice(1).toLowerCase();
        
        if (['play', 'p', 'çal'].includes(commandName) || cmd === 'çal') {
            const searchQuery = ['play', 'p', 'çal'].includes(commandName) ? args.join(' ') : query;
            return this.play(message, client, true, searchQuery);
        }

        if (['skip', 'geç', 's'].includes(commandName) || cmd === 'geç') {
            return this.skip(message, client, true);
        }

        if (['stop', 'dur', 'durdur'].includes(commandName) || cmd === 'durdur') {
            return this.pause(message, client, true);
        }

        if (['queue', 'kuyruk', 'q'].includes(commandName) || cmd === 'kuyruk') {
            return this.queue(message, client, true);
        }

        if (['leave', 'çık', 'çıkış', 'dc'].includes(commandName) || cmd === 'çıkış') {
            return this.leave(message, client, true);
        }

        // Alt komutlar için
        switch (cmd) {
            case 'çal':
                await this.play(message, client, true, query);
                break;
            case 'ara':
                await this.search(message, client, true, query);
                break;
            case 'geç':
                await this.skip(message, client, true);
                break;
            case 'durdur':
                await this.pause(message, client, true);
                break;
            case 'devam':
                await this.resume(message, client, true);
                break;
            case 'kuyruk':
                await this.queue(message, client, true);
                break;
            case 'ses':
                await this.volume(message, client, true, parseInt(query));
                break;
            case 'karıştır':
                await this.shuffle(message, client, true);
                break;
            case 'temizle':
                await this.clear(message, client, true);
                break;
            case 'çıkış':
                await this.leave(message, client, true);
                break;
            case 'şimdi':
                await this.nowPlaying(message, client, true);
                break;
            default:
                // Varsayılan: çal
                if (args.length > 0) {
                    await this.play(message, client, true, args.join(' '));
                } else {
                    const helpEmbed = new EmbedBuilder()
                        .setColor('#FF0000')
                        .setTitle('🎵 Müzik Komutları')
                        .setDescription(
                            '`.müzik çal <şarkı>` - Şarkı çal\n' +
                            '`.müzik ara <sorgu>` - Şarkı ara\n' +
                            '`.müzik geç` - Şarkıyı geç\n' +
                            '`.müzik durdur` - Duraklat\n' +
                            '`.müzik devam` - Devam et\n' +
                            '`.müzik kuyruk` - Kuyruğu göster\n' +
                            '`.müzik ses <1-100>` - Ses ayarla\n' +
                            '`.müzik karıştır` - Karıştır\n' +
                            '`.müzik temizle` - Kuyruğu temizle\n' +
                            '`.müzik çıkış` - Kanaldan çık\n\n' +
                            '**Kısayollar:**\n' +
                            '`.çal <şarkı>` `.geç` `.kuyruk` `.çık`'
                        );
                    message.reply({ embeds: [helpEmbed] });
                }
        }
    },

    // Şarkı çal
    async play(ctx, client, isPrefix, prefixQuery = null) {
        const query = isPrefix ? prefixQuery : ctx.options.getString('şarkı');
        const member = isPrefix ? ctx.member : ctx.member;
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const channel = isPrefix ? ctx.channel : ctx.channel;

        // Ses kanalı kontrolü
        const voiceChannel = member.voice.channel;
        if (!voiceChannel) {
            const msg = '❌ Önce bir ses kanalına katılmalısın!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        // Bot izinleri
        const permissions = voiceChannel.permissionsFor(client.user);
        if (!permissions.has('Connect') || !permissions.has('Speak')) {
            const msg = '❌ Ses kanalına bağlanma veya konuşma yetkim yok!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        if (!query) {
            const msg = '❌ Bir şarkı adı veya link girmelisin!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        // Defer reply
        if (!isPrefix) {
            await ctx.deferReply();
        }

        try {
            // Şarkı bilgisi al
            const songInfo = await musicSystem.getSongInfo(query);

            if (!songInfo) {
                const msg = '❌ Şarkı bulunamadı!';
                return isPrefix ? ctx.reply(msg) : ctx.editReply(msg);
            }

            // Kuyruk al veya bağlan
            let queue = musicSystem.getQueue(guild.id);
            
            if (!queue.connection) {
                queue = await musicSystem.connect(voiceChannel, channel);
            }

            // Playlist mi?
            if (Array.isArray(songInfo)) {
                // Playlist
                const playlistName = songInfo[0]?.playlistName || 'Playlist';
                
                for (const song of songInfo) {
                    queue.addSong({
                        ...song,
                        requestedBy: isPrefix ? ctx.author.id : ctx.user.id
                    });
                }

                const embed = new EmbedBuilder()
                    .setColor('#57F287')
                    .setTitle('📋 Playlist Eklendi!')
                    .setDescription(`**${playlistName}**\n\n✅ **${songInfo.length}** şarkı kuyruğa eklendi!`)
                    .setTimestamp();

                if (isPrefix) {
                    ctx.reply({ embeds: [embed] });
                } else {
                    ctx.editReply({ embeds: [embed] });
                }

                // Çalmıyorsa başlat
                if (!queue.playing) {
                    queue.processQueue();
                }

            } else {
                // Tek şarkı
                const song = {
                    ...songInfo,
                    requestedBy: isPrefix ? ctx.author.id : ctx.user.id
                };

                queue.addSong(song);

                const embed = new EmbedBuilder()
                    .setColor('#57F287')
                    .setAuthor({ name: '✅ Kuyruğa Eklendi' })
                    .setTitle(song.title)
                    .setURL(song.url)
                    .setThumbnail(song.thumbnail)
                    .addFields(
                        { name: '⏱️ Süre', value: song.duration || 'Bilinmiyor', inline: true },
                        { name: '📺 Kanal', value: song.channel, inline: true },
                        { name: '📋 Sıra', value: `#${queue.songs.length}`, inline: true }
                    )
                    .setTimestamp();

                if (isPrefix) {
                    ctx.reply({ embeds: [embed] });
                } else {
                    ctx.editReply({ embeds: [embed] });
                }

                // Çalmıyorsa başlat
                if (!queue.playing) {
                    queue.processQueue();
                }
            }

        } catch (error) {
            console.error('Play hatası:', error);
            const msg = '❌ Şarkı çalınırken bir hata oluştu!';
            isPrefix ? ctx.reply(msg) : ctx.editReply(msg);
        }
    },

    // Arama
    async search(ctx, client, isPrefix, prefixQuery = null) {
        const query = isPrefix ? prefixQuery : ctx.options.getString('sorgu');
        const member = isPrefix ? ctx.member : ctx.member;
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const channel = isPrefix ? ctx.channel : ctx.channel;

        if (!member.voice.channel) {
            const msg = '❌ Önce bir ses kanalına katılmalısın!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        if (!query) {
            const msg = '❌ Aranacak şarkıyı yazmalısın!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        if (!isPrefix) await ctx.deferReply();

        try {
            const results = await musicSystem.search(query, 10);

            if (results.length === 0) {
                const msg = '❌ Sonuç bulunamadı!';
                return isPrefix ? ctx.reply(msg) : ctx.editReply(msg);
            }

            // URL'leri JSON olarak sakla
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('music_search')
                .setPlaceholder('🎵 Şarkı seç...')
                .addOptions(
                    results.slice(0, 10).map((song, i) => ({
                        label: song.title.substring(0, 100),
                        description: `${song.channel} • ${song.duration}`.substring(0, 100),
                        value: `${i}`, // Index olarak sakla
                        emoji: ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'][i]
                    }))
                );

            const row = new ActionRowBuilder().addComponents(selectMenu);

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle(`🔍 "${query}" için sonuçlar`)
                .setDescription(
                    results.slice(0, 10).map((song, i) => 
                        `**${i + 1}.** [${song.title}](${song.url})\n> ${song.channel} • \`${song.duration}\``
                    ).join('\n\n')
                )
                .setFooter({ text: 'Aşağıdan şarkı seç!' });

            let response;
            if (isPrefix) {
                response = await ctx.reply({ embeds: [embed], components: [row] });
            } else {
                response = await ctx.editReply({ embeds: [embed], components: [row] });
            }

            // Collector
            const collector = response.createMessageComponentCollector({
                filter: i => i.user.id === (isPrefix ? ctx.author.id : ctx.user.id),
                time: 60000
            });

            collector.on('collect', async i => {
                const selectedIndex = parseInt(i.values[0]);
                const selectedSong = results[selectedIndex];
                try {
                    await i.deferUpdate();
                } catch (e) {}

                // Zorunlu url kontrolü ve debug
                const url = typeof selectedSong.url === 'string' ? selectedSong.url : '';
                console.log('Seçilen şarkı:', selectedSong);
                if (!selectedSong || !url || !url.startsWith('http')) {
                    try {
                        return await channel.send({ content: '❌ Şarkı bulunamadı veya URL hatalı!' });
                    } catch (e) {}
                    return;
                }

                let queue = musicSystem.getQueue(guild.id);
                const voiceChannel = member.voice.channel;
                if (!voiceChannel) {
                    try {
                        return await channel.send({ content: '❌ Ses kanalından ayrıldın!' });
                    } catch (e) {}
                    return;
                }
                if (!queue.connection) {
                    queue = await musicSystem.connect(voiceChannel, channel);
                }

                const song = {
                    title: selectedSong.title,
                    url,
                    duration: selectedSong.duration,
                    thumbnail: selectedSong.thumbnail,
                    channel: selectedSong.channel,
                    requestedBy: isPrefix ? ctx.author.id : ctx.user.id
                };
                queue.addSong(song);

                const addedEmbed = new EmbedBuilder()
                    .setColor('#57F287')
                    .setAuthor({ name: '✅ Kuyruğa Eklendi' })
                    .setTitle(song.title)
                    .setURL(song.url)
                    .setThumbnail(song.thumbnail)
                    .addFields(
                        { name: '⏱️ Süre', value: song.duration || 'Bilinmiyor', inline: true },
                        { name: '📺 Kanal', value: song.channel || 'Bilinmiyor', inline: true },
                        { name: '📋 Sıra', value: `#${queue.songs.length}`, inline: true }
                    )
                    .setTimestamp();
                try {
                    await channel.send({ embeds: [addedEmbed] });
                } catch (e) {}
                if (!queue.playing) {
                    queue.processQueue();
                }
                collector.stop();
            });

            collector.on('end', async (collected, reason) => {
                if (reason === 'time') {
                    try {
                        await response.edit({ components: [] });
                    } catch (e) {}
                }
            });

        } catch (error) {
            console.error('Search hatası:', error);
            const msg = '❌ Arama yapılırken hata oluştu!';
            isPrefix ? ctx.reply(msg) : ctx.editReply(msg);
        }
    },

    // Geç
    async skip(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const member = isPrefix ? ctx.member : ctx.member;

        if (!member.voice.channel) {
            const msg = '❌ Ses kanalında değilsin!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const queue = musicSystem.getQueue(guild.id);
        
        if (!queue.playing) {
            const msg = '❌ Şu anda çalan bir şarkı yok!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const skipped = queue.currentSong;
        queue.skip();

        const embed = new EmbedBuilder()
            .setColor('#FFA500')
            .setDescription(`⏭️ **${skipped?.title || 'Şarkı'}** geçildi!`);

        isPrefix ? ctx.reply({ embeds: [embed] }) : ctx.reply({ embeds: [embed] });
    },

    // Duraklat
    async pause(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const member = isPrefix ? ctx.member : ctx.member;

        if (!member.voice.channel) {
            const msg = '❌ Ses kanalında değilsin!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const queue = musicSystem.getQueue(guild.id);
        
        if (!queue.playing) {
            const msg = '❌ Şu anda çalan bir şarkı yok!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        queue.pause();

        const embed = new EmbedBuilder()
            .setColor('#FEE75C')
            .setDescription('⏸️ Müzik duraklatıldı!');

        isPrefix ? ctx.reply({ embeds: [embed] }) : ctx.reply({ embeds: [embed] });
    },

    // Devam
    async resume(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const member = isPrefix ? ctx.member : ctx.member;

        if (!member.voice.channel) {
            const msg = '❌ Ses kanalında değilsin!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const queue = musicSystem.getQueue(guild.id);
        queue.resume();

        const embed = new EmbedBuilder()
            .setColor('#57F287')
            .setDescription('▶️ Müzik devam ediyor!');

        isPrefix ? ctx.reply({ embeds: [embed] }) : ctx.reply({ embeds: [embed] });
    },

    // Kuyruk
    async queue(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const queue = musicSystem.getQueue(guild.id);

        if (!queue.playing && queue.songs.length === 0) {
            const msg = '📋 Kuyruk boş!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const songs = queue.songs.slice(0, 10);
        const current = queue.currentSong;

        let description = '';
        
        if (current) {
            description += `**🎵 Şimdi Çalıyor:**\n[${current.title}](${current.url})\n> İsteyen: <@${current.requestedBy}>\n\n`;
        }

        if (songs.length > 0) {
            description += '**📋 Sıradakiler:**\n';
            description += songs.map((song, i) => 
                `**${i + 1}.** [${song.title}](${song.url})\n> \`${song.duration}\` • <@${song.requestedBy}>`
            ).join('\n\n');
        }

        if (queue.songs.length > 10) {
            description += `\n\n*...ve ${queue.songs.length - 10} şarkı daha*`;
        }

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle(`🎶 Şarkı Kuyruğu (${queue.songs.length} şarkı)`)
            .setDescription(description || 'Kuyruk boş!')
            .addFields(
                { name: '🔊 Ses', value: `${queue.volume}%`, inline: true },
                { name: '🔁 Tekrar', value: queue.loop ? '🔂 Tek' : (queue.loopQueue ? '🔁 Kuyruk' : '❌ Kapalı'), inline: true }
            )
            .setTimestamp();

        isPrefix ? ctx.reply({ embeds: [embed] }) : ctx.reply({ embeds: [embed] });
    },

    // Ses
    async volume(ctx, client, isPrefix, prefixVol = null) {
        const volume = isPrefix ? prefixVol : ctx.options.getInteger('seviye');
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const member = isPrefix ? ctx.member : ctx.member;

        if (!member.voice.channel) {
            const msg = '❌ Ses kanalında değilsin!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        if (!volume || volume < 1 || volume > 100) {
            const msg = '❌ Ses seviyesi 1-100 arasında olmalı!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const queue = musicSystem.getQueue(guild.id);
        queue.setVolume(volume);

        const volumeBar = '█'.repeat(Math.floor(volume / 10)) + '░'.repeat(10 - Math.floor(volume / 10));

        const embed = new EmbedBuilder()
            .setColor('#57F287')
            .setDescription(`🔊 Ses seviyesi: **${volume}%**\n\`${volumeBar}\``);

        isPrefix ? ctx.reply({ embeds: [embed] }) : ctx.reply({ embeds: [embed] });
    },

    // Karıştır
    async shuffle(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const member = isPrefix ? ctx.member : ctx.member;

        if (!member.voice.channel) {
            const msg = '❌ Ses kanalında değilsin!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const queue = musicSystem.getQueue(guild.id);
        
        if (queue.songs.length < 2) {
            const msg = '❌ Karıştırmak için en az 2 şarkı olmalı!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        queue.shuffle();

        const embed = new EmbedBuilder()
            .setColor('#57F287')
            .setDescription(`🔀 **${queue.songs.length}** şarkı karıştırıldı!`);

        isPrefix ? ctx.reply({ embeds: [embed] }) : ctx.reply({ embeds: [embed] });
    },

    // Loop
    async loop(ctx, client, isPrefix) {
        const mode = isPrefix ? null : ctx.options.getString('mod');
        const guild = isPrefix ? ctx.guild : ctx.guild;
        
        const queue = musicSystem.getQueue(guild.id);

        if (!isPrefix) {
            switch (mode) {
                case 'single':
                    queue.loop = true;
                    queue.loopQueue = false;
                    break;
                case 'queue':
                    queue.loop = false;
                    queue.loopQueue = true;
                    break;
                case 'off':
                    queue.loop = false;
                    queue.loopQueue = false;
                    break;
            }
        } else {
            // Toggle
            if (!queue.loop && !queue.loopQueue) {
                queue.loop = true;
            } else if (queue.loop) {
                queue.loop = false;
                queue.loopQueue = true;
            } else {
                queue.loopQueue = false;
            }
        }

        const status = queue.loop ? '🔂 Tek şarkı tekrarı açık' : 
                       (queue.loopQueue ? '🔁 Kuyruk tekrarı açık' : '▶️ Tekrar kapalı');

        const embed = new EmbedBuilder()
            .setColor('#57F287')
            .setDescription(status);

        isPrefix ? ctx.reply({ embeds: [embed] }) : ctx.reply({ embeds: [embed] });
    },

    // Temizle
    async clear(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const member = isPrefix ? ctx.member : ctx.member;

        if (!member.voice.channel) {
            const msg = '❌ Ses kanalında değilsin!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const queue = musicSystem.getQueue(guild.id);
        const count = queue.songs.length;
        queue.clear();

        const embed = new EmbedBuilder()
            .setColor('#ED4245')
            .setDescription(`🗑️ **${count}** şarkı kuyruktan silindi!`);

        isPrefix ? ctx.reply({ embeds: [embed] }) : ctx.reply({ embeds: [embed] });
    },

    // Çıkış
    async leave(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const member = isPrefix ? ctx.member : ctx.member;

        if (!member.voice.channel) {
            const msg = '❌ Ses kanalında değilsin!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        musicSystem.deleteQueue(guild.id);

        const embed = new EmbedBuilder()
            .setColor('#ED4245')
            .setDescription('👋 Ses kanalından ayrıldım!');

        isPrefix ? ctx.reply({ embeds: [embed] }) : ctx.reply({ embeds: [embed] });
    },

    // Şimdi çalan
    async nowPlaying(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const queue = musicSystem.getQueue(guild.id);

        if (!queue.currentSong) {
            const msg = '❌ Şu anda çalan bir şarkı yok!';
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const song = queue.currentSong;

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setAuthor({ name: '🎵 Şimdi Çalıyor' })
            .setTitle(song.title)
            .setURL(song.url)
            .setThumbnail(song.thumbnail)
            .addFields(
                { name: '📺 Kanal', value: song.channel || 'Bilinmiyor', inline: true },
                { name: '⏱️ Süre', value: song.duration || 'Bilinmiyor', inline: true },
                { name: '👤 İsteyen', value: `<@${song.requestedBy}>`, inline: true },
                { name: '🔊 Ses', value: `${queue.volume}%`, inline: true },
                { name: '🔁 Tekrar', value: queue.loop ? '🔂 Tek' : (queue.loopQueue ? '🔁 Kuyruk' : '❌'), inline: true },
                { name: '📋 Sırada', value: `${queue.songs.length} şarkı`, inline: true }
            )
            .setTimestamp();

        // Kontrol butonları
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('music_pause')
                .setEmoji('⏸️')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('music_skip')
                .setEmoji('⏭️')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('music_stop')
                .setEmoji('⏹️')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('music_queue')
                .setEmoji('📋')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('music_loop')
                .setEmoji('🔁')
                .setStyle(ButtonStyle.Secondary)
        );

        isPrefix ? ctx.reply({ embeds: [embed], components: [row] }) : ctx.reply({ embeds: [embed], components: [row] });
    }
};
