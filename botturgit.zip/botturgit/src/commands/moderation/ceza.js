const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const PunishmentModel = require('../../models/Punishment');
const embedUtil = require('../../utils/embed');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ceza')
        .setDescription('Ceza geçmişi komutları')
        .addSubcommand(subcommand =>
            subcommand
                .setName('sorgula')
                .setDescription('Kullanıcının ceza geçmişini sorgula')
                .addUserOption(option =>
                    option.setName('kullanici')
                        .setDescription('Sorgulanacak kullanıcı')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('son')
                .setDescription('Kullanıcının son cezasını göster')
                .addUserOption(option =>
                    option.setName('kullanici')
                        .setDescription('Kullanıcı')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('tur')
                        .setDescription('Ceza türü')
                        .setRequired(false)
                        .addChoices(
                            { name: 'Mute', value: 'mute' },
                            { name: 'Ban', value: 'ban' },
                            { name: 'Kick', value: 'kick' },
                            { name: 'Warn', value: 'warn' },
                            { name: 'Jail', value: 'jail' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('istatistik')
                .setDescription('Sunucu ceza istatistiklerini göster'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    name: 'cezasorgula',
    aliases: ['ceza', 'sicil', 'cezasebebi'],
    description: 'Kullanıcının ceza geçmişini sorgula',

    async executeSlash(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'sorgula') {
            const user = interaction.options.getUser('kullanici');
            const punishments = PunishmentModel.getAll(user.id);
            const stats = PunishmentModel.getStats(user.id);

            if (punishments.length === 0) {
                return interaction.reply({
                    embeds: [embedUtil.success('Temiz Sicil', `${user.tag} kullanıcısının hiç ceza kaydı yok! 🎉`)],
                    ephemeral: true
                });
            }

            // Son 10 cezayı göster
            const recentPunishments = punishments
                .sort((a, b) => b.timestamp - a.timestamp)
                .slice(0, 10);

            const punishmentList = recentPunishments.map((p, i) => {
                const emoji = getTypeEmoji(p.type);
                const date = `<t:${Math.floor(p.timestamp / 1000)}:d>`;
                const status = p.active ? '🔴 Aktif' : '🟢 Bitti';
                return `**${i + 1}.** ${emoji} **${p.type.toUpperCase()}** - ${date}\n└ Sebep: ${p.reason}\n└ Yetkili: ${p.moderatorTag}\n└ Durum: ${status}`;
            }).join('\n\n');

            const embed = embedUtil.create({
                color: '#ED4245',
                title: `⚖️ ${user.tag} - Ceza Geçmişi`,
                thumbnail: user.displayAvatarURL({ dynamic: true }),
                description: punishmentList,
                fields: [
                    { name: '📊 Toplam', value: `**${stats.total}**`, inline: true },
                    { name: '🔇 Mute', value: `**${stats.mutes}**`, inline: true },
                    { name: '🔨 Ban', value: `**${stats.bans}**`, inline: true },
                    { name: '👢 Kick', value: `**${stats.kicks}**`, inline: true },
                    { name: '⚠️ Warn', value: `**${stats.warns}**`, inline: true },
                    { name: '🔒 Jail', value: `**${stats.jails}**`, inline: true }
                ],
                footer: `Aktif Ceza: ${stats.active}`
            });

            await interaction.reply({ embeds: [embed], ephemeral: true });

        } else if (subcommand === 'son') {
            const user = interaction.options.getUser('kullanici');
            const type = interaction.options.getString('tur');

            const lastPunishment = PunishmentModel.getLast(user.id, type);

            if (!lastPunishment) {
                return interaction.reply({
                    embeds: [embedUtil.info('Bilgi', `${user.tag} kullanıcısının ${type ? type + ' cezası' : 'ceza kaydı'} yok.`)],
                    ephemeral: true
                });
            }

            const embed = embedUtil.create({
                color: '#ED4245',
                title: `${getTypeEmoji(lastPunishment.type)} Son ${lastPunishment.type.toUpperCase()} Cezası`,
                thumbnail: user.displayAvatarURL({ dynamic: true }),
                fields: [
                    { name: '👤 Kullanıcı', value: user.tag, inline: true },
                    { name: '👮 Yetkili', value: lastPunishment.moderatorTag, inline: true },
                    { name: '📅 Tarih', value: `<t:${Math.floor(lastPunishment.timestamp / 1000)}:F>`, inline: false },
                    { name: '📝 Sebep', value: lastPunishment.reason, inline: false },
                    { name: '📊 Durum', value: lastPunishment.active ? '🔴 Aktif' : '🟢 Bitti', inline: true }
                ],
                footer: `Ceza ID: ${lastPunishment.id}`
            });

            if (lastPunishment.expiresAt) {
                embed.addFields({ 
                    name: '⏰ Bitiş', 
                    value: `<t:${Math.floor(lastPunishment.expiresAt / 1000)}:R>`, 
                    inline: true 
                });
            }

            await interaction.reply({ embeds: [embed], ephemeral: true });

        } else if (subcommand === 'istatistik') {
            const stats = PunishmentModel.getGlobalStats();

            const embed = embedUtil.create({
                color: '#5865F2',
                title: '📊 Sunucu Ceza İstatistikleri',
                fields: [
                    { name: '📋 Toplam Ceza', value: `**${stats.totalPunishments}**`, inline: true },
                    { name: '👥 Cezalı Kullanıcı', value: `**${stats.totalUsers}**`, inline: true },
                    { name: '\u200b', value: '\u200b', inline: true },
                    { name: '🔇 Mute', value: `**${stats.byType.mute}**`, inline: true },
                    { name: '🔨 Ban', value: `**${stats.byType.ban}**`, inline: true },
                    { name: '👢 Kick', value: `**${stats.byType.kick}**`, inline: true },
                    { name: '⚠️ Warn', value: `**${stats.byType.warn}**`, inline: true },
                    { name: '🔒 Jail', value: `**${stats.byType.jail}**`, inline: true }
                ],
                footer: 'Sunucu moderasyon istatistikleri'
            });

            await interaction.reply({ embeds: [embed] });
        }
    },

    async executePrefix(message, args, client) {
        if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            return message.reply({
                embeds: [embedUtil.error('Yetki Hatası', 'Bu komutu kullanmak için yetkiniz yok!')]
            });
        }

        const user = message.mentions.users.first();
        
        if (!user) {
            // İstatistik göster
            const stats = PunishmentModel.getGlobalStats();
            
            const embed = embedUtil.create({
                color: '#5865F2',
                title: '📊 Sunucu Ceza İstatistikleri',
                description: `Kullanım: \`.cezasorgula @kullanıcı\``,
                fields: [
                    { name: '📋 Toplam Ceza', value: `**${stats.totalPunishments}**`, inline: true },
                    { name: '👥 Cezalı Kullanıcı', value: `**${stats.totalUsers}**`, inline: true }
                ]
            });
            
            return message.reply({ embeds: [embed] });
        }

        const punishments = PunishmentModel.getAll(user.id);
        const stats = PunishmentModel.getStats(user.id);

        if (punishments.length === 0) {
            return message.reply({
                embeds: [embedUtil.success('Temiz Sicil', `${user.tag} kullanıcısının hiç ceza kaydı yok! 🎉`)]
            });
        }

        const recentPunishments = punishments
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, 5);

        const punishmentList = recentPunishments.map((p, i) => {
            const emoji = getTypeEmoji(p.type);
            const date = `<t:${Math.floor(p.timestamp / 1000)}:d>`;
            return `**${i + 1}.** ${emoji} **${p.type}** - ${p.reason} (${date})`;
        }).join('\n');

        const embed = embedUtil.create({
            color: '#ED4245',
            title: `⚖️ ${user.tag} - Ceza Geçmişi`,
            thumbnail: user.displayAvatarURL({ dynamic: true }),
            description: punishmentList,
            fields: [
                { name: '📊 Toplam', value: `${stats.total}`, inline: true },
                { name: '🔴 Aktif', value: `${stats.active}`, inline: true }
            ]
        });

        await message.reply({ embeds: [embed] });
    }
};

function getTypeEmoji(type) {
    const emojis = {
        mute: '🔇',
        ban: '🔨',
        kick: '👢',
        warn: '⚠️',
        jail: '🔒'
    };
    return emojis[type] || '📋';
}
