const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("unmute")
    .setDescription("Belirtilen üyenin susturmasını kaldırır")
    .addUserOption(option =>
      option.setName("kullanıcı")
        .setDescription("Susturması kaldırılacak kullanıcı")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("sebep")
        .setDescription("Unmute sebebi")
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  name: "unmute",
  aliases: ["susturmakaldır", "untimeout"],
  description: "Kullanıcının susturmasını kaldırır",

  MUTE_HAMMER_ID: "1454080866719371348",
  MUTED_ROLE_ID: "1454082850029699094",
  LOG_CHANNEL_ID: "1454080629795721359",

  async executeSlash(interaction, client) {
    const user = interaction.options.getUser("kullanıcı");
    const sebep = interaction.options.getString("sebep") || "Belirtilmemiş";
    const member = interaction.guild.members.cache.get(user.id);

    // Yetki kontrolü
    if (!interaction.member.roles.cache.has(this.MUTE_HAMMER_ID) && !interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ content: "❌ Bu komutu kullanmak için yetkin yok.", flags: 64 });
    }

    if (!member) return interaction.reply({ content: "❌ Kullanıcı bulunamadı.", flags: 64 });

    // Mute durumu kontrol
    if (!member.isCommunicationDisabled() && !member.roles.cache.has(this.MUTED_ROLE_ID)) {
      return interaction.reply({ content: "❌ Bu kullanıcı zaten susturulmuş değil!", flags: 64 });
    }

    try {
      // Discord timeout kaldır
      await member.timeout(null, `${sebep} | Yetkili: ${interaction.user.tag}`);
      
      // Muted rolü kaldır
      await member.roles.remove(this.MUTED_ROLE_ID).catch(() => {});

      // DM gönder
      const dmEmbed = new EmbedBuilder()
        .setColor('#57F287')
        .setTitle('🔊 Susturmanız Kaldırıldı!')
        .setDescription(`**${interaction.guild.name}** sunucusunda susturmanız kaldırıldı.`)
        .addFields(
          { name: '📝 Sebep', value: sebep, inline: true },
          { name: '👮 Yetkili', value: interaction.user.tag, inline: true }
        )
        .setTimestamp();

      await user.send({ embeds: [dmEmbed] }).catch(() => {});

      // Log embed
      const logEmbed = new EmbedBuilder()
        .setColor('#57F287')
        .setAuthor({ name: 'Moderasyon Sistemi', iconURL: interaction.guild.iconURL() })
        .setTitle('🔊 Susturma Kaldırıldı')
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Kullanıcı', value: `${user} (${user.tag})`, inline: true },
          { name: '👮 Yetkili', value: `${interaction.user}`, inline: true },
          { name: '📝 Sebep', value: sebep, inline: false },
          { name: '🕐 Tarih', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: true }
        )
        .setFooter({ text: `ID: ${user.id}` })
        .setTimestamp();

      const logChannel = interaction.guild.channels.cache.get(this.LOG_CHANNEL_ID);
      if (logChannel) logChannel.send({ embeds: [logEmbed] });

      // Başarılı embed
      const successEmbed = new EmbedBuilder()
        .setColor('#57F287')
        .setDescription(`🔊 **${user.tag}** artık konuşabilir!\n📝 **Sebep:** ${sebep}`)
        .setTimestamp();

      await interaction.reply({ embeds: [successEmbed] });

    } catch (err) {
      console.error('Unmute hatası:', err);
      interaction.reply({ content: "❌ Unmute işlemi başarısız.", flags: 64 });
    }
  },

  async executePrefix(message, args, client) {
    const user = message.mentions.users.first();
    const sebep = args.slice(1).join(" ") || "Belirtilmemiş";
    const member = message.guild.members.cache.get(user?.id);

    if (!message.member.roles.cache.has(this.MUTE_HAMMER_ID) && !message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    if (!user) return message.reply("❌ Bir kullanıcı etiketle!");
    if (!member) return message.reply("❌ Kullanıcı bulunamadı.");

    if (!member.isCommunicationDisabled() && !member.roles.cache.has(this.MUTED_ROLE_ID)) {
      return message.reply("❌ Bu kullanıcı zaten susturulmuş değil!");
    }

    try {
      await member.timeout(null, `${sebep} | Yetkili: ${message.author.tag}`);
      await member.roles.remove(this.MUTED_ROLE_ID).catch(() => {});

      // DM
      const dmEmbed = new EmbedBuilder()
        .setColor('#57F287')
        .setTitle('🔊 Susturmanız Kaldırıldı!')
        .setDescription(`**${message.guild.name}** sunucusunda susturmanız kaldırıldı.`)
        .addFields(
          { name: '📝 Sebep', value: sebep, inline: true },
          { name: '👮 Yetkili', value: message.author.tag, inline: true }
        )
        .setTimestamp();

      await user.send({ embeds: [dmEmbed] }).catch(() => {});

      // Log
      const logChannel = message.guild.channels.cache.get(this.LOG_CHANNEL_ID);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setColor('#57F287')
          .setAuthor({ name: 'Moderasyon Sistemi', iconURL: message.guild.iconURL() })
          .setTitle('🔊 Susturma Kaldırıldı')
          .setThumbnail(user.displayAvatarURL({ dynamic: true }))
          .addFields(
            { name: '👤 Kullanıcı', value: `${user}`, inline: true },
            { name: '👮 Yetkili', value: `${message.author}`, inline: true },
            { name: '📝 Sebep', value: sebep, inline: false }
          )
          .setTimestamp();
        logChannel.send({ embeds: [logEmbed] });
      }

      const successEmbed = new EmbedBuilder()
        .setColor('#57F287')
        .setDescription(`🔊 **${user.tag}** artık konuşabilir!`)
        .setTimestamp();

      message.reply({ embeds: [successEmbed] });

    } catch (err) {
      console.error('Unmute hatası:', err);
      message.reply("❌ Unmute işlemi başarısız.");
    }
  }
};
