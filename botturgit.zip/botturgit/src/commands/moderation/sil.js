const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("sil")
    .setDescription("Belirtilen sayıda mesaj siler")
    .addIntegerOption(option =>
      option.setName("miktar")
        .setDescription("Silinecek mesaj sayısı (1-100)")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100))
    .addUserOption(option =>
      option.setName("kullanıcı")
        .setDescription("Sadece bu kullanıcının mesajlarını sil")
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  name: "sil",
  aliases: ["temizle", "purge", "clear"],
  description: "Mesaj siler",

  LOG_CHANNEL_ID: "1454080629795721359",

  async executeSlash(interaction, client) {
    const miktar = interaction.options.getInteger("miktar");
    const targetUser = interaction.options.getUser("kullanıcı");

    await interaction.deferReply({ flags: 64 });

    try {
      let messages = await interaction.channel.messages.fetch({ limit: 100 });
      
      // Kullanıcı filtresi
      if (targetUser) {
        messages = messages.filter(m => m.author.id === targetUser.id);
      }

      // 14 günden eski mesajları filtrele
      const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
      messages = messages.filter(m => m.createdTimestamp > twoWeeksAgo);

      // Miktar kadar al
      messages = Array.from(messages.values()).slice(0, miktar);

      if (messages.length === 0) {
        return interaction.editReply({ content: "❌ Silinecek mesaj bulunamadı!" });
      }

      const deleted = await interaction.channel.bulkDelete(messages, true);

      // Başarılı embed
      const embed = new EmbedBuilder()
        .setColor('#57F287')
        .setDescription(
          `🗑️ **${deleted.size}** mesaj başarıyla silindi!` +
          (targetUser ? `\n👤 Kullanıcı: ${targetUser}` : '')
        )
        .setFooter({ text: `Yetkili: ${interaction.user.tag}` })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });

      // Log
      const logChannel = interaction.guild.channels.cache.get(this.LOG_CHANNEL_ID);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setColor('#FFA500')
          .setAuthor({ name: 'Moderasyon Sistemi', iconURL: interaction.guild.iconURL() })
          .setTitle('🗑️ Toplu Mesaj Silme')
          .addFields(
            { name: '👮 Yetkili', value: `${interaction.user}`, inline: true },
            { name: '📍 Kanal', value: `${interaction.channel}`, inline: true },
            { name: '📊 Miktar', value: `${deleted.size} mesaj`, inline: true }
          )
          .setTimestamp();

        if (targetUser) {
          logEmbed.addFields({ name: '👤 Hedef', value: `${targetUser}`, inline: true });
        }

        logChannel.send({ embeds: [logEmbed] });
      }

    } catch (err) {
      console.error('Sil hatası:', err);
      interaction.editReply({ content: "❌ Mesajlar silinirken bir hata oluştu!" });
    }
  },

  async executePrefix(message, args, client) {
    const miktar = parseInt(args[0]);
    if (isNaN(miktar) || miktar < 1 || miktar > 100) {
      return message.reply("❌ 1 ile 100 arasında bir sayı giriniz.");
    }

    const targetUser = message.mentions.users.first();

    try {
      let messages = await message.channel.messages.fetch({ limit: 100 });
      
      if (targetUser) {
        messages = messages.filter(m => m.author.id === targetUser.id);
      }

      const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
      messages = messages.filter(m => m.createdTimestamp > twoWeeksAgo);
      messages = Array.from(messages.values()).slice(0, miktar + 1);

      const deleted = await message.channel.bulkDelete(messages, true);

      const embed = new EmbedBuilder()
        .setColor('#57F287')
        .setDescription(`🗑️ **${deleted.size - 1}** mesaj silindi!`)
        .setTimestamp();

      message.channel.send({ embeds: [embed] }).then(m => {
        setTimeout(() => m.delete().catch(() => {}), 5000);
      });

    } catch (err) {
      console.error('Sil hatası:', err);
      message.reply("❌ Mesajlar silinirken bir hata oluştu!");
    }
  }
};
