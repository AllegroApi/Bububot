const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const PunishmentModel = require("../../models/Punishment");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kullanıcıyı sunucudan atar")
    .addUserOption(option =>
      option.setName("kullanıcı")
            .setDescription("Atılacak kişi")
            .setRequired(true)
    )
    .addStringOption(option =>
      option.setName("sebep")
            .setDescription("Atılma sebebi")
            .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  name: "kick",
  aliases: ["at", "kickle"],
  description: "Kullanıcıyı sunucudan atar",

  KICK_HAMMER_ID: "1454080941843681512",
  LOG_CHANNEL_ID: "1454080629795721359",

  async executeSlash(interaction, client) {
    const user = interaction.options.getUser("kullanıcı");
    const reason = interaction.options.getString("sebep") || "Belirtilmedi";
    const member = interaction.guild.members.cache.get(user.id);

    // Yetki kontrolü
    if (!interaction.member.roles.cache.has(this.KICK_HAMMER_ID) && !interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) {
      return interaction.reply({ content: "❌ Bu komutu kullanmak için yetkin yok!", flags: 64 });
    }

    // Kendini atma
    if (user.id === interaction.user.id) {
      return interaction.reply({ content: "❌ Kendini atamazsın!", flags: 64 });
    }

    // Bot'u atma
    if (user.id === client.user.id) {
      return interaction.reply({ content: "❌ Beni atamazsın!", flags: 64 });
    }

    if (!member) {
      return interaction.reply({ content: "❌ Bu kullanıcı sunucuda değil!", flags: 64 });
    }

    // Hiyerarşi kontrolü
    if (member.roles.highest.position >= interaction.member.roles.highest.position) {
      return interaction.reply({ content: "❌ Bu kullanıcıyı atamazsın! (Rol hiyerarşisi)", flags: 64 });
    }

    try {
      // DM gönder
      const dmEmbed = new EmbedBuilder()
        .setColor('#FFA500')
        .setTitle('👢 Sunucudan Atıldınız!')
        .setDescription(`**${interaction.guild.name}** sunucusundan atıldınız.`)
        .addFields(
          { name: '📝 Sebep', value: reason, inline: true },
          { name: '👮 Yetkili', value: interaction.user.tag, inline: true }
        )
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setFooter({ text: 'Tekrar katılabilirsiniz!' })
        .setTimestamp();

      await user.send({ embeds: [dmEmbed] }).catch(() => {});

      // Kick
      await member.kick(`${reason} | Yetkili: ${interaction.user.tag}`);

      // Ceza kaydı
      PunishmentModel.add(user.id, {
        type: 'kick',
        reason: reason,
        moderatorId: interaction.user.id,
        moderatorTag: interaction.user.tag
      });

      // Log embed
      const logEmbed = new EmbedBuilder()
        .setColor('#FFA500')
        .setAuthor({ name: 'Moderasyon Sistemi', iconURL: interaction.guild.iconURL() })
        .setTitle('👢 Üye Atıldı')
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Kullanıcı', value: `${user} (${user.tag})`, inline: true },
          { name: '👮 Yetkili', value: `${interaction.user}`, inline: true },
          { name: '📝 Sebep', value: reason, inline: false },
          { name: '🕐 Tarih', value: `<t:${Math.floor(Date.now()/1000)}:F>`, inline: true }
        )
        .setFooter({ text: `ID: ${user.id}` })
        .setTimestamp();

      const logChannel = interaction.guild.channels.cache.get(this.LOG_CHANNEL_ID);
      if (logChannel) logChannel.send({ embeds: [logEmbed] });

      // Başarılı embed
      const successEmbed = new EmbedBuilder()
        .setColor('#57F287')
        .setDescription(`✅ **${user.tag}** başarıyla sunucudan atıldı!\n📝 **Sebep:** ${reason}`)
        .setTimestamp();

      await interaction.reply({ embeds: [successEmbed] });

    } catch (err) {
      console.error('Kick hatası:', err);
      interaction.reply({ content: "❌ Kullanıcı atılamadı!", flags: 64 });
    }
  },

  async executePrefix(message, args, client) {
    const user = message.mentions.users.first();
    const reason = args.slice(1).join(" ") || "Belirtilmedi";

    if (!message.member.roles.cache.has(this.KICK_HAMMER_ID) && !message.member.permissions.has(PermissionFlagsBits.KickMembers)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok!");
    }

    if (!user) return message.reply("❌ Bir kullanıcı etiketle!");

    const member = message.guild.members.cache.get(user.id);
    if (!member) return message.reply("❌ Bu kullanıcı sunucuda değil!");

    if (member.roles.highest.position >= message.member.roles.highest.position) {
      return message.reply("❌ Bu kullanıcıyı atamazsın! (Rol hiyerarşisi)");
    }

    try {
      // DM gönder
      const dmEmbed = new EmbedBuilder()
        .setColor('#FFA500')
        .setTitle('👢 Sunucudan Atıldınız!')
        .setDescription(`**${message.guild.name}** sunucusundan atıldınız.`)
        .addFields(
          { name: '📝 Sebep', value: reason, inline: true },
          { name: '👮 Yetkili', value: message.author.tag, inline: true }
        )
        .setTimestamp();

      await user.send({ embeds: [dmEmbed] }).catch(() => {});

      await member.kick(`${reason} | Yetkili: ${message.author.tag}`);

      // Ceza kaydı
      PunishmentModel.add(user.id, {
        type: 'kick',
        reason: reason,
        moderatorId: message.author.id,
        moderatorTag: message.author.tag
      });

      // Log
      const logChannel = message.guild.channels.cache.get(this.LOG_CHANNEL_ID);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setColor('#FFA500')
          .setAuthor({ name: 'Moderasyon Sistemi', iconURL: message.guild.iconURL() })
          .setTitle('👢 Üye Atıldı')
          .setThumbnail(user.displayAvatarURL({ dynamic: true }))
          .addFields(
            { name: '👤 Kullanıcı', value: `${user} (${user.tag})`, inline: true },
            { name: '👮 Yetkili', value: `${message.author}`, inline: true },
            { name: '📝 Sebep', value: reason, inline: false }
          )
          .setTimestamp();
        logChannel.send({ embeds: [logEmbed] });
      }

      const successEmbed = new EmbedBuilder()
        .setColor('#57F287')
        .setDescription(`✅ **${user.tag}** sunucudan atıldı!`)
        .setTimestamp();

      message.reply({ embeds: [successEmbed] });

    } catch (err) {
      console.error('Kick hatası:', err);
      message.reply("❌ Kullanıcı atılamadı!");
    }
  }
};
