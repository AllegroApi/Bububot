const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const PunishmentModel = require("../../models/Punishment");
const fs = require('fs');
const path = require('path');

// Jail verileri
const jailDataPath = path.join(__dirname, '../../data/jail.json');

function loadJailData() {
    try {
        if (fs.existsSync(jailDataPath)) {
            return JSON.parse(fs.readFileSync(jailDataPath, 'utf8'));
        }
    } catch (e) {}
    return {};
}

function saveJailData(data) {
    const dir = path.dirname(jailDataPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(jailDataPath, JSON.stringify(data, null, 2));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("jail")
        .setDescription("Kullanıcıyı hapse atar veya çıkarır")
        .addSubcommand(sub =>
            sub.setName("at")
                .setDescription("Kullanıcıyı hapse atar")
                .addUserOption(opt => opt.setName("kullanıcı").setDescription("Hapse atılacak kullanıcı").setRequired(true))
                .addStringOption(opt => opt.setName("sebep").setDescription("Hapise atılma sebebi").setRequired(false))
                .addStringOption(opt => opt.setName("süre").setDescription("Süre (örn: 1s, 30dk, 2d)").setRequired(false))
        )
        .addSubcommand(sub =>
            sub.setName("çıkar")
                .setDescription("Kullanıcıyı hapisten çıkarır")
                .addUserOption(opt => opt.setName("kullanıcı").setDescription("Hapisten çıkarılacak kullanıcı").setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName("liste")
                .setDescription("Hapisteki kullanıcıları listeler")
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    name: "jail",
    aliases: ["hapis", "cezaevi"],
    description: "Kullanıcıyı hapse atar",

    // Config
    JAIL_ROLE_ID: "JAIL_ROLE_ID", // Değiştir
    JAIL_CHANNEL_ID: "JAIL_CHANNEL_ID", // Değiştir
    LOG_CHANNEL_ID: "1454080629795721359",
    JAIL_HAMMER_ID: "1454080866719371348",

    async executeSlash(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === "at") {
            await this.jailUser(interaction, client, false);
        } else if (subcommand === "çıkar") {
            await this.unjailUser(interaction, client, false);
        } else if (subcommand === "liste") {
            await this.listJailed(interaction, client, false);
        }
    },

    async executePrefix(message, args, client) {
        if (!args[0]) {
            return message.reply("❌ Kullanım: `.jail at @kullanıcı [sebep]` veya `.jail çıkar @kullanıcı`");
        }

        const subcommand = args[0].toLowerCase();

        if (subcommand === "at") {
            const user = message.mentions.users.first();
            const sebep = args.slice(2).join(" ") || "Belirtilmemiş";
            if (!user) return message.reply("❌ Bir kullanıcı etiketle!");
            await this.jailUser(message, client, true, user, sebep);
        } else if (subcommand === "çıkar") {
            const user = message.mentions.users.first();
            if (!user) return message.reply("❌ Bir kullanıcı etiketle!");
            await this.unjailUser(message, client, true, user);
        } else if (subcommand === "liste") {
            await this.listJailed(message, client, true);
        }
    },

    async jailUser(ctx, client, isPrefix, prefixUser = null, prefixSebep = null) {
        const user = isPrefix ? prefixUser : ctx.options.getUser("kullanıcı");
        const sebep = isPrefix ? prefixSebep : (ctx.options.getString("sebep") || "Belirtilmemiş");
        const süreStr = isPrefix ? null : ctx.options.getString("süre");
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const moderator = isPrefix ? ctx.author : ctx.user;
        const member = guild.members.cache.get(user.id);

        // Yetki kontrolü
        const memberToCheck = isPrefix ? ctx.member : ctx.member;
        if (!memberToCheck.roles.cache.has(this.JAIL_HAMMER_ID) && !memberToCheck.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            const msg = "❌ Bu komutu kullanmak için yetkin yok!";
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        if (!member) {
            const msg = "❌ Kullanıcı bulunamadı!";
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        // Süre hesaplama
        let duration = null;
        if (süreStr) {
            duration = this.parseDuration(süreStr);
        }

        try {
            // Mevcut rolleri kaydet
            const jailData = loadJailData();
            const previousRoles = member.roles.cache
                .filter(r => r.id !== guild.id && r.id !== this.JAIL_ROLE_ID)
                .map(r => r.id);

            jailData[user.id] = {
                moderatorId: moderator.id,
                reason: sebep,
                previousRoles: previousRoles,
                jailedAt: Date.now(),
                expiresAt: duration ? Date.now() + duration : null
            };
            saveJailData(jailData);

            // Rolleri kaldır ve jail rolü ver
            await member.roles.set([this.JAIL_ROLE_ID]).catch(() => {});

            // Ceza kaydı
            PunishmentModel.add(user.id, {
                type: 'jail',
                reason: sebep,
                moderatorId: moderator.id,
                moderatorTag: moderator.tag,
                duration: duration,
                active: true
            });

            // Log embed
            const embed = new EmbedBuilder()
                .setColor('#8B0000')
                .setAuthor({ name: 'Hapis Sistemi', iconURL: guild.iconURL() })
                .setTitle('⛓️ Kullanıcı Hapse Atıldı')
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .addFields(
                    { name: '👤 Kullanıcı', value: `${user} (${user.tag})`, inline: true },
                    { name: '👮 Yetkili', value: `${moderator}`, inline: true },
                    { name: '📝 Sebep', value: sebep, inline: false },
                    { name: '⏰ Süre', value: duration ? this.formatDuration(duration) : 'Süresiz', inline: true },
                    { name: '🕐 Tarih', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                )
                .setFooter({ text: `ID: ${user.id}` })
                .setTimestamp();

            // Log gönder
            const logChannel = guild.channels.cache.get(this.LOG_CHANNEL_ID);
            if (logChannel) logChannel.send({ embeds: [embed] });

            // Jail kanalına mesaj
            const jailChannel = guild.channels.cache.get(this.JAIL_CHANNEL_ID);
            if (jailChannel) {
                const jailEmbed = new EmbedBuilder()
                    .setColor('#8B0000')
                    .setDescription(`⛓️ ${user} hapse atıldı!\n\n**Sebep:** ${sebep}\n**Süre:** ${duration ? this.formatDuration(duration) : 'Süresiz'}`)
                    .setTimestamp();
                jailChannel.send({ embeds: [jailEmbed] });
            }

            // Otomatik çıkarma
            if (duration) {
                setTimeout(() => this.autoUnjail(guild, user.id, client), duration);
            }

            const successMsg = `✅ ${user.tag} hapse atıldı!`;
            if (isPrefix) {
                ctx.reply({ embeds: [embed] });
            } else {
                ctx.reply({ content: successMsg, flags: 64 });
            }

        } catch (err) {
            console.error('Jail hatası:', err);
            const errMsg = "❌ Hapis işlemi başarısız!";
            isPrefix ? ctx.reply(errMsg) : ctx.reply({ content: errMsg, flags: 64 });
        }
    },

    async unjailUser(ctx, client, isPrefix, prefixUser = null) {
        const user = isPrefix ? prefixUser : ctx.options.getUser("kullanıcı");
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const moderator = isPrefix ? ctx.author : ctx.user;
        const member = guild.members.cache.get(user.id);

        // Yetki kontrolü
        const memberToCheck = isPrefix ? ctx.member : ctx.member;
        if (!memberToCheck.roles.cache.has(this.JAIL_HAMMER_ID) && !memberToCheck.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            const msg = "❌ Bu komutu kullanmak için yetkin yok!";
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        if (!member) {
            const msg = "❌ Kullanıcı bulunamadı!";
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const jailData = loadJailData();
        if (!jailData[user.id]) {
            const msg = "❌ Bu kullanıcı hapiste değil!";
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        try {
            // Eski rolleri geri ver
            const previousRoles = jailData[user.id].previousRoles || [];
            await member.roles.set(previousRoles).catch(() => {});

            // Veriyi sil
            delete jailData[user.id];
            saveJailData(jailData);

            // Log embed
            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setAuthor({ name: 'Hapis Sistemi', iconURL: guild.iconURL() })
                .setTitle('🔓 Kullanıcı Hapisten Çıkarıldı')
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .addFields(
                    { name: '👤 Kullanıcı', value: `${user} (${user.tag})`, inline: true },
                    { name: '👮 Yetkili', value: `${moderator}`, inline: true },
                    { name: '🕐 Tarih', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                )
                .setFooter({ text: `ID: ${user.id}` })
                .setTimestamp();

            // Log gönder
            const logChannel = guild.channels.cache.get(this.LOG_CHANNEL_ID);
            if (logChannel) logChannel.send({ embeds: [embed] });

            const successMsg = `✅ ${user.tag} hapisten çıkarıldı!`;
            if (isPrefix) {
                ctx.reply({ embeds: [embed] });
            } else {
                ctx.reply({ content: successMsg, flags: 64 });
            }

        } catch (err) {
            console.error('Unjail hatası:', err);
            const errMsg = "❌ Hapisten çıkarma başarısız!";
            isPrefix ? ctx.reply(errMsg) : ctx.reply({ content: errMsg, flags: 64 });
        }
    },

    async listJailed(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const jailData = loadJailData();

        const jailedUsers = Object.entries(jailData);
        if (jailedUsers.length === 0) {
            const msg = "📋 Hapiste kimse yok!";
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const embed = new EmbedBuilder()
            .setColor('#8B0000')
            .setAuthor({ name: 'Hapis Sistemi', iconURL: guild.iconURL() })
            .setTitle('⛓️ Hapisteki Kullanıcılar')
            .setDescription(
                jailedUsers.map(([userId, data], index) => {
                    const timeLeft = data.expiresAt ? `<t:${Math.floor(data.expiresAt / 1000)}:R>` : 'Süresiz';
                    return `**${index + 1}.** <@${userId}>\n> 📝 ${data.reason}\n> ⏰ ${timeLeft}`;
                }).join('\n\n')
            )
            .setFooter({ text: `Toplam: ${jailedUsers.length} kişi` })
            .setTimestamp();

        isPrefix ? ctx.reply({ embeds: [embed] }) : ctx.reply({ embeds: [embed], flags: 64 });
    },

    async autoUnjail(guild, userId, client) {
        const jailData = loadJailData();
        if (!jailData[userId]) return;

        const member = guild.members.cache.get(userId);
        if (!member) {
            delete jailData[userId];
            saveJailData(jailData);
            return;
        }

        // Eski rolleri geri ver
        const previousRoles = jailData[userId].previousRoles || [];
        await member.roles.set(previousRoles).catch(() => {});

        // Veriyi sil
        delete jailData[userId];
        saveJailData(jailData);

        // Log
        const logChannel = guild.channels.cache.get(this.LOG_CHANNEL_ID);
        if (logChannel) {
            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('🔓 Hapis Süresi Doldu')
                .setDescription(`<@${userId}> hapisten otomatik olarak çıkarıldı.`)
                .setTimestamp();
            logChannel.send({ embeds: [embed] });
        }
    },

    parseDuration(str) {
        const match = str.match(/^(\d+)(s|dk|d|h|m|w)$/i);
        if (!match) return null;

        const num = parseInt(match[1]);
        const unit = match[2].toLowerCase();

        const multipliers = {
            's': 3600000,      // saat
            'h': 3600000,      // hour
            'dk': 60000,       // dakika
            'm': 60000,        // minute
            'd': 86400000,     // gün/day
            'w': 604800000     // hafta/week
        };

        return num * (multipliers[unit] || 60000);
    },

    formatDuration(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) return `${days} gün`;
        if (hours > 0) return `${hours} saat`;
        if (minutes > 0) return `${minutes} dakika`;
        return `${seconds} saniye`;
    }
};
