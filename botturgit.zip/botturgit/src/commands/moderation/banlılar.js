const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("banlılar")
    .setDescription("Sunucudaki banlı üyeleri gösterir")
    .addStringOption(opt =>
      opt.setName("ara")
        .setDescription("Kullanıcı adına göre ara")
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  name: "banlılar",
  aliases: ["banlist", "banlar"],
  description: "Banlı üyeleri listeler",

  async executeSlash(interaction, client) {
    const searchQuery = interaction.options.getString("ara");
    await this.showBanList(interaction, client, false, searchQuery);
  },

  async executePrefix(message, args, client) {
    const searchQuery = args.join(" ") || null;
    await this.showBanList(message, client, true, searchQuery);
  },

  async showBanList(ctx, client, isPrefix, searchQuery = null) {
    const guild = isPrefix ? ctx.guild : ctx.guild;
    const user = isPrefix ? ctx.author : ctx.user;

    try {
      let bans = await guild.bans.fetch();
      
      if (!bans.size) {
        const msg = "📋 Bu sunucuda banlı üye bulunmuyor!";
        return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
      }

      // Arama filtresi
      if (searchQuery) {
        bans = bans.filter(b => 
          b.user.tag.toLowerCase().includes(searchQuery.toLowerCase()) ||
          b.user.id.includes(searchQuery)
        );

        if (!bans.size) {
          const msg = `❌ "${searchQuery}" ile eşleşen banlı kullanıcı bulunamadı!`;
          return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }
      }

      // Sayfalama
      const bansArray = Array.from(bans.values());
      const itemsPerPage = 10;
      const totalPages = Math.ceil(bansArray.length / itemsPerPage);
      let currentPage = 0;

      const generateEmbed = (page) => {
        const start = page * itemsPerPage;
        const end = start + itemsPerPage;
        const pageBans = bansArray.slice(start, end);

        const embed = new EmbedBuilder()
          .setColor('#ED4245')
          .setAuthor({ name: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
          .setTitle('🚫 Banlı Üyeler')
          .setDescription(
            pageBans.map((b, i) => {
              const index = start + i + 1;
              const reason = b.reason ? (b.reason.length > 30 ? b.reason.substring(0, 30) + '...' : b.reason) : 'Belirtilmemiş';
              return `**${index}.** ${b.user.tag}\n> 📝 ${reason}\n> 🆔 \`${b.user.id}\``;
            }).join('\n\n')
          )
          .setFooter({ 
            text: `Sayfa ${page + 1}/${totalPages} • Toplam ${bansArray.length} ban`,
            iconURL: user.displayAvatarURL({ dynamic: true })
          })
          .setTimestamp();

        if (searchQuery) {
          embed.setDescription(`🔍 Arama: "${searchQuery}"\n\n` + embed.data.description);
        }

        return embed;
      };

      const generateButtons = (page) => {
        return new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('ban_first')
            .setEmoji('⏪')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(page === 0),
          new ButtonBuilder()
            .setCustomId('ban_prev')
            .setEmoji('◀️')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === 0),
          new ButtonBuilder()
            .setCustomId('ban_page')
            .setLabel(`${page + 1}/${totalPages}`)
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true),
          new ButtonBuilder()
            .setCustomId('ban_next')
            .setEmoji('▶️')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === totalPages - 1),
          new ButtonBuilder()
            .setCustomId('ban_last')
            .setEmoji('⏩')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(page === totalPages - 1)
        );
      };

      const embed = generateEmbed(currentPage);
      const components = totalPages > 1 ? [generateButtons(currentPage)] : [];

      let response;
      if (isPrefix) {
        response = await ctx.reply({ embeds: [embed], components });
      } else {
        response = await ctx.reply({ embeds: [embed], components, fetchReply: true });
      }

      if (totalPages <= 1) return;

      // Collector
      const collector = response.createMessageComponentCollector({
        filter: i => i.user.id === user.id,
        time: 120000
      });

      collector.on('collect', async i => {
        if (i.customId === 'ban_first') currentPage = 0;
        else if (i.customId === 'ban_prev') currentPage = Math.max(0, currentPage - 1);
        else if (i.customId === 'ban_next') currentPage = Math.min(totalPages - 1, currentPage + 1);
        else if (i.customId === 'ban_last') currentPage = totalPages - 1;

        await i.update({
          embeds: [generateEmbed(currentPage)],
          components: [generateButtons(currentPage)]
        });
      });

      collector.on('end', async () => {
        try {
          const disabledRow = new ActionRowBuilder().addComponents(
            ...generateButtons(currentPage).components.map(b => b.setDisabled(true))
          );
          await response.edit({ components: [disabledRow] });
        } catch (e) {}
      });

    } catch (err) {
      console.error('Banlılar hatası:', err);
      const errMsg = "❌ Banlılar listesi alınırken bir hata oluştu!";
      isPrefix ? ctx.reply(errMsg) : ctx.reply({ content: errMsg, flags: 64 });
    }
  }
};
