const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const PunishmentModel = require("../../models/Punishment");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("mute")
    .setDescription("Belirtilen üyeyi susturur")
    .addUserOption(option =>
      option.setName("kullanıcı")
        .setDescription("Susturulacak kullanıcı")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("süre")
        .setDescription("Susturma süresi (örn: 10m, 1h, 1d)")
        .setRequired(false))
    .addStringOption(option =>
      option.setName("sebep")
        .setDescription("Mute sebebi")
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  name: "mute",
  aliases: ["sustur", "timeout"],
  description: "Kullanıcıyı susturur",

  MUTE_HAMMER_ID: "1454080866719371348",
  MUTED_ROLE_ID: "1454082850029699094",
  LOG_CHANNEL_ID: "1454080629795721359",

  async executeSlash(interaction, client) {
    const user = interaction.options.getUser("kullanıcı");
    const süreStr = interaction.options.getString("süre");
    const sebep = interaction.options.getString("sebep") || "Belirtilmemiş";
    const member = interaction.guild.members.cache.get(user.id);

    // Yetki kontrolü
    if (!interaction.member.roles.cache.has(this.MUTE_HAMMER_ID) && !interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ content: "❌ Bu komutu kullanmak için yetkin yok.", flags: 64 });
    }

    if (!member) return interaction.reply({ content: "❌ Kullanıcı bulunamadı.", flags: 64 });

    // Kendini mute
    if (user.id === interaction.user.id) {
      return interaction.reply({ content: "❌ Kendini susturamazsın!", flags: 64 });
    }

    // Hiyerarşi
    if (member.roles.highest.position >= interaction.member.roles.highest.position) {
      return interaction.reply({ content: "❌ Bu kullanıcıyı susturamazsın! (Rol hiyerarşisi)", flags: 64 });
    }

    try {
      // Süre parse
      const duration = this.parseDuration(süreStr) || 600000; // Varsayılan 10 dakika
      const durationText = this.formatDuration(duration);

      // Discord timeout (daha modern)
      await member.timeout(duration, `${sebep} | Yetkili: ${interaction.user.tag}`);

      // Muted rol de ver (ekstra güvenlik)
      if (this.MUTED_ROLE_ID !== "1454082850029699094") {
        await member.roles.add(this.MUTED_ROLE_ID).catch(() => {});
      }

      // Ceza kaydı
      PunishmentModel.add(user.id, {
        type: 'mute',
        reason: sebep,
        duration: duration,
        moderatorId: interaction.user.id,
        moderatorTag: interaction.user.tag,
        active: true,
        expiresAt: Date.now() + duration
      });

      // DM gönder
      const dmEmbed = new EmbedBuilder()
        .setColor('#FEE75C')
        .setTitle('🔇 Susturuldunuz!')
        .setDescription(`**${interaction.guild.name}** sunucusunda susturuldunuz.`)
        .addFields(
          { name: '📝 Sebep', value: sebep, inline: true },
          { name: '⏰ Süre', value: durationText, inline: true },
          { name: '👮 Yetkili', value: interaction.user.tag, inline: true }
        )
        .setTimestamp();

      await user.send({ embeds: [dmEmbed] }).catch(() => {});

      // Log embed
      const logEmbed = new EmbedBuilder()
        .setColor('#FEE75C')
        .setAuthor({ name: 'Moderasyon Sistemi', iconURL: interaction.guild.iconURL() })
        .setTitle('🔇 Üye Susturuldu')
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Kullanıcı', value: `${user} (${user.tag})`, inline: true },
          { name: '👮 Yetkili', value: `${interaction.user}`, inline: true },
          { name: '📝 Sebep', value: sebep, inline: false },
          { name: '⏰ Süre', value: durationText, inline: true },
          { name: '🕐 Bitiş', value: `<t:${Math.floor((Date.now() + duration)/1000)}:R>`, inline: true }
        )
        .setFooter({ text: `ID: ${user.id}` })
        .setTimestamp();

      const logChannel = interaction.guild.channels.cache.get(this.LOG_CHANNEL_ID);
      if (logChannel) logChannel.send({ embeds: [logEmbed] });

      // Başarılı embed
      const successEmbed = new EmbedBuilder()
        .setColor('#57F287')
        .setDescription(`🔇 **${user.tag}** susturuldu!\n⏰ **Süre:** ${durationText}\n📝 **Sebep:** ${sebep}`)
        .setTimestamp();

      await interaction.reply({ embeds: [successEmbed] });

    } catch (err) {
      console.error('Mute hatası:', err);
      interaction.reply({ content: "❌ Mute işlemi başarısız.", flags: 64 });
    }
  },

  async executePrefix(message, args, client) {
    const user = message.mentions.users.first();
    if (!user) return message.reply("❌ Bir kullanıcı etiketle!");

    // Süre ve sebep parse
    let süreStr = args[1];
    let sebep = args.slice(2).join(" ") || "Belirtilmemiş";

    // Süre yoksa varsayılan
    if (süreStr && !this.parseDuration(süreStr)) {
      sebep = args.slice(1).join(" ") || "Belirtilmemiş";
      süreStr = null;
    }

    const member = message.guild.members.cache.get(user.id);

    if (!message.member.roles.cache.has(this.MUTE_HAMMER_ID) && !message.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    if (!member) return message.reply("❌ Kullanıcı bulunamadı.");

    if (member.roles.highest.position >= message.member.roles.highest.position) {
      return message.reply("❌ Bu kullanıcıyı susturamazsın! (Rol hiyerarşisi)");
    }

    try {
      const duration = this.parseDuration(süreStr) || 600000;
      const durationText = this.formatDuration(duration);

      await member.timeout(duration, `${sebep} | Yetkili: ${message.author.tag}`);

      // Ceza kaydı
      PunishmentModel.add(user.id, {
        type: 'mute',
        reason: sebep,
        duration: duration,
        moderatorId: message.author.id,
        moderatorTag: message.author.tag,
        active: true
      });

      // DM
      const dmEmbed = new EmbedBuilder()
        .setColor('#FEE75C')
        .setTitle('🔇 Susturuldunuz!')
        .setDescription(`**${message.guild.name}** sunucusunda susturuldunuz.`)
        .addFields(
          { name: '📝 Sebep', value: sebep, inline: true },
          { name: '⏰ Süre', value: durationText, inline: true }
        )
        .setTimestamp();

      await user.send({ embeds: [dmEmbed] }).catch(() => {});

      // Log
      const logChannel = message.guild.channels.cache.get(this.LOG_CHANNEL_ID);
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setColor('#FEE75C')
          .setAuthor({ name: 'Moderasyon Sistemi', iconURL: message.guild.iconURL() })
          .setTitle('🔇 Üye Susturuldu')
          .setThumbnail(user.displayAvatarURL({ dynamic: true }))
          .addFields(
            { name: '👤 Kullanıcı', value: `${user}`, inline: true },
            { name: '👮 Yetkili', value: `${message.author}`, inline: true },
            { name: '📝 Sebep', value: sebep, inline: false },
            { name: '⏰ Süre', value: durationText, inline: true }
          )
          .setTimestamp();
        logChannel.send({ embeds: [logEmbed] });
      }

      const successEmbed = new EmbedBuilder()
        .setColor('#57F287')
        .setDescription(`🔇 **${user.tag}** susturuldu! (${durationText})`)
        .setTimestamp();

      message.reply({ embeds: [successEmbed] });

    } catch (err) {
      console.error('Mute hatası:', err);
      message.reply("❌ Mute işlemi başarısız.");
    }
  },

  parseDuration(str) {
    if (!str) return null;
    const match = str.match(/^(\d+)(s|m|h|d|dk|sn|sa|g)$/i);
    if (!match) return null;

    const num = parseInt(match[1]);
    const unit = match[2].toLowerCase();

    const multipliers = {
      'sn': 1000,
      's': 1000,
      'dk': 60000,
      'm': 60000,
      'sa': 3600000,
      'h': 3600000,
      'g': 86400000,
      'd': 86400000
    };

    return num * (multipliers[unit] || 60000);
  },

  formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} gün`;
    if (hours > 0) return `${hours} saat`;
    if (minutes > 0) return `${minutes} dakika`;
    return `${seconds} saniye`;
  }
};
