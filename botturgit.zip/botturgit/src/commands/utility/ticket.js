const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const ticketSystem = require('../../systems/ticketSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Ticket sistemi komutları')
        .addSubcommand(subcommand =>
            subcommand
                .setName('panel')
                .setDescription('Ticket paneli gönder'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('kapat')
                .setDescription('Bu ticket\'ı kapat'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    name: 'ticket',
    description: 'Ticket sistemi',

    async executeSlash(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'panel') {
            await ticketSystem.sendPanel(interaction.channel);
            await interaction.reply({
                embeds: [embedUtil.success('Başarılı', 'Ticket paneli gönderildi!')],
                ephemeral: true
            });

        } else if (subcommand === 'kapat') {
            const result = await ticketSystem.close(interaction.channel.id, interaction.user, client);
            
            if (!result.success) {
                return interaction.reply({
                    embeds: [embedUtil.error('Hata', result.message)],
                    ephemeral: true
                });
            }

            await interaction.reply({
                embeds: [embedUtil.success('Ticket Kapatılıyor', 'Kanal 5 saniye içinde silinecek...')]
            });
        }
    },

    async executePrefix(message, args, client) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return message.reply({
                embeds: [embedUtil.error('Yetki Hatası', 'Bu komutu kullanmak için yetkiniz yok!')]
            });
        }

        const subcommand = args[0]?.toLowerCase();

        if (subcommand === 'panel') {
            await ticketSystem.sendPanel(message.channel);
            const reply = await message.reply({
                embeds: [embedUtil.success('Başarılı', 'Ticket paneli gönderildi!')]
            });
            setTimeout(() => reply.delete().catch(() => {}), 3000);

        } else if (subcommand === 'kapat') {
            const result = await ticketSystem.close(message.channel.id, message.author, client);
            
            if (!result.success) {
                return message.reply({
                    embeds: [embedUtil.error('Hata', result.message)]
                });
            }

        } else {
            return message.reply({
                embeds: [embedUtil.info('Ticket Komutları', 
                    '`.ticket panel` - Ticket paneli gönder\n' +
                    '`.ticket kapat` - Bu ticket\'ı kapat'
                )]
            });
        }
    }
};
