const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("profil")
    .setDescription("Kullanıcının detaylı profilini gösterir"),

  async executeSlash(interaction) {
    const user = interaction.user;
    const member = interaction.member;

    const totalSeconds = 0; // Mongo yoksa sıfır göster
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);

    const inVoice = member.voice.channel ? `🎧 ${member.voice.channel.name}` : "❌ Seste değil";

    const level = Math.floor(totalSeconds / 3600);
    const xp = totalSeconds % 3600;

    const embed = new EmbedBuilder()
      .setColor("#2b2d31")
      .setAuthor({ name: `${user.username} Profili`, iconURL: user.displayAvatarURL() })
      .setThumbnail(user.displayAvatarURL())
      .addFields(
        { name: "👤 Kullanıcı", value: `<@${user.id}>`, inline: true },
        { name: "🆔 ID", value: user.id, inline: true },
        { name: "⏱️ Toplam Ses", value: `${hours}s ${minutes}dk`, inline: true },
        { name: "🎙️ Ses Durumu", value: inVoice, inline: true },
        { name: "📅 Sunucuya Katılım", value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: "🏅 Ses Seviyesi", value: `Level ${level} (${xp} XP)`, inline: true }
      )
      .setFooter({ text: "Bubu • Profil Sistemi" })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },

  async executePrefix(message) {
    const user = message.author;
    const member = message.member;

    const totalSeconds = 0;
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);

    const inVoice = member.voice.channel ? `🎧 ${member.voice.channel.name}` : "❌ Seste değil";

    const level = Math.floor(totalSeconds / 3600);
    const xp = totalSeconds % 3600;

    const embed = new EmbedBuilder()
      .setColor("#2b2d31")
      .setAuthor({ name: `${user.username} Profili`, iconURL: user.displayAvatarURL() })
      .setThumbnail(user.displayAvatarURL())
      .addFields(
        { name: "👤 Kullanıcı", value: `<@${user.id}>`, inline: true },
        { name: "🆔 ID", value: user.id, inline: true },
        { name: "⏱️ Toplam Ses", value: `${hours}s ${minutes}dk`, inline: true },
        { name: "🎙️ Ses Durumu", value: inVoice, inline: true },
        { name: "📅 Sunucuya Katılım", value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: "🏅 Ses Seviyesi", value: `Level ${level} (${xp} XP)`, inline: true }
      )
      .setFooter({ text: "Bubu • Profil Sistemi" })
      .setTimestamp();

    message.reply({ embeds: [embed] });
  }
};
