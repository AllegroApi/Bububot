const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

// Bot bilgileri
const BOT_INFO = {
    name: 'Flux',
    version: '2.0.0',
    developer: 'Flux Team',
    supportServer: 'discord.gg/flux',
    website: 'fluxbot.xyz'
};

// Komut kategorileri
const categories = {
    home: {
        emoji: '🏠',
        name: 'Ana Sayfa',
        description: 'Bot hakkında genel bilgiler'
    },
    general: {
        emoji: '📋',
        name: 'Genel',
        description: 'Temel bot komutları',
        commands: [
            { name: 'help', usage: '/help', description: 'Bu yardım menüsünü gösterir', cooldown: '3s' },
            { name: 'ping', usage: '/ping', description: 'Bot gecikmesini gösterir', cooldown: '5s' },
            { name: 'profil', usage: '/profil [@kullanıcı]', description: 'Kullanıcı profilini gösterir', cooldown: '10s' },
            { name: 'sunucu', usage: '/sunucu', description: 'Sunucu bilgilerini gösterir', cooldown: '10s' }
        ]
    },
    level: {
        emoji: '📊',
        name: 'Seviye Sistemi',
        description: 'XP ve seviye komutları',
        commands: [
            { name: 'seviye', usage: '/seviye bak [@kullanıcı]', description: 'Seviye bilgilerini gösterir', cooldown: '10s' },
            { name: 'sıralama', usage: '/seviye sıralama', description: 'Seviye sıralamasını gösterir', cooldown: '30s' },
            { name: 'ödüller', usage: '/seviye ödüller', description: 'Seviye ödüllerini listeler', cooldown: '10s' }
        ]
    },
    fun: {
        emoji: '🎉',
        name: 'Eğlence',
        description: 'Eğlenceli komutlar',
        commands: [
            { name: 'ship', usage: '/ship @kullanıcı1 @kullanıcı2', description: 'Aşk uyumu hesaplar', cooldown: '15s' },
            { name: 'çekiliş', usage: '/çekiliş başlat', description: 'Çekiliş başlatır', cooldown: '60s', permission: 'Yetkili' },
            { name: 'oyunbaslat', usage: '/oyunbaslat', description: 'Son harf oyunu başlatır', cooldown: '30s' },
            { name: 'oyunbitir', usage: '/oyunbitir', description: 'Oyunu sonlandırır', cooldown: '10s' }
        ]
    },
    moderation: {
        emoji: '🛡️',
        name: 'Moderasyon',
        description: 'Sunucu yönetim komutları',
        commands: [
            { name: 'ban', usage: '/ban @kullanıcı [sebep]', description: 'Kullanıcıyı yasaklar', permission: 'Ban Yetkisi' },
            { name: 'kick', usage: '/kick @kullanıcı [sebep]', description: 'Kullanıcıyı atar', permission: 'Kick Yetkisi' },
            { name: 'mute', usage: '/mute @kullanıcı [sebep]', description: 'Kullanıcıyı susturur', permission: 'Mute Yetkisi' },
            { name: 'unmute', usage: '/unmute @kullanıcı', description: 'Susturmayı kaldırır', permission: 'Mute Yetkisi' },
            { name: 'jail', usage: '/jail at @kullanıcı [süre] [sebep]', description: 'Kullanıcıyı hapse atar', permission: 'Moderatör' },
            { name: 'sil', usage: '/sil [miktar]', description: 'Mesaj siler (1-100)', permission: 'Mesaj Yönetimi' },
            { name: 'banlılar', usage: '/banlılar', description: 'Banlı üyeleri listeler', permission: 'Ban Yetkisi' }
        ]
    },
    systems: {
        emoji: '⚙️',
        name: 'Sistemler',
        description: 'Bot sistemleri ve panelleri',
        commands: [
            { name: 'ticket', usage: '/ticket panel', description: 'Destek ticket paneli', permission: 'Yönetici' },
            { name: 'itiraf', usage: '/itiraf panel', description: 'Anonim itiraf paneli', permission: 'Yönetici' },
            { name: 'tag', usage: '/tag tara', description: 'Tag sistemini tarar', permission: 'Yönetici' },
            { name: 'basvuru', usage: '/basvuru', description: 'Yetkili başvurusu yapar', cooldown: '24h' },
            { name: 'yetkili', usage: '/yetkili seç', description: 'Yetkili seçim menüsü', permission: 'Yönetici' }
        ]
    },
    staff: {
        emoji: '👮',
        name: 'Yetkili',
        description: 'Yetkili komutları',
        commands: [
            { name: 'ceza sorgula', usage: '/ceza sorgula @kullanıcı', description: 'Ceza geçmişini gösterir', permission: 'Moderatör' },
            { name: 'basvuru', usage: '/basvuru', description: 'Yetkili başvuru formu', cooldown: '24h' }
        ]
    }
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Bot komutlarını ve özelliklerini gösterir')
        .addStringOption(opt =>
            opt.setName('komut')
                .setDescription('Detaylı bilgi almak istediğiniz komut')
                .setRequired(false)
        ),

    name: 'help',
    aliases: ['yardım', 'h', 'komutlar', 'menu', 'commands'],
    description: 'Bot komutlarını gösterir',

    async executeSlash(interaction, client) {
        const specificCommand = interaction.options.getString('komut');
        if (specificCommand) {
            return this.showCommandInfo(interaction, specificCommand, client, false);
        }
        await this.sendHelpMenu(interaction, client, false);
    },

    async executePrefix(message, args, client) {
        if (args[0]) {
            return this.showCommandInfo(message, args[0], client, true);
        }
        await this.sendHelpMenu(message, client, true);
    },

    async sendHelpMenu(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;
        const user = isPrefix ? ctx.author : ctx.user;

        // Ana sayfa embed'i
        const homeEmbed = this.createHomeEmbed(client, guild, user);
        
        // Select menü
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('help_menu')
            .setPlaceholder('📂 Kategori seçin...')
            .addOptions(
                Object.entries(categories).map(([key, cat]) => ({
                    label: cat.name,
                    description: cat.description,
                    value: key,
                    emoji: cat.emoji,
                    default: key === 'home'
                }))
            );

        // Butonlar
        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('help_home')
                .setLabel('Ana Sayfa')
                .setEmoji('🏠')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setLabel('Destek Sunucusu')
                .setEmoji('💬')
                .setStyle(ButtonStyle.Link)
                .setURL(`https://${BOT_INFO.supportServer}`),
            new ButtonBuilder()
                .setLabel('Davet Et')
                .setEmoji('➕')
                .setStyle(ButtonStyle.Link)
                .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
        );

        const selectRow = new ActionRowBuilder().addComponents(selectMenu);

        let response;
        if (isPrefix) {
            response = await ctx.reply({ embeds: [homeEmbed], components: [selectRow, buttons] });
        } else {
            response = await ctx.reply({ embeds: [homeEmbed], components: [selectRow, buttons], fetchReply: true });
        }

        // Collector
        const collector = response.createMessageComponentCollector({
            filter: i => i.user.id === user.id,
            time: 180000 // 3 dakika
        });

        collector.on('collect', async i => {
            let embed;

            if (i.customId === 'help_home') {
                embed = this.createHomeEmbed(client, guild, user);
            } else if (i.customId === 'help_menu') {
                const categoryKey = i.values[0];
                if (categoryKey === 'home') {
                    embed = this.createHomeEmbed(client, guild, user);
                } else {
                    embed = this.createCategoryEmbed(categoryKey, client, guild);
                }
            }

            await i.update({ embeds: [embed] });
        });

        collector.on('end', async () => {
            try {
                const disabledSelect = StringSelectMenuBuilder.from(selectMenu).setDisabled(true);
                const disabledButtons = ActionRowBuilder.from(buttons);
                disabledButtons.components[0].setDisabled(true);
                
                await response.edit({ 
                    components: [
                        new ActionRowBuilder().addComponents(disabledSelect),
                        disabledButtons
                    ] 
                });
            } catch (e) {}
        });
    },

    createHomeEmbed(client, guild, user) {
        const totalCommands = Object.values(categories)
            .filter(c => c.commands)
            .reduce((acc, cat) => acc + cat.commands.length, 0);

        return new EmbedBuilder()
            .setColor('#5865F2')
            .setAuthor({ 
                name: `${BOT_INFO.name} Bot`, 
                iconURL: client.user.displayAvatarURL({ dynamic: true })
            })
            .setTitle('📚 Yardım Merkezi')
            .setDescription(
                `Merhaba **${user.displayName}**! 👋\n\n` +
                `Ben **${BOT_INFO.name}**, sunucunuzun çok yönlü yardımcısıyım. ` +
                `Aşağıdaki menüden kategorileri keşfedebilir veya butonları kullanabilirsiniz.\n\n` +
                `╭─────────────────────────╮\n` +
                `│  📌 **Prefix:** \`.komut\` veya \`/komut\`\n` +
                `│  📊 **Toplam Komut:** \`${totalCommands}\`\n` +
                `│  🌐 **Sunucu:** \`${guild.memberCount}\` üye\n` +
                `│  ⏱️ **Ping:** \`${client.ws.ping}ms\`\n` +
                `╰─────────────────────────╯`
            )
            .addFields(
                {
                    name: '🌟 Öne Çıkan Özellikler',
                    value: [
                        '```',
                        '📊 Gelişmiş Seviye Sistemi',
                        '🏷️ Otomatik Tag Rol Sistemi',
                        '💎 Booster Ödül Sistemi',
                        '🎉 Akıllı Çekiliş Sistemi',
                        '🎫 Öncelikli Ticket Sistemi',
                        '🤫 Anonim İtiraf Sistemi',
                        '🎙️ Özel Ses Odaları',
                        '🛡️ Anti-Raid & AutoMod',
                        '⚖️ Detaylı Ceza Takibi',
                        '📝 Kapsamlı Log Sistemi',
                        '```'
                    ].join('\n'),
                    inline: false
                }
            )
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 512 }))
            .setFooter({ 
                text: `${BOT_INFO.name} v${BOT_INFO.version} • ${BOT_INFO.supportServer}`,
                iconURL: guild.iconURL({ dynamic: true })
            })
            .setTimestamp();
    },

    createCategoryEmbed(categoryKey, client, guild) {
        const category = categories[categoryKey];
        
        const commandList = category.commands.map(cmd => {
            const permBadge = cmd.permission ? `\`🔒 ${cmd.permission}\`` : '';
            const cooldownBadge = cmd.cooldown ? `\`⏱️ ${cmd.cooldown}\`` : '';
            const badges = [permBadge, cooldownBadge].filter(b => b).join(' ');
            
            return [
                `**\`${cmd.usage}\`**`,
                `> ${cmd.description}`,
                badges ? `> ${badges}` : ''
            ].filter(l => l).join('\n');
        }).join('\n\n');

        return new EmbedBuilder()
            .setColor(this.getCategoryColor(categoryKey))
            .setAuthor({ 
                name: `${BOT_INFO.name} Bot`, 
                iconURL: client.user.displayAvatarURL({ dynamic: true })
            })
            .setTitle(`${category.emoji} ${category.name}`)
            .setDescription(
                `${category.description}\n\n` +
                `**📜 Komutlar (${category.commands.length})**\n\n` +
                commandList
            )
            .setFooter({ 
                text: `Ana menüye dönmek için 🏠 butonuna tıklayın`,
                iconURL: guild.iconURL({ dynamic: true })
            })
            .setTimestamp();
    },

    getCategoryColor(key) {
        const colors = {
            home: '#5865F2',
            general: '#3498DB',
            level: '#F1C40F',
            fun: '#E91E63',
            moderation: '#E74C3C',
            systems: '#9B59B6',
            staff: '#1ABC9C'
        };
        return colors[key] || '#5865F2';
    },

    async showCommandInfo(ctx, commandName, client, isPrefix) {
        // Tüm kategorilerde komutu ara
        let foundCommand = null;
        let foundCategory = null;

        for (const [key, cat] of Object.entries(categories)) {
            if (!cat.commands) continue;
            const cmd = cat.commands.find(c => 
                c.name.toLowerCase() === commandName.toLowerCase()
            );
            if (cmd) {
                foundCommand = cmd;
                foundCategory = cat;
                break;
            }
        }

        if (!foundCommand) {
            const msg = `❌ \`${commandName}\` adında bir komut bulunamadı!`;
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg, flags: 64 });
        }

        const embed = new EmbedBuilder()
            .setColor('#5865F2')
            .setTitle(`📖 Komut: ${foundCommand.name}`)
            .addFields(
                { name: '📝 Açıklama', value: foundCommand.description, inline: false },
                { name: '💡 Kullanım', value: `\`${foundCommand.usage}\``, inline: true },
                { name: '📂 Kategori', value: `${foundCategory.emoji} ${foundCategory.name}`, inline: true }
            )
            .setFooter({ text: `${BOT_INFO.name} Yardım Sistemi` })
            .setTimestamp();

        if (foundCommand.permission) {
            embed.addFields({ name: '🔒 Gerekli Yetki', value: foundCommand.permission, inline: true });
        }
        if (foundCommand.cooldown) {
            embed.addFields({ name: '⏱️ Bekleme Süresi', value: foundCommand.cooldown, inline: true });
        }

        if (isPrefix) {
            ctx.reply({ embeds: [embed] });
        } else {
            ctx.reply({ embeds: [embed] });
        }
    }
};
