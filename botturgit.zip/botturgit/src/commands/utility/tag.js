const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const tagSystem = require('../../systems/tagSystem');
const embedUtil = require('../../utils/embed');
const config = require('../../config/config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tag')
        .setDescription('Tag sistemi komutları')
        .addSubcommand(subcommand =>
            subcommand
                .setName('tara')
                .setDescription('Tüm sunucuyu tarayıp tag rollerini güncelle'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('bilgi')
                .setDescription('Tag sistemi bilgisi'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    name: 'tag',
    description: 'Tag sistemi',

    async executeSlash(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'tara') {
            await interaction.deferReply({ flags: 64 });

            const result = await tagSystem.scanGuild(interaction.guild, client);

            await interaction.editReply({
                embeds: [embedUtil.success('Tarama Tamamlandı', 
                    `✅ **${result.added}** kişiye rol verildi\n` +
                    `❌ **${result.removed}** kişiden rol alındı`
                )]
            });

        } else if (subcommand === 'bilgi') {
            const tag = config.tag?.tag || 'Ayarlanmamış';
            const roleId = config.tag?.roleId;
            const role = roleId ? interaction.guild.roles.cache.get(roleId) : null;

            await interaction.reply({
                embeds: [embedUtil.info('Tag Sistemi Bilgisi', 
                    `**Tag:** \`${tag}\`\n` +
                    `**Rol:** ${role ? role : 'Ayarlanmamış'}\n` +
                    `**Durum:** ${config.tag?.enabled ? '✅ Aktif' : '❌ Devre Dışı'}`
                )],
                flags: 64
            });
        }
    },

    async executePrefix(message, args, client) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.reply({
                embeds: [embedUtil.error('Yetki Hatası', 'Bu komutu kullanmak için yetkiniz yok!')]
            });
        }

        const subcommand = args[0]?.toLowerCase();

        if (subcommand === 'tara') {
            const msg = await message.reply({
                embeds: [embedUtil.info('Taranıyor', 'Sunucu taranıyor, lütfen bekleyin...')]
            });

            const result = await tagSystem.scanGuild(message.guild, client);

            await msg.edit({
                embeds: [embedUtil.success('Tarama Tamamlandı', 
                    `✅ **${result.added}** kişiye rol verildi\n` +
                    `❌ **${result.removed}** kişiden rol alındı`
                )]
            });

        } else {
            const tag = config.tag?.tag || 'Ayarlanmamış';
            
            return message.reply({
                embeds: [embedUtil.info('Tag Sistemi', 
                    `**Tag:** \`${tag}\`\n` +
                    `**Komutlar:**\n` +
                    `\`.tag tara\` - Sunucuyu tara`
                )]
            });
        }
    }
};
