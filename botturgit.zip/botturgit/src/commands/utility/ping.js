const { SlashCommandBuilder, MessageFlags } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Botun gecikmesini gösterir"),

  name: 'ping',
  description: 'Botun gecikmesini gösterir',

  async executeSlash(interaction) {
    const start = Date.now();
    await interaction.reply({ content: "🏓 Pinging..." });
    const latency = Date.now() - start;
    const apiLatency = Math.round(interaction.client.ws.ping);
    await interaction.editReply(`🏓 **Pong!**\n📡 Gecikme: **${latency}ms**\n💓 API: **${apiLatency}ms**`);
  },

  async executePrefix(message) {
    const sent = await message.reply("Pong! 🏓");
    const delay = sent.createdTimestamp - message.createdTimestamp;
    message.channel.send(`Gecikme: ${delay}ms`);
  }
};
