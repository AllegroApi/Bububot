const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const confessionSystem = require('../../systems/confessionSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('itiraf')
        .setDescription('İtiraf sistemi komutları')
        .addSubcommand(subcommand =>
            subcommand
                .setName('panel')
                .setDescription('İtiraf paneli gönder'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('sil')
                .setDescription('Bir itirafı sil')
                .addIntegerOption(option =>
                    option.setName('id')
                        .setDescription('İtiraf numarası')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('bul')
                .setDescription('İtirafı kimin yazdığını bul (gizli)')
                .addIntegerOption(option =>
                    option.setName('id')
                        .setDescription('İtiraf numarası')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    name: 'itiraf',
    description: 'İtiraf sistemi',

    async executeSlash(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'panel') {
            await confessionSystem.sendPanel(interaction.channel);
            await interaction.reply({
                embeds: [embedUtil.success('Başarılı', 'İtiraf paneli gönderildi!')],
                ephemeral: true
            });

        } else if (subcommand === 'sil') {
            const id = interaction.options.getInteger('id');
            const result = await confessionSystem.delete(id, client);
            
            if (!result.success) {
                return interaction.reply({
                    embeds: [embedUtil.error('Hata', result.message)],
                    ephemeral: true
                });
            }

            await interaction.reply({
                embeds: [embedUtil.success('Başarılı', `#${id} numaralı itiraf silindi!`)],
                ephemeral: true
            });

        } else if (subcommand === 'bul') {
            const id = interaction.options.getInteger('id');
            const author = confessionSystem.findAuthor(id);
            
            if (!author) {
                return interaction.reply({
                    embeds: [embedUtil.error('Hata', 'İtiraf bulunamadı!')],
                    ephemeral: true
                });
            }

            await interaction.reply({
                embeds: [embedUtil.create({
                    color: '#5865F2',
                    title: `🔍 İtiraf #${id} - Yazar Bilgisi`,
                    fields: [
                        { name: '👤 Kullanıcı', value: `${author.tag} (<@${author.id}>)`, inline: false },
                        { name: '📅 Tarih', value: `<t:${Math.floor(author.createdAt / 1000)}:F>`, inline: false }
                    ],
                    footer: '⚠️ Bu bilgi gizlidir!'
                })],
                ephemeral: true
            });
        }
    },

    async executePrefix(message, args, client) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return message.reply({
                embeds: [embedUtil.error('Yetki Hatası', 'Bu komutu kullanmak için yetkiniz yok!')]
            });
        }

        const subcommand = args[0]?.toLowerCase();

        if (subcommand === 'panel') {
            await confessionSystem.sendPanel(message.channel);
            const reply = await message.reply({
                embeds: [embedUtil.success('Başarılı', 'İtiraf paneli gönderildi!')]
            });
            setTimeout(() => reply.delete().catch(() => {}), 3000);
            message.delete().catch(() => {});

        } else {
            return message.reply({
                embeds: [embedUtil.info('İtiraf Komutları', 
                    '`.itiraf panel` - İtiraf paneli gönder\n' +
                    '`/itiraf sil <id>` - Bir itirafı sil\n' +
                    '`/itiraf bul <id>` - İtirafı kimin yazdığını bul'
                )]
            });
        }
    }
};
