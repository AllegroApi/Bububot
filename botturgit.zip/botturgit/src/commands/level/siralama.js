const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const levelSystem = require('../../systems/levelSystem');
const config = require('../../config/config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('siralama')
        .setDescription('Seviye sıralamasını göster')
        .addIntegerOption(option =>
            option.setName('sayfa')
                .setDescription('Sayfa numarası')
                .setRequired(false)
                .setMinValue(1)),

    name: 'sıralama',
    aliases: ['leaderboard', 'lb', 'top'],
    description: 'Seviye sıralamasını göster',

    async executeSlash(interaction, client) {
        const page = interaction.options.getInteger('sayfa') || 1;
        const embed = await createLeaderboardEmbed(interaction.guild, page);
        await interaction.reply({ embeds: [embed] });
    },

    async executePrefix(message, args) {
        const page = parseInt(args[0]) || 1;
        const embed = await createLeaderboardEmbed(message.guild, page);
        await message.reply({ embeds: [embed] });
    }
};

async function createLeaderboardEmbed(guild, page) {
    const perPage = 10;
    const leaderboard = levelSystem.getLeaderboard(100);
    
    const totalPages = Math.ceil(leaderboard.length / perPage);
    const currentPage = Math.min(page, totalPages) || 1;
    const start = (currentPage - 1) * perPage;
    const pageData = leaderboard.slice(start, start + perPage);

    const medals = ['🥇', '🥈', '🥉'];

    let description = '';
    for (let i = 0; i < pageData.length; i++) {
        const user = pageData[i];
        const position = start + i + 1;
        const medal = position <= 3 ? medals[position - 1] : `**${position}.**`;
        
        try {
            const member = await guild.members.fetch(user.id).catch(() => null);
            const username = member ? member.user.username : 'Bilinmeyen Kullanıcı';
            
            description += `${medal} **${username}**\n`;
            description += `└ Seviye: **${user.level}** • XP: **${user.xp.toLocaleString()}** • Mesaj: **${user.messages.toLocaleString()}**\n\n`;
        } catch (e) {
            description += `${medal} **Bilinmeyen Kullanıcı**\n`;
            description += `└ Seviye: **${user.level}** • XP: **${user.xp.toLocaleString()}**\n\n`;
        }
    }

    if (!description) {
        description = 'Henüz sıralamada kimse yok!';
    }

    const embed = new EmbedBuilder()
        .setColor(config.colors?.gold || '#FFD700')
        .setTitle('🏆 Seviye Sıralaması')
        .setDescription(description)
        .setFooter({ text: `Sayfa ${currentPage}/${totalPages || 1} • Toplam ${leaderboard.length} kullanıcı` })
        .setTimestamp();

    return embed;
}
