const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require("discord.js");
const fs = require('fs');
const path = require('path');

// Level verileri
const usersPath = path.join(__dirname, '../../data/users.json');

function loadUsers() {
    try {
        if (fs.existsSync(usersPath)) {
            return JSON.parse(fs.readFileSync(usersPath, 'utf8'));
        }
    } catch (e) {}
    return {};
}

// XP hesaplama
function getRequiredXP(level) {
    return Math.floor(100 * Math.pow(level, 1.5));
}

function getLevelFromXP(xp) {
    let level = 0;
    let totalXP = 0;
    while (totalXP <= xp) {
        level++;
        totalXP += getRequiredXP(level);
    }
    return level - 1;
}

// Progress bar oluştur
function createProgressBar(current, max, length = 15) {
    const percentage = Math.min(current / max, 1);
    const filled = Math.round(length * percentage);
    const empty = length - filled;
    
    const filledChar = '█';
    const emptyChar = '░';
    
    return filledChar.repeat(filled) + emptyChar.repeat(empty);
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("seviye")
        .setDescription("Seviye bilgilerini gösterir")
        .addSubcommand(sub =>
            sub.setName("bak")
                .setDescription("Kendi veya başka birinin seviyesine bak")
                .addUserOption(opt => opt.setName("kullanıcı").setDescription("Seviyesine bakılacak kullanıcı"))
        )
        .addSubcommand(sub =>
            sub.setName("sıralama")
                .setDescription("Sunucu seviye sıralamasını gösterir")
        )
        .addSubcommand(sub =>
            sub.setName("ödüller")
                .setDescription("Seviye ödüllerini gösterir")
        ),

    name: "seviye",
    aliases: ["level", "rank", "xp", "sıralama", "leaderboard", "top"],
    description: "Seviye sistemi komutları",

    // Seviye ödülleri
    levelRewards: {
        5: { roleId: null, reward: '🎖️ Acemi rozeti' },
        10: { roleId: null, reward: '⭐ Aktif üye rolü' },
        20: { roleId: null, reward: '💎 VIP erişimi' },
        30: { roleId: null, reward: '👑 Elit üye rozeti' },
        50: { roleId: null, reward: '🏆 Efsane üye' },
        100: { roleId: null, reward: '🌟 Sunucu Yıldızı' }
    },

    async executeSlash(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === "bak") {
            const user = interaction.options.getUser("kullanıcı") || interaction.user;
            await this.showLevel(interaction, user, client, false);
        } else if (subcommand === "sıralama") {
            await this.showLeaderboard(interaction, client, false);
        } else if (subcommand === "ödüller") {
            await this.showRewards(interaction, client, false);
        }
    },

    async executePrefix(message, args, client) {
        const cmd = args[0]?.toLowerCase();

        if (cmd === "sıralama" || cmd === "top" || cmd === "leaderboard" || this.aliases.includes(cmd)) {
            if (cmd === "sıralama" || cmd === "top" || cmd === "leaderboard") {
                return this.showLeaderboard(message, client, true);
            }
        }

        if (cmd === "ödüller" || cmd === "rewards") {
            return this.showRewards(message, client, true);
        }

        // Varsayılan: seviye göster
        const user = message.mentions.users.first() || message.author;
        await this.showLevel(message, user, client, true);
    },

    async showLevel(ctx, user, client, isPrefix) {
        const users = loadUsers();
        const userData = users[user.id] || { xp: 0, level: 0, messages: 0 };
        
        const level = userData.level || getLevelFromXP(userData.xp || 0);
        const xp = userData.xp || 0;
        
        // Bir sonraki seviye için gerekli XP
        let totalXPForCurrentLevel = 0;
        for (let i = 1; i <= level; i++) {
            totalXPForCurrentLevel += getRequiredXP(i);
        }
        const xpForNextLevel = getRequiredXP(level + 1);
        const currentLevelXP = xp - totalXPForCurrentLevel;
        const progressPercent = Math.floor((currentLevelXP / xpForNextLevel) * 100);

        // Sıralama hesapla
        const sortedUsers = Object.entries(users)
            .sort((a, b) => (b[1].xp || 0) - (a[1].xp || 0));
        const rank = sortedUsers.findIndex(([id]) => id === user.id) + 1 || sortedUsers.length + 1;

        // Seviye rozeti
        const badges = this.getLevelBadge(level);
        
        // Renk belirleme (seviyeye göre)
        const colors = ['#808080', '#00FF00', '#00BFFF', '#9400D3', '#FFD700', '#FF4500'];
        const colorIndex = Math.min(Math.floor(level / 20), colors.length - 1);

        const embed = new EmbedBuilder()
            .setColor(colors[colorIndex])
            .setAuthor({ 
                name: `${user.displayName}'in Profili`, 
                iconURL: user.displayAvatarURL({ dynamic: true }) 
            })
            .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
            .addFields(
                { 
                    name: '📊 Seviye Bilgileri', 
                    value: [
                        `${badges} **Seviye:** \`${level}\``,
                        `⭐ **XP:** \`${xp.toLocaleString()}\``,
                        `🏆 **Sıralama:** \`#${rank}\``,
                        `💬 **Mesaj:** \`${(userData.messages || 0).toLocaleString()}\``
                    ].join('\n'),
                    inline: true 
                },
                {
                    name: '📈 İlerleme',
                    value: [
                        `Sonraki Seviye: \`${level + 1}\``,
                        `\`${currentLevelXP.toLocaleString()}\` / \`${xpForNextLevel.toLocaleString()}\` XP`,
                        `${createProgressBar(currentLevelXP, xpForNextLevel)} \`${progressPercent}%\``
                    ].join('\n'),
                    inline: true
                }
            )
            .setFooter({ 
                text: `Sonraki seviyeye ${(xpForNextLevel - currentLevelXP).toLocaleString()} XP kaldı!` 
            })
            .setTimestamp();

        // Bir sonraki ödül
        const nextReward = Object.entries(this.levelRewards)
            .find(([lvl]) => parseInt(lvl) > level);
        
        if (nextReward) {
            embed.addFields({
                name: '🎁 Sonraki Ödül',
                value: `Seviye \`${nextReward[0]}\` → ${nextReward[1].reward}`,
                inline: false
            });
        }

        if (isPrefix) {
            ctx.reply({ embeds: [embed] });
        } else {
            ctx.reply({ embeds: [embed] });
        }
    },

    async showLeaderboard(ctx, client, isPrefix) {
        const users = loadUsers();
        const guild = isPrefix ? ctx.guild : ctx.guild;

        // Sıralama
        const sortedUsers = Object.entries(users)
            .filter(([id]) => guild.members.cache.has(id))
            .sort((a, b) => (b[1].xp || 0) - (a[1].xp || 0))
            .slice(0, 10);

        if (sortedUsers.length === 0) {
            const msg = "📊 Henüz sıralamada kimse yok!";
            return isPrefix ? ctx.reply(msg) : ctx.reply({ content: msg });
        }

        const medals = ['🥇', '🥈', '🥉'];
        const leaderboardText = sortedUsers.map(([userId, data], index) => {
            const medal = medals[index] || `**${index + 1}.**`;
            const level = data.level || getLevelFromXP(data.xp || 0);
            const xp = (data.xp || 0).toLocaleString();
            return `${medal} <@${userId}>\n> 📊 Seviye: \`${level}\` • ⭐ XP: \`${xp}\``;
        }).join('\n\n');

        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setAuthor({ 
                name: `${guild.name} Seviye Sıralaması`, 
                iconURL: guild.iconURL({ dynamic: true }) 
            })
            .setDescription(leaderboardText)
            .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }))
            .setFooter({ text: `Top 10 • Toplam ${Object.keys(users).length} üye` })
            .setTimestamp();

        if (isPrefix) {
            ctx.reply({ embeds: [embed] });
        } else {
            ctx.reply({ embeds: [embed] });
        }
    },

    async showRewards(ctx, client, isPrefix) {
        const guild = isPrefix ? ctx.guild : ctx.guild;

        const rewardsList = Object.entries(this.levelRewards)
            .map(([level, data]) => {
                return `**Seviye ${level}** → ${data.reward}`;
            })
            .join('\n');

        const embed = new EmbedBuilder()
            .setColor('#9B59B6')
            .setAuthor({ 
                name: 'Seviye Ödülleri', 
                iconURL: guild.iconURL({ dynamic: true }) 
            })
            .setDescription(
                '🎁 **Seviye atladıkça kazanacağın ödüller:**\n\n' +
                rewardsList +
                '\n\n*Aktif olarak mesaj atarak XP kazan!*'
            )
            .addFields(
                { name: '💡 Nasıl XP Kazanırım?', value: '> Her mesajda `15-25` XP kazanırsın\n> 60 saniyede bir XP alabilirsin', inline: false }
            )
            .setFooter({ text: 'Daha fazla özellik için seviye atla!' })
            .setTimestamp();

        if (isPrefix) {
            ctx.reply({ embeds: [embed] });
        } else {
            ctx.reply({ embeds: [embed] });
        }
    },

    getLevelBadge(level) {
        if (level >= 100) return '🌟';
        if (level >= 50) return '🏆';
        if (level >= 30) return '👑';
        if (level >= 20) return '💎';
        if (level >= 10) return '⭐';
        if (level >= 5) return '🎖️';
        return '🔰';
    }
};
