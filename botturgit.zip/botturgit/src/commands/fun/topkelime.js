const { SlashCommandBuilder } = require("discord.js");
const game = require("../../game/sonHarf");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("topkelime")
    .setDescription("Oyundaki kelime sayılarını gösterir"),

  name: "topkelime",
  description: "Oyundaki kelime sayılarını gösterir",

  async executeSlash(interaction) {
    if (!game.active) {
      return interaction.reply({
        content: "❌ Aktif bir oyun yok.",
        flags: 64
      });
    }

    const sorted = Object.entries(game.scores)
      .sort((a, b) => b[1] - a[1]);

    if (sorted.length === 0) {
      return interaction.reply("Henüz kimse kelime yazmadı.");
    }

    let text = "🏆 **Kelime Sıralaması**\n\n";
    for (let [id, score] of sorted) {
      const user = await interaction.client.users.fetch(id).catch(() => null);
      text += `**${user?.username || 'Bilinmeyen'}** → ${score} kelime\n`;
    }

    await interaction.reply(text);
  },

  async executePrefix(message) {
    if (!game.active) {
      return message.reply("❌ Aktif bir oyun yok.");
    }

    const sorted = Object.entries(game.scores)
      .sort((a, b) => b[1] - a[1]);

    if (sorted.length === 0) {
      return message.reply("Henüz kimse kelime yazmadı.");
    }

    let text = "🏆 **Kelime Sıralaması**\n\n";
    for (let [id, score] of sorted) {
      const user = await message.client.users.fetch(id).catch(() => null);
      text += `**${user?.username || 'Bilinmeyen'}** → ${score} kelime\n`;
    }

    await message.reply(text);
  }
};
