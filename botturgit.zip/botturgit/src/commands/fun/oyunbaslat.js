const { SlashCommandBuilder } = require("discord.js");
const game = require("../../game/sonHarf");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("oyunbaslat")
    .setDescription("Son harf kelime oyununu başlatır"),

  name: "oyunbaslat",
  description: "Son harf kelime oyununu başlatır",

  async executeSlash(interaction) {
    if (game.active) {
      return interaction.reply({
        content: "❌ Oyun zaten aktif.",
        flags: 64
      });
    }

    game.active = true;
    game.channelId = interaction.channelId;
    game.lastWord = null;
    game.usedWords.clear();
    game.scores = {};

    await interaction.reply(
      "🎮 **Son Harf Oyunu Başladı!**\n" +
      "İlk kelimeyi biri yazabilir.\n" +
      "⚠️ `ğ` ile biten kelimeler geçersizdir."
    );
  },

  async executePrefix(message) {
    if (game.active) {
      return message.reply("❌ Oyun zaten aktif.");
    }

    game.active = true;
    game.channelId = message.channelId;
    game.lastWord = null;
    game.usedWords.clear();
    game.scores = {};

    await message.reply(
      "🎮 **Son Harf Oyunu Başladı!**\n" +
      "İlk kelimeyi biri yazabilir.\n" +
      "⚠️ `ğ` ile biten kelimeler geçersizdir."
    );
  }
};
