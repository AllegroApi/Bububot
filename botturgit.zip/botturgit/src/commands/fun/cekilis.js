const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const giveawaySystem = require('../../systems/giveawaySystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('cekilis')
        .setDescription('Çekiliş komutları')
        .addSubcommand(subcommand =>
            subcommand
                .setName('baslat')
                .setDescription('Yeni çekiliş başlat')
                .addStringOption(option =>
                    option.setName('odul')
                        .setDescription('Çekiliş ödülü')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('sure')
                        .setDescription('Süre (örn: 1d, 2h, 30m)')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('kazanan')
                        .setDescription('Kazanan sayısı')
                        .setRequired(false)
                        .setMinValue(1)
                        .setMaxValue(10))
                .addRoleOption(option =>
                    option.setName('rol')
                        .setDescription('Katılmak için gerekli rol')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('bitir')
                .setDescription('Çekilişi erken bitir')
                .addStringOption(option =>
                    option.setName('mesaj_id')
                        .setDescription('Çekiliş mesajının ID\'si')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('yenile')
                .setDescription('Yeni kazanan seç')
                .addStringOption(option =>
                    option.setName('mesaj_id')
                        .setDescription('Çekiliş mesajının ID\'si')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('sayi')
                        .setDescription('Yeni kazanan sayısı')
                        .setRequired(false)
                        .setMinValue(1)
                        .setMaxValue(5)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    name: 'çekiliş',
    description: 'Çekiliş başlat/bitir/yenile',

    async executeSlash(interaction, client) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'baslat') {
            const prize = interaction.options.getString('odul');
            const durationStr = interaction.options.getString('sure');
            const winnerCount = interaction.options.getInteger('kazanan') || 1;
            const requiredRole = interaction.options.getRole('rol');

            // Süreyi parse et
            const duration = giveawaySystem.parseDuration(durationStr);
            if (!duration) {
                return interaction.reply({
                    embeds: [embedUtil.error('Hata', 'Geçersiz süre formatı! Örnek: 1d, 2h, 30m, 60s')],
                    ephemeral: true
                });
            }

            await interaction.deferReply({ ephemeral: true });

            const giveaway = await giveawaySystem.start(interaction.channel, {
                prize,
                duration,
                winnerCount,
                requiredRoleId: requiredRole?.id
            }, interaction.user);

            await interaction.editReply({
                embeds: [embedUtil.success('Çekiliş Başlatıldı', `**${prize}** için çekiliş başlatıldı!\nBitiş: <t:${Math.floor(giveaway.endsAt / 1000)}:R>`)]
            });

        } else if (subcommand === 'bitir') {
            const messageId = interaction.options.getString('mesaj_id');

            await interaction.deferReply({ ephemeral: true });

            const result = await giveawaySystem.end(interaction.channel, messageId);
            
            if (!result) {
                return interaction.editReply({
                    embeds: [embedUtil.error('Hata', 'Çekiliş bulunamadı veya zaten bitmiş!')]
                });
            }

            await interaction.editReply({
                embeds: [embedUtil.success('Çekiliş Bitirildi', 'Çekiliş başarıyla bitirildi!')]
            });

        } else if (subcommand === 'yenile') {
            const messageId = interaction.options.getString('mesaj_id');
            const count = interaction.options.getInteger('sayi') || 1;

            await interaction.deferReply({ ephemeral: true });

            const result = await giveawaySystem.reroll(interaction.channel, messageId, count);
            
            if (!result.success) {
                return interaction.editReply({
                    embeds: [embedUtil.error('Hata', result.message)]
                });
            }

            await interaction.editReply({
                embeds: [embedUtil.success('Yeniden Çekildi', `${count} yeni kazanan seçildi!`)]
            });
        }
    },

    async executePrefix(message, args, client) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return message.reply({
                embeds: [embedUtil.error('Yetki Hatası', 'Bu komutu kullanmak için yetkiniz yok!')]
            });
        }

        const subcommand = args[0]?.toLowerCase();

        if (!subcommand || subcommand === 'help') {
            return message.reply({
                embeds: [embedUtil.info('Çekiliş Komutları', 
                    '`.çekiliş başlat <ödül> <süre> [kazanan_sayısı]`\n' +
                    '`.çekiliş bitir <mesaj_id>`\n' +
                    '`.çekiliş yenile <mesaj_id> [sayı]`\n\n' +
                    'Süre formatı: 1d, 2h, 30m, 60s'
                )]
            });
        }

        if (subcommand === 'başlat' || subcommand === 'baslat') {
            // .çekiliş başlat Nitro 1d 1
            const prize = args[1];
            const durationStr = args[2];
            const winnerCount = parseInt(args[3]) || 1;

            if (!prize || !durationStr) {
                return message.reply({
                    embeds: [embedUtil.error('Hata', 'Kullanım: `.çekiliş başlat <ödül> <süre> [kazanan_sayısı]`')]
                });
            }

            const duration = giveawaySystem.parseDuration(durationStr);
            if (!duration) {
                return message.reply({
                    embeds: [embedUtil.error('Hata', 'Geçersiz süre formatı! Örnek: 1d, 2h, 30m')]
                });
            }

            const giveaway = await giveawaySystem.start(message.channel, {
                prize,
                duration,
                winnerCount
            }, message.author);

            const reply = await message.reply({
                embeds: [embedUtil.success('Çekiliş Başlatıldı', `**${prize}** için çekiliş başlatıldı!`)]
            });
            setTimeout(() => reply.delete().catch(() => {}), 5000);

        } else if (subcommand === 'bitir') {
            const messageId = args[1];
            if (!messageId) {
                return message.reply({
                    embeds: [embedUtil.error('Hata', 'Mesaj ID\'si belirtmelisiniz!')]
                });
            }

            const result = await giveawaySystem.end(message.channel, messageId);
            if (!result) {
                return message.reply({
                    embeds: [embedUtil.error('Hata', 'Çekiliş bulunamadı!')]
                });
            }

        } else if (subcommand === 'yenile') {
            const messageId = args[1];
            const count = parseInt(args[2]) || 1;

            if (!messageId) {
                return message.reply({
                    embeds: [embedUtil.error('Hata', 'Mesaj ID\'si belirtmelisiniz!')]
                });
            }

            await giveawaySystem.reroll(message.channel, messageId, count);
        }
    }
};
