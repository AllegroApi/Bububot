const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const game = require("../../game/sonHarf");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("oyunbitir")
    .setDescription("Son harf kelime oyununu bitirir")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  name: "oyunbitir",
  description: "Son harf kelime oyununu bitirir",

  async executeSlash(interaction) {
    if (!game.active) {
      return interaction.reply({
        content: "❌ Aktif bir oyun yok.",
        flags: 64
      });
    }

    // Sonuçları hesapla
    const sorted = Object.entries(game.scores)
      .sort((a, b) => b[1] - a[1]);

    let resultText = "🏁 **Oyun Bitti!**\n\n";
    
    if (sorted.length === 0) {
      resultText += "Kimse kelime yazmadı! 😅";
    } else {
      resultText += "🏆 **Final Sıralaması:**\n\n";
      for (let i = 0; i < Math.min(sorted.length, 10); i++) {
        const [id, score] = sorted[i];
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `**${i + 1}.**`;
        const user = await interaction.client.users.fetch(id).catch(() => null);
        resultText += `${medal} **${user?.username || 'Bilinmeyen'}** → ${score} kelime\n`;
      }
      resultText += `\n📊 Toplam ${game.usedWords.size} kelime yazıldı!`;
    }

    // Oyunu sıfırla
    game.active = false;
    game.channelId = null;
    game.lastWord = null;
    game.usedWords.clear();
    game.scores = {};

    await interaction.reply(resultText);
  },

  async executePrefix(message) {
    // Yetki kontrolü
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return message.reply("❌ Bu komutu kullanmak için yetkin yok.");
    }

    if (!game.active) {
      return message.reply("❌ Aktif bir oyun yok.");
    }

    // Sonuçları hesapla
    const sorted = Object.entries(game.scores)
      .sort((a, b) => b[1] - a[1]);

    let resultText = "🏁 **Oyun Bitti!**\n\n";
    
    if (sorted.length === 0) {
      resultText += "Kimse kelime yazmadı! 😅";
    } else {
      resultText += "🏆 **Final Sıralaması:**\n\n";
      for (let i = 0; i < Math.min(sorted.length, 10); i++) {
        const [id, score] = sorted[i];
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `**${i + 1}.**`;
        const user = await message.client.users.fetch(id).catch(() => null);
        resultText += `${medal} **${user?.username || 'Bilinmeyen'}** → ${score} kelime\n`;
      }
      resultText += `\n📊 Toplam ${game.usedWords.size} kelime yazıldı!`;
    }

    // Oyunu sıfırla
    game.active = false;
    game.channelId = null;
    game.lastWord = null;
    game.usedWords.clear();
    game.scores = {};

    await message.reply(resultText);
  }
};
