const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const embedUtil = require('../../utils/embed');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ship')
        .setDescription('İki kişi arasındaki aşk uyumunu hesapla')
        .addUserOption(option =>
            option.setName('kisi1')
                .setDescription('İlk kişi (boş bırakılırsa rastgele)')
                .setRequired(false))
        .addUserOption(option =>
            option.setName('kisi2')
                .setDescription('İkinci kişi (boş bırakılırsa rastgele)')
                .setRequired(false)),

    name: 'ship',
    description: 'İki kişi arasındaki aşk uyumunu hesapla',

    async executeSlash(interaction) {
        await interaction.deferReply();
        
        let user1 = interaction.options.getUser('kisi1');
        let user2 = interaction.options.getUser('kisi2');
        
        // Cache'den üyeleri al (daha hızlı)
        const humanMembers = interaction.guild.members.cache.filter(m => !m.user.bot);
        const memberArray = [...humanMembers.values()];
        
        if (memberArray.length < 2) {
            return interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Sunucuda yeterli üye yok!')]
            });
        }
        
        if (!user1) {
            const randomMember = memberArray[Math.floor(Math.random() * memberArray.length)];
            user1 = randomMember.user;
        }
        
        if (!user2) {
            // user1'den farklı birini seç
            let randomMember;
            do {
                randomMember = memberArray[Math.floor(Math.random() * memberArray.length)];
            } while (randomMember.user.id === user1.id && memberArray.length > 1);
            user2 = randomMember.user;
        }
        
        // Aynı kişiyse
        if (user1.id === user2.id) {
            return interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Kendini kendinle ship edemezsin! 🤦')]
            });
        }
        
        // Tutarlı yüzde hesapla (aynı çift her zaman aynı sonucu alır)
        const percentage = calculateShipPercentage(user1.id, user2.id);
        
        const embed = embedUtil.ship(user1, user2, percentage);
        
        await interaction.editReply({ embeds: [embed] });
    },

    async executePrefix(message, args) {
        const mentions = message.mentions.users;
        let user1, user2;
        
        const members = await message.guild.members.fetch();
        const humanMembers = members.filter(m => !m.user.bot);
        const memberArray = [...humanMembers.values()];
        
        if (mentions.size >= 2) {
            const usersArray = [...mentions.values()];
            user1 = usersArray[0];
            user2 = usersArray[1];
        } else if (mentions.size === 1) {
            user1 = mentions.first();
            // Rastgele ikinci kişi
            let randomMember;
            do {
                randomMember = memberArray[Math.floor(Math.random() * memberArray.length)];
            } while (randomMember.user.id === user1.id && memberArray.length > 1);
            user2 = randomMember.user;
        } else {
            // İki rastgele kişi
            const random1 = memberArray[Math.floor(Math.random() * memberArray.length)];
            let random2;
            do {
                random2 = memberArray[Math.floor(Math.random() * memberArray.length)];
            } while (random2.user.id === random1.user.id && memberArray.length > 1);
            
            user1 = random1.user;
            user2 = random2.user;
        }
        
        if (user1.id === user2.id) {
            return message.reply({
                embeds: [embedUtil.error('Hata', 'Kendini kendinle ship edemezsin! 🤦')]
            });
        }
        
        const percentage = calculateShipPercentage(user1.id, user2.id);
        const embed = embedUtil.ship(user1, user2, percentage);
        
        await message.reply({ embeds: [embed] });
    }
};

// Tutarlı yüzde hesaplama
function calculateShipPercentage(id1, id2) {
    // ID'leri sırala ki her zaman aynı sonuç çıksın
    const sortedIds = [id1, id2].sort();
    const combined = sortedIds.join('');
    
    // Basit hash fonksiyonu
    let hash = 0;
    for (let i = 0; i < combined.length; i++) {
        const char = combined.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // 32bit integer'a çevir
    }
    
    // 0-100 arasına normalize et
    return Math.abs(hash % 101);
}
