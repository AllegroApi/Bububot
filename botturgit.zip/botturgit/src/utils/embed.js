const { EmbedBuilder } = require('discord.js');
const config = require('../config/config.json');

const colors = config.colors || {
    primary: "#5865F2",
    success: "#57F287",
    warning: "#FEE75C",
    danger: "#ED4245",
    info: "#5865F2",
    pink: "#FF69B4",
    purple: "#9B59B6",
    gold: "#FFD700"
};

module.exports = {
    // Standart embed oluştur
    create(options = {}) {
        const embed = new EmbedBuilder()
            .setColor(options.color || colors.primary)
            .setTimestamp();
        
        if (options.title) embed.setTitle(options.title);
        if (options.description) embed.setDescription(options.description);
        if (options.footer) embed.setFooter({ text: options.footer });
        if (options.thumbnail) embed.setThumbnail(options.thumbnail);
        if (options.image) embed.setImage(options.image);
        if (options.author) embed.setAuthor(options.author);
        if (options.fields) embed.addFields(options.fields);
        
        return embed;
    },

    // Başarı embed
    success(title, description) {
        return new EmbedBuilder()
            .setColor(colors.success)
            .setTitle(`✅ ${title}`)
            .setDescription(description)
            .setTimestamp();
    },

    // Hata embed
    error(title, description) {
        return new EmbedBuilder()
            .setColor(colors.danger)
            .setTitle(`❌ ${title}`)
            .setDescription(description)
            .setTimestamp();
    },

    // Uyarı embed
    warning(title, description) {
        return new EmbedBuilder()
            .setColor(colors.warning)
            .setTitle(`⚠️ ${title}`)
            .setDescription(description)
            .setTimestamp();
    },

    // Bilgi embed
    info(title, description) {
        return new EmbedBuilder()
            .setColor(colors.info)
            .setTitle(`ℹ️ ${title}`)
            .setDescription(description)
            .setTimestamp();
    },

    // Seviye embed
    levelUp(user, level, rank) {
        return new EmbedBuilder()
            .setColor(colors.gold)
            .setTitle('🎉 SEVİYE ATLADIN!')
            .setDescription(`Tebrikler ${user}!`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: '📊 Yeni Seviye', value: `**${level}**`, inline: true },
                { name: '🏆 Sıralama', value: `**#${rank}**`, inline: true }
            )
            .setTimestamp();
    },

    // Profil embed
    profile(member, userData, rank) {
        const progress = userData.progress || { percentage: 0 };
        const progressBar = createProgressBar(progress.percentage);
        
        return new EmbedBuilder()
            .setColor(colors.purple)
            .setAuthor({ 
                name: member.user.tag, 
                iconURL: member.user.displayAvatarURL({ dynamic: true }) 
            })
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
            .addFields(
                { name: '📊 Seviye', value: `**${userData.level}**`, inline: true },
                { name: '⭐ XP', value: `**${userData.xp.toLocaleString()}**`, inline: true },
                { name: '🏆 Sıralama', value: `**#${rank}**`, inline: true },
                { name: '💬 Mesaj', value: `**${userData.messages.toLocaleString()}**`, inline: true },
                { name: '🎙️ Ses Süresi', value: formatVoiceTime(userData.voiceTime), inline: true },
                { name: '📈 İlerleme', value: `${progressBar} **${progress.percentage}%**`, inline: false }
            )
            .setFooter({ text: `Sonraki seviye için ${progress.needed - progress.current} XP gerekli` })
            .setTimestamp();
    },

    // Çekiliş embed
    giveaway(prize, host, endsAt, winnerCount, participants = 0) {
        const timeRemaining = Math.max(0, endsAt - Date.now());
        
        return new EmbedBuilder()
            .setColor(colors.pink)
            .setTitle('🎉 ÇEKİLİŞ!')
            .setDescription(`**Ödül:** ${prize}\n\n🎁 Katılmak için aşağıdaki 🎉 emojisine tıkla!`)
            .addFields(
                { name: '👤 Düzenleyen', value: `${host}`, inline: true },
                { name: '🏆 Kazanan Sayısı', value: `**${winnerCount}**`, inline: true },
                { name: '👥 Katılımcı', value: `**${participants}**`, inline: true },
                { name: '⏰ Bitiş', value: `<t:${Math.floor(endsAt / 1000)}:R>`, inline: false }
            )
            .setFooter({ text: 'Çekilişe katılmak için tepki ver!' })
            .setTimestamp(new Date(endsAt));
    },

    // Çekiliş bitti embed
    giveawayEnded(prize, winners, host) {
        const winnersText = winners.length > 0 
            ? winners.map(w => `<@${w}>`).join(', ')
            : 'Yeterli katılımcı yok!';
        
        return new EmbedBuilder()
            .setColor(colors.gold)
            .setTitle('🎉 ÇEKİLİŞ BİTTİ!')
            .setDescription(`**Ödül:** ${prize}`)
            .addFields(
                { name: '🏆 Kazanan(lar)', value: winnersText, inline: false },
                { name: '👤 Düzenleyen', value: `${host}`, inline: true }
            )
            .setFooter({ text: 'Kazananları tebrik edelim!' })
            .setTimestamp();
    },

    // Ticket embed
    ticket(ticketId, priority, user) {
        const priorityEmoji = { low: '🟢', medium: '🟡', high: '🔴' };
        const priorityName = { low: 'Düşük', medium: 'Orta', high: 'Yüksek' };
        
        return new EmbedBuilder()
            .setColor(priority === 'high' ? colors.danger : priority === 'medium' ? colors.warning : colors.success)
            .setTitle(`🎫 Destek Talebi #${ticketId}`)
            .setDescription(`Merhaba ${user}!\n\nDestek talebiniz oluşturuldu. Lütfen sorununuzu detaylı bir şekilde açıklayın. Ekibimiz en kısa sürede size yardımcı olacaktır.`)
            .addFields(
                { name: '📊 Öncelik', value: `${priorityEmoji[priority]} ${priorityName[priority]}`, inline: true },
                { name: '📅 Oluşturulma', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
            )
            .setFooter({ text: 'Ticket\'ı kapatmak için aşağıdaki butonu kullanın' })
            .setTimestamp();
    },

    // İtiraf embed
    confession(confessionId, content) {
        return new EmbedBuilder()
            .setColor(colors.purple)
            .setTitle(`🤫 İtiraf #${confessionId}`)
            .setDescription(content)
            .setFooter({ text: 'Anonim itiraf • Tepki vererek görüşünüzü bildirin' })
            .setTimestamp();
    },

    // Ship embed
    ship(user1, user2, percentage) {
        const heart = getShipHeart(percentage);
        const bar = createLoveBar(percentage);
        const comment = getShipComment(percentage);
        
        return new EmbedBuilder()
            .setColor(colors.pink)
            .setTitle(`${heart} Ship Sonucu ${heart}`)
            .setDescription(`**${user1.username}** 💕 **${user2.username}**`)
            .addFields(
                { name: 'Aşk Yüzdesi', value: `${bar} **${percentage}%**`, inline: false },
                { name: '💭 Yorum', value: comment, inline: false }
            )
            .setThumbnail('https://cdn.discordapp.com/emojis/1072786783823011860.gif')
            .setTimestamp();
    },

    // Log embed
    log(type, data) {
        const types = {
            tag: { emoji: '🏷️', color: colors.info, title: 'Tag Güncelleme' },
            boost: { emoji: '💎', color: colors.pink, title: 'Boost' },
            level: { emoji: '📊', color: colors.gold, title: 'Seviye' },
            punishment: { emoji: '⚖️', color: colors.danger, title: 'Ceza' },
            confession: { emoji: '🤫', color: colors.purple, title: 'İtiraf Log' },
            voice: { emoji: '🎙️', color: colors.info, title: 'Özel Oda' },
            ticket: { emoji: '🎫', color: colors.warning, title: 'Ticket' }
        };
        
        const typeData = types[type] || { emoji: '📝', color: colors.primary, title: 'Log' };
        
        return new EmbedBuilder()
            .setColor(typeData.color)
            .setTitle(`${typeData.emoji} ${typeData.title}`)
            .setDescription(data.description || null)
            .addFields(data.fields || [])
            .setFooter({ text: data.footer || 'Log Sistemi' })
            .setTimestamp();
    },

    // Panel embed (ticket, itiraf vb. için)
    panel(type, options = {}) {
        switch (type) {
            case 'ticket':
                return new EmbedBuilder()
                    .setColor(colors.primary)
                    .setTitle('🎫 Destek Merkezi')
                    .setDescription(
                        '**Merhaba!** Herhangi bir sorun, öneri veya şikayetiniz için destek talebi oluşturabilirsiniz.\n\n' +
                        '**Öncelik Seviyeleri:**\n' +
                        '🟢 **Düşük** - Genel sorular, öneriler\n' +
                        '🟡 **Orta** - Yardım gerektiren konular\n' +
                        '🔴 **Yüksek** - Acil durumlar, önemli sorunlar\n\n' +
                        '*Aşağıdaki butonlardan birine tıklayarak ticket açın!*'
                    )
                    .setImage(options.image || null)
                    .setFooter({ text: 'Spam ticket açmak yasaktır!' })
                    .setTimestamp();
            
            case 'confession':
                return new EmbedBuilder()
                    .setColor(colors.purple)
                    .setTitle('🤫 Anonim İtiraf')
                    .setDescription(
                        '**İçini dökmek mi istiyorsun?**\n\n' +
                        'Aşağıdaki butona tıklayarak anonim bir itiraf gönderebilirsin. ' +
                        'Kimliğin tamamen gizli kalacak, ancak kuralları ihlal eden itiraflar silinecektir.\n\n' +
                        '⚠️ *Hakaret, taciz veya zararlı içerik yasaktır!*'
                    )
                    .setFooter({ text: 'İtirafın sadece yetkililere görünür loglanır' })
                    .setTimestamp();
            
            case 'basvuru':
                return new EmbedBuilder()
                    .setColor(colors.gold)
                    .setTitle('📝 Yetkili Başvurusu')
                    .setDescription(
                        '**Ekibimize Katılmak İster Misin?**\n\n' +
                        'Sunucumuza katkıda bulunmak ve yetkili olmak için başvuru yapabilirsin!\n\n' +
                        '**Gereksinimler:**\n' +
                        '• En az 15 yaşında olmak\n' +
                        '• Sunucuda en az 1 hafta aktif olmak\n' +
                        '• Kurallara uyan ve saygılı olmak\n' +
                        '• Discord kullanım deneyimi\n\n' +
                        '*Başvurun incelendikten sonra seninle iletişime geçilecektir.*'
                    )
                    .setFooter({ text: 'Sahte bilgi veren başvurular reddedilir!' })
                    .setTimestamp();
            
            default:
                return new EmbedBuilder()
                    .setColor(colors.primary)
                    .setDescription(options.description || 'Panel');
        }
    }
};

// Yardımcı fonksiyonlar
function createProgressBar(percentage, length = 10) {
    const filled = Math.round((percentage / 100) * length);
    const empty = length - filled;
    return '█'.repeat(filled) + '░'.repeat(empty);
}

function createLoveBar(percentage, length = 10) {
    const filled = Math.round((percentage / 100) * length);
    const empty = length - filled;
    return '❤️'.repeat(filled) + '🖤'.repeat(empty);
}

function formatVoiceTime(ms) {
    if (!ms) return '0 dakika';
    const hours = Math.floor(ms / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    if (hours > 0) return `${hours} saat ${minutes} dk`;
    return `${minutes} dakika`;
}

function getShipHeart(percentage) {
    if (percentage >= 90) return '💖';
    if (percentage >= 70) return '💕';
    if (percentage >= 50) return '💗';
    if (percentage >= 30) return '💔';
    return '🖤';
}

function getShipComment(percentage) {
    const comments = {
        high: [
            'Birbirleri için yaratılmışlar! 💕',
            'Mükemmel bir çift olurlar! 😍',
            'Aşk havada kokuyor! 💖',
            'Bu aşk gerçek! 💗',
            'Evlilik yakın! 💒'
        ],
        medium: [
            'Potansiyel var! 🌟',
            'Arkadaşlıktan öte olabilir 👀',
            'Şans verilmeli! ✨',
            'İlginç bir kombinasyon 🤔',
            'Belki de evet? 💭'
        ],
        low: [
            'Sadece arkadaş kalsalar iyi olur 😅',
            'Pek uyumlu görünmüyorlar 🤷',
            'Farklı dünyalardan gibiler 🌍',
            'Friendzone! 👋',
            'Bir dahaki sefere artık... 😬'
        ]
    };
    
    let category;
    if (percentage >= 70) category = 'high';
    else if (percentage >= 40) category = 'medium';
    else category = 'low';
    
    return comments[category][Math.floor(Math.random() * comments[category].length)];
}
