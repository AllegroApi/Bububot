module.exports = {
  active: false,
  channelId: null,
  lastWord: null,
  usedWords: new Set(),
  scores: {}
};
