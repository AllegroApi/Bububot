const { 
    ChannelType, 
    PermissionFlagsBits,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder
} = require('discord.js');
const config = require('../config/config.json');
const PrivateVoiceModel = require('../models/PrivateVoice');
const embedUtil = require('../utils/embed');

module.exports = {
    name: 'privateVoiceSystem',
    
    // Ses kanalına girdiğinde
    async handleVoiceJoin(member, channel, client) {
        if (!config.privateVoice?.enabled) return;
        
        // Oluşturma kanalına mı girdi?
        if (channel.id === config.privateVoice.createChannelId) {
            await this.createPrivateRoom(member, client);
        } else {
            // Başkasının odasına girmeye çalışıyor mu?
            const room = PrivateVoiceModel.get(channel.id);
            if (room && !PrivateVoiceModel.canJoin(channel.id, member.id)) {
                // Kullanıcıyı at
                await member.voice.disconnect();
                
                try {
                    await member.send({
                        embeds: [embedUtil.error('Erişim Engellendi', 'Bu özel odaya girme izniniz yok!')]
                    });
                } catch (e) {}
            }
        }
    },

    // Ses kanalından çıktığında
    async handleVoiceLeave(member, channel, client) {
        if (!config.privateVoice?.enabled) return;
        
        const room = PrivateVoiceModel.get(channel.id);
        if (!room) return;
        
        // Kanal boş mu kontrol et
        const voiceChannel = client.channels.cache.get(channel.id);
        if (!voiceChannel) return;
        
        // Kanal boşsa sil
        if (voiceChannel.members.size === 0) {
            await this.deletePrivateRoom(channel.id, client);
        }
    },

    // Özel oda oluştur
    async createPrivateRoom(member, client) {
        // Zaten odası var mı kontrol et
        const existingRoom = PrivateVoiceModel.getByOwner(member.id, member.guild.id);
        if (existingRoom) {
            // Mevcut odasına taşı
            const existingChannel = client.channels.cache.get(existingRoom.channelId);
            if (existingChannel) {
                await member.voice.setChannel(existingChannel);
                return;
            } else {
                // Kanal silinmiş, veritabanından da sil
                PrivateVoiceModel.delete(existingRoom.channelId);
            }
        }
        
        const categoryId = config.privateVoice.categoryId;
        const category = client.channels.cache.get(categoryId);
        
        try {
            // Ses kanalı oluştur
            const channel = await member.guild.channels.create({
                name: `🔊 ${member.user.username}'ın Odası`,
                type: ChannelType.GuildVoice,
                parent: category,
                permissionOverwrites: [
                    {
                        id: member.guild.id,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect]
                    },
                    {
                        id: member.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.Connect,
                            PermissionFlagsBits.ManageChannels,
                            PermissionFlagsBits.MoveMembers,
                            PermissionFlagsBits.MuteMembers,
                            PermissionFlagsBits.DeafenMembers
                        ]
                    }
                ],
                userLimit: 0,
                bitrate: 64000
            });
            
            // Veritabanına kaydet
            PrivateVoiceModel.create({
                channelId: channel.id,
                guildId: member.guild.id,
                ownerId: member.id,
                ownerTag: member.user.tag,
                name: channel.name
            });
            
            // Kullanıcıyı kanala taşı
            await member.voice.setChannel(channel);
            
            // Kontrol paneli gönder
            await this.sendControlPanel(member, channel, client);
            
            // Log
            await this.sendLog(client, member, channel, 'create');
            
        } catch (error) {
            console.error('Özel oda oluşturma hatası:', error);
        }
    },

    // Kontrol paneli gönder
    async sendControlPanel(member, channel, client) {
        try {
            const embed = embedUtil.create({
                color: '#5865F2',
                title: '🎙️ Özel Oda Kontrol Paneli',
                description: `Merhaba ${member}! Odanız başarıyla oluşturuldu.\n\nAşağıdaki butonları kullanarak odanızı yönetebilirsiniz.`,
                fields: [
                    { name: '🔒 Kilitle/Aç', value: 'Odaya girişi kısıtla', inline: true },
                    { name: '👤 Limit', value: 'Kullanıcı limitini ayarla', inline: true },
                    { name: '✏️ İsim', value: 'Oda ismini değiştir', inline: true },
                    { name: '👥 İzin Ver', value: 'Kullanıcıya erişim izni ver', inline: true },
                    { name: '🚫 Yasakla', value: 'Kullanıcıyı engelle', inline: true },
                    { name: '👑 Devret', value: 'Sahipliği devret', inline: true }
                ],
                footer: 'Odadan herkes çıkınca kanal otomatik silinir'
            });
            
            const row1 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('pv_lock')
                        .setLabel('Kilitle/Aç')
                        .setEmoji('🔒')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('pv_limit')
                        .setLabel('Limit')
                        .setEmoji('👤')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('pv_rename')
                        .setLabel('İsim')
                        .setEmoji('✏️')
                        .setStyle(ButtonStyle.Primary)
                );
            
            const row2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('pv_allow')
                        .setLabel('İzin Ver')
                        .setEmoji('👥')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('pv_block')
                        .setLabel('Yasakla')
                        .setEmoji('🚫')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('pv_kick')
                        .setLabel('At')
                        .setEmoji('👢')
                        .setStyle(ButtonStyle.Danger)
                );
            
            const row3 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('pv_transfer')
                        .setLabel('Sahipliği Devret')
                        .setEmoji('👑')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('pv_delete')
                        .setLabel('Odayı Sil')
                        .setEmoji('🗑️')
                        .setStyle(ButtonStyle.Danger)
                );
            
            await member.send({ embeds: [embed], components: [row1, row2, row3] });
        } catch (error) {
            // DM kapalı olabilir
        }
    },

    // Özel odayı sil
    async deletePrivateRoom(channelId, client) {
        const room = PrivateVoiceModel.get(channelId);
        if (!room) return;
        
        try {
            const channel = client.channels.cache.get(channelId);
            if (channel) {
                await channel.delete();
            }
            
            PrivateVoiceModel.delete(channelId);
            
        } catch (error) {
            console.error('Özel oda silme hatası:', error);
        }
    },

    // Oda işlemleri
    async lockRoom(channelId, client) {
        const room = PrivateVoiceModel.toggleLock(channelId);
        if (!room) return null;
        
        const channel = client.channels.cache.get(channelId);
        if (channel) {
            await channel.permissionOverwrites.edit(channel.guild.id, {
                Connect: room.settings.locked ? false : true
            });
        }
        
        return room;
    },

    async setLimit(channelId, limit, client) {
        const room = PrivateVoiceModel.updateSettings(channelId, { userLimit: limit });
        if (!room) return null;
        
        const channel = client.channels.cache.get(channelId);
        if (channel) {
            await channel.setUserLimit(limit);
        }
        
        return room;
    },

    async renameRoom(channelId, name, client) {
        const room = PrivateVoiceModel.update(channelId, { name });
        if (!room) return null;
        
        const channel = client.channels.cache.get(channelId);
        if (channel) {
            await channel.setName(name);
        }
        
        return room;
    },

    async allowUser(channelId, userId, client) {
        const room = PrivateVoiceModel.allowUser(channelId, userId);
        if (!room) return null;
        
        const channel = client.channels.cache.get(channelId);
        if (channel) {
            await channel.permissionOverwrites.edit(userId, {
                Connect: true,
                ViewChannel: true
            });
        }
        
        return room;
    },

    async blockUser(channelId, userId, client) {
        const room = PrivateVoiceModel.blockUser(channelId, userId);
        if (!room) return null;
        
        const channel = client.channels.cache.get(channelId);
        if (channel) {
            await channel.permissionOverwrites.edit(userId, {
                Connect: false,
                ViewChannel: false
            });
            
            // Kanalda ise at
            const member = channel.members.get(userId);
            if (member) {
                await member.voice.disconnect();
            }
        }
        
        return room;
    },

    async kickUser(channelId, userId, client) {
        const channel = client.channels.cache.get(channelId);
        if (channel) {
            const member = channel.members.get(userId);
            if (member) {
                await member.voice.disconnect();
            }
        }
    },

    async transferOwnership(channelId, newOwnerId, client) {
        const channel = client.channels.cache.get(channelId);
        if (!channel) return null;
        
        const newOwner = await channel.guild.members.fetch(newOwnerId);
        if (!newOwner) return null;
        
        const room = PrivateVoiceModel.transferOwnership(channelId, newOwnerId, newOwner.user.tag);
        if (!room) return null;
        
        // Kanal ismini güncelle
        await channel.setName(`🔊 ${newOwner.user.username}'ın Odası`);
        
        // Yetkileri güncelle
        await channel.permissionOverwrites.edit(newOwnerId, {
            ViewChannel: true,
            Connect: true,
            ManageChannels: true,
            MoveMembers: true,
            MuteMembers: true,
            DeafenMembers: true
        });
        
        return room;
    },

    // Log gönder
    async sendLog(client, member, channel, action) {
        const logChannelId = config.privateVoice.logChannelId;
        if (!logChannelId) return;
        
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;
        
        const actionTexts = {
            create: '✅ Oluşturuldu',
            delete: '🗑️ Silindi',
            lock: '🔒 Kilitlendi',
            unlock: '🔓 Kilit Açıldı'
        };
        
        const embed = embedUtil.log('voice', {
            fields: [
                { name: '👤 Kullanıcı', value: `${member} (${member.user.tag})`, inline: true },
                { name: '🎙️ Kanal', value: channel.name, inline: true },
                { name: '🎯 İşlem', value: actionTexts[action] || action, inline: true },
                { name: '📅 Tarih', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
            ],
            footer: `Kanal ID: ${channel.id}`
        });
        
        await logChannel.send({ embeds: [embed] });
    },

    // Boş odaları temizle
    async cleanEmptyRooms(client) {
        const allRooms = PrivateVoiceModel.getAll();
        
        for (const room of allRooms) {
            const channel = client.channels.cache.get(room.channelId);
            
            if (!channel) {
                // Kanal silinmiş
                PrivateVoiceModel.delete(room.channelId);
            } else if (channel.members.size === 0) {
                // Kanal boş
                await this.deletePrivateRoom(room.channelId, client);
            }
        }
    }
};
