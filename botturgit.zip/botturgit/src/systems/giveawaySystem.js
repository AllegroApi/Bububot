const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config/config.json');
const GiveawayModel = require('../models/Giveaway');
const embedUtil = require('../utils/embed');

// Aktif interval'lar
const checkIntervals = new Map();

module.exports = {
    name: 'giveawaySystem',
    
    // Çekiliş başlat
    async start(channel, options, host) {
        const { prize, duration, winnerCount = 1, requiredRoleId } = options;
        
        const endsAt = Date.now() + duration;
        
        const embed = embedUtil.giveaway(prize, host, endsAt, winnerCount, 0);
        
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('giveaway_join')
                    .setLabel('Katıl')
                    .setEmoji('🎉')
                    .setStyle(ButtonStyle.Primary)
            );
        
        const message = await channel.send({ 
            embeds: [embed],
            components: [row]
        });
        
        // Emoji tepkisi de ekle (alternatif katılım)
        await message.react(config.giveaway?.emoji || '🎉');
        
        // Veritabanına kaydet
        const giveaway = GiveawayModel.create({
            messageId: message.id,
            channelId: channel.id,
            guildId: channel.guild.id,
            prize,
            winnerCount,
            hostId: host.id,
            hostTag: host.tag,
            endsAt,
            requiredRoleId
        });
        
        // Interval başlat
        this.startCheckInterval(message, giveaway);
        
        return giveaway;
    },

    // Çekiliş kontrolü interval
    startCheckInterval(message, giveaway) {
        const intervalId = setInterval(async () => {
            const current = GiveawayModel.get(giveaway.messageId);
            
            if (!current || current.ended) {
                clearInterval(intervalId);
                checkIntervals.delete(giveaway.messageId);
                return;
            }
            
            // Süre doldu mu?
            if (Date.now() >= current.endsAt) {
                clearInterval(intervalId);
                checkIntervals.delete(giveaway.messageId);
                await this.end(message.channel, giveaway.messageId);
                return;
            }
            
            // Embed'i güncelle
            try {
                const embed = embedUtil.giveaway(
                    current.prize, 
                    `<@${current.hostId}>`, 
                    current.endsAt, 
                    current.winnerCount,
                    current.participants.length
                );
                await message.edit({ embeds: [embed] });
            } catch (e) {}
            
        }, 30000); // 30 saniyede bir güncelle
        
        checkIntervals.set(giveaway.messageId, intervalId);
    },

    // Çekilişe katıl
    async join(messageId, userId, member) {
        const giveaway = GiveawayModel.get(messageId);
        
        if (!giveaway) return { success: false, message: 'Çekiliş bulunamadı!' };
        if (giveaway.ended) return { success: false, message: 'Bu çekiliş sona erdi!' };
        
        // Rol kontrolü
        if (giveaway.requiredRoleId) {
            if (!member.roles.cache.has(giveaway.requiredRoleId)) {
                return { success: false, message: 'Bu çekilişe katılmak için gerekli role sahip değilsin!' };
            }
        }
        
        // Zaten katılmış mı?
        if (giveaway.participants.includes(userId)) {
            return { success: false, message: 'Zaten bu çekilişe katıldın!' };
        }
        
        GiveawayModel.addParticipant(messageId, userId);
        return { success: true, message: 'Çekilişe başarıyla katıldın! 🎉' };
    },

    // Çekilişten ayrıl
    async leave(messageId, userId) {
        const giveaway = GiveawayModel.get(messageId);
        
        if (!giveaway) return { success: false, message: 'Çekiliş bulunamadı!' };
        if (giveaway.ended) return { success: false, message: 'Bu çekiliş sona erdi!' };
        
        GiveawayModel.removeParticipant(messageId, userId);
        return { success: true, message: 'Çekilişten ayrıldın.' };
    },

    // Çekilişi bitir
    async end(channel, messageId) {
        const giveaway = GiveawayModel.end(messageId);
        
        if (!giveaway) return null;
        
        try {
            const message = await channel.messages.fetch(messageId);
            
            const embed = embedUtil.giveawayEnded(
                giveaway.prize,
                giveaway.winners,
                `<@${giveaway.hostId}>`
            );
            
            const disabledRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('giveaway_ended')
                        .setLabel('Çekiliş Bitti!')
                        .setEmoji('🎉')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(true)
                );
            
            await message.edit({ embeds: [embed], components: [disabledRow] });
            
            // Kazananları etiketle
            if (giveaway.winners.length > 0) {
                const winnersText = giveaway.winners.map(w => `<@${w}>`).join(', ');
                await channel.send({
                    content: `🎉 Tebrikler ${winnersText}! **${giveaway.prize}** kazandınız!\n<@${giveaway.hostId}> ile iletişime geçin.`
                });
            } else {
                await channel.send({
                    content: `😢 Yeterli katılımcı olmadığından çekiliş iptal edildi.`
                });
            }
            
        } catch (error) {
            console.error('Çekiliş bitirme hatası:', error);
        }
        
        return giveaway;
    },

    // Yeniden çekiliş yap
    async reroll(channel, messageId, count = 1) {
        const newWinners = GiveawayModel.reroll(messageId, count);
        
        if (!newWinners || newWinners.length === 0) {
            return { success: false, message: 'Yeniden çekiliş yapılamadı!' };
        }
        
        const winnersText = newWinners.map(w => `<@${w}>`).join(', ');
        await channel.send({
            content: `🎉 Yeni kazanan(lar): ${winnersText}`
        });
        
        return { success: true, winners: newWinners };
    },

    // Bot başlatıldığında aktif çekilişleri yükle
    async loadActiveGiveaways(client) {
        const activeGiveaways = GiveawayModel.getActive();
        
        for (const giveaway of activeGiveaways) {
            try {
                const channel = await client.channels.fetch(giveaway.channelId);
                const message = await channel.messages.fetch(giveaway.messageId);
                
                // Interval başlat
                this.startCheckInterval(message, giveaway);
                
            } catch (error) {
                // Mesaj veya kanal silinmişse çekilişi bitir
                GiveawayModel.end(giveaway.messageId);
            }
        }
        
        // Süresi dolmuş ama bitirilmemiş çekilişleri bitir
        const expiredGiveaways = GiveawayModel.getExpired();
        
        for (const giveaway of expiredGiveaways) {
            try {
                const channel = await client.channels.fetch(giveaway.channelId);
                await this.end(channel, giveaway.messageId);
            } catch (error) {
                GiveawayModel.end(giveaway.messageId);
            }
        }
        
        console.log(`✅ ${activeGiveaways.length} aktif çekiliş yüklendi.`);
    },

    // Süre parse et (1d, 2h, 30m vb.)
    parseDuration(durationStr) {
        const regex = /^(\d+)([smhd])$/i;
        const match = durationStr.match(regex);
        
        if (!match) return null;
        
        const amount = parseInt(match[1]);
        const unit = match[2].toLowerCase();
        
        const multipliers = {
            's': 1000,
            'm': 60 * 1000,
            'h': 60 * 60 * 1000,
            'd': 24 * 60 * 60 * 1000
        };
        
        return amount * multipliers[unit];
    }
};
