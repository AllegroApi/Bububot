const { Collection, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config/config.json');

// Kullanıcıların mesaj geçmişini saklayacak
const userMessages = new Collection();
const warnedUsers = new Collection();
const mutedUsers = new Collection();

module.exports = {
    name: 'antiSpam',

    // Ayarlar
    settings: {
        enabled: true,
        messageLimit: 5,          // Maksimum mesaj sayısı
        timeframe: 5000,          // Süre (ms)
        duplicateLimit: 3,        // Aynı mesajdan kaç tane
        warnThreshold: 2,         // Kaç ihlalde uyarı
        muteThreshold: 3,         // Kaç ihlalde mute
        muteDuration: 300000,     // Mute süresi (5 dakika)
        ignoredRoles: [],         // Muaf roller
        ignoredChannels: []       // Muaf kanallar
    },

    // Mesaj kontrolü
    async checkMessage(message, client) {
        if (!this.settings.enabled) return { spam: false };
        if (message.author.bot) return { spam: false };
        if (!message.guild) return { spam: false };

        // Yetkili kontrolü
        if (message.member?.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return { spam: false };
        }

        // Muaf rol kontrolü
        if (this.settings.ignoredRoles.some(roleId => message.member?.roles.cache.has(roleId))) {
            return { spam: false };
        }

        // Muaf kanal kontrolü
        if (this.settings.ignoredChannels.includes(message.channel.id)) {
            return { spam: false };
        }

        const userId = message.author.id;
        const now = Date.now();

        // Kullanıcı verisi al
        if (!userMessages.has(userId)) {
            userMessages.set(userId, { messages: [], violations: 0, lastViolation: 0 });
        }

        const userData = userMessages.get(userId);

        // Mesajı kaydet
        userData.messages.push({
            content: message.content,
            time: now,
            channelId: message.channel.id
        });

        // Eski mesajları temizle
        userData.messages = userData.messages.filter(m => now - m.time < this.settings.timeframe);

        // Spam kontrolü
        let isSpam = false;
        let reason = '';

        // 1. Çok hızlı mesaj
        if (userData.messages.length >= this.settings.messageLimit) {
            isSpam = true;
            reason = 'Çok hızlı mesaj gönderimi';
        }

        // 2. Aynı mesajı tekrarlama
        const duplicates = userData.messages.filter(m => m.content === message.content);
        if (duplicates.length >= this.settings.duplicateLimit) {
            isSpam = true;
            reason = 'Aynı mesajı tekrarlama';
        }

        // 3. Caps lock kontrolü (80%+ büyük harf)
        if (message.content.length > 10) {
            const uppercase = message.content.replace(/[^A-ZÇĞİÖŞÜ]/g, '').length;
            const total = message.content.replace(/[^a-zA-ZçğıöşüÇĞİÖŞÜ]/g, '').length;
            if (total > 0 && (uppercase / total) > 0.8) {
                isSpam = true;
                reason = 'Aşırı büyük harf kullanımı';
            }
        }

        // 4. Emoji spam
        const emojiCount = (message.content.match(/<a?:\w+:\d+>|[\u{1F300}-\u{1F9FF}]/gu) || []).length;
        if (emojiCount > 10) {
            isSpam = true;
            reason = 'Aşırı emoji kullanımı';
        }

        // 5. Mention spam
        if (message.mentions.users.size + message.mentions.roles.size > 5) {
            isSpam = true;
            reason = 'Aşırı etiketleme';
        }

        if (isSpam) {
            userData.violations++;
            userData.lastViolation = now;

            // Mesajı sil
            try {
                await message.delete();
            } catch (e) {}

            // Aksiyon al
            await this.takeAction(message, client, userData.violations, reason);

            return { spam: true, reason, violations: userData.violations };
        }

        return { spam: false };
    },

    // Aksiyon al
    async takeAction(message, client, violations, reason) {
        const member = message.member;
        if (!member) return;

        // Log için embed
        const logEmbed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('⚠️ Spam Tespit Edildi')
            .addFields(
                { name: '👤 Kullanıcı', value: `${message.author} (${message.author.id})`, inline: true },
                { name: '📍 Kanal', value: `${message.channel}`, inline: true },
                { name: '📝 Sebep', value: reason, inline: true },
                { name: '⚡ İhlal Sayısı', value: `${violations}`, inline: true }
            )
            .setTimestamp();

        // Uyarı
        if (violations >= this.settings.warnThreshold && violations < this.settings.muteThreshold) {
            try {
                await message.channel.send({
                    content: `⚠️ ${message.author}, **spam yapmayı bırak!** (${violations}. uyarı)\nSebep: ${reason}`,
                }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
            } catch (e) {}
            
            logEmbed.addFields({ name: '🔨 Aksiyon', value: 'Uyarı', inline: true });
        }

        // Mute
        if (violations >= this.settings.muteThreshold) {
            try {
                await member.timeout(this.settings.muteDuration, `Anti-Spam: ${reason}`);
                
                await message.channel.send({
                    content: `🔇 ${message.author} spam yaptığı için **${this.settings.muteDuration / 60000} dakika** susturuldu!`,
                }).then(m => setTimeout(() => m.delete().catch(() => {}), 10000));
                
                // Violation sıfırla
                const userData = userMessages.get(message.author.id);
                if (userData) userData.violations = 0;
                
                logEmbed.setColor('#ED4245');
                logEmbed.addFields({ name: '🔨 Aksiyon', value: `${this.settings.muteDuration / 60000} dk Mute`, inline: true });
            } catch (e) {
                console.error('Mute hatası:', e.message);
            }
        }

        // Log gönder
        const logChannelId = config.logs?.channelId;
        if (logChannelId && logChannelId !== 'LOG_CHANNEL_ID') {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
            }
        }
    },

    // Kullanıcı verisini temizle
    clearUser(userId) {
        userMessages.delete(userId);
        warnedUsers.delete(userId);
    },

    // Tüm veriyi temizle
    clearAll() {
        userMessages.clear();
        warnedUsers.clear();
        mutedUsers.clear();
    }
};