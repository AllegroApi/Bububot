const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config/config.json');

// Raid takip verileri
const joinTracker = new Map(); // guildId -> [{ userId, joinedAt }]
const actionTracker = new Map(); // guildId -> { locked: boolean, lockedAt: number }

module.exports = {
    name: 'antiRaid',

    // Ayarlar
    settings: {
        enabled: true,
        joinLimit: 10,           // Bu kadar kişi katılırsa
        joinTimeframe: 10000,    // Bu süre içinde (ms)
        accountAgeDays: 7,       // Hesap yaşı bu günden az ise şüpheli
        lockdownDuration: 300000, // Lockdown süresi (5 dakika)
        action: 'kick'           // kick, ban, timeout
    },

    // Üye katıldığında kontrol
    async checkJoin(member, client) {
        if (!this.settings.enabled) return { safe: true };
        
        const guildId = member.guild.id;
        const now = Date.now();
        
        // Takip listesini al veya oluştur
        if (!joinTracker.has(guildId)) {
            joinTracker.set(guildId, []);
        }
        
        const joins = joinTracker.get(guildId);
        
        // Yeni katılımı ekle
        joins.push({
            userId: member.id,
            joinedAt: now,
            accountAge: now - member.user.createdTimestamp
        });
        
        // Eski kayıtları temizle
        const recentJoins = joins.filter(j => now - j.joinedAt < this.settings.joinTimeframe);
        joinTracker.set(guildId, recentJoins);
        
        // Raid kontrolü
        if (recentJoins.length >= this.settings.joinLimit) {
            await this.triggerRaidMode(member.guild, client, recentJoins);
            return { safe: false, reason: 'raid_detected' };
        }
        
        // Hesap yaşı kontrolü
        const accountAgeDays = (now - member.user.createdTimestamp) / (1000 * 60 * 60 * 24);
        if (accountAgeDays < this.settings.accountAgeDays) {
            return { safe: false, reason: 'new_account', accountAge: accountAgeDays };
        }
        
        return { safe: true };
    },

    // Raid modu tetikle
    async triggerRaidMode(guild, client, recentJoins) {
        const guildId = guild.id;
        
        // Zaten lockdown'daysa çık
        const action = actionTracker.get(guildId);
        if (action?.locked) return;
        
        // Lockdown başlat
        actionTracker.set(guildId, { locked: true, lockedAt: Date.now() });
        
        console.log(`🚨 RAID ALGILANDI: ${guild.name} - ${recentJoins.length} kişi hızlı katılım!`);
        
        // Log gönder
        const logSystem = require('./logSystem');
        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🚨 RAİD ALARMI!')
            .setDescription(
                `**${recentJoins.length}** kişi çok kısa sürede katıldı!\n\n` +
                `⚠️ **Otomatik koruma aktif!**`
            )
            .addFields(
                { name: '👥 Şüpheli Hesaplar', value: recentJoins.slice(0, 10).map(j => `<@${j.userId}>`).join(', ') || 'Yok', inline: false },
                { name: '⏰ Lockdown Süresi', value: `${this.settings.lockdownDuration / 60000} dakika`, inline: true },
                { name: '🔨 Aksiyon', value: this.settings.action.toUpperCase(), inline: true }
            )
            .setTimestamp();

        const logChannelId = config.logs?.channelId;
        if (logChannelId && logChannelId !== 'LOG_CHANNEL_ID') {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                await logChannel.send({ embeds: [embed] });
            }
        }

        // Şüpheli hesaplara aksiyon al
        for (const join of recentJoins) {
            try {
                const member = await guild.members.fetch(join.userId).catch(() => null);
                if (!member) continue;
                
                switch (this.settings.action) {
                    case 'kick':
                        await member.kick('Anti-Raid: Toplu katılım tespit edildi');
                        break;
                    case 'ban':
                        await member.ban({ reason: 'Anti-Raid: Toplu katılım tespit edildi', deleteMessageSeconds: 86400 });
                        break;
                    case 'timeout':
                        await member.timeout(this.settings.lockdownDuration, 'Anti-Raid: Toplu katılım tespit edildi');
                        break;
                }
            } catch (err) {
                console.error(`Raid aksiyonu başarısız (${join.userId}):`, err.message);
            }
        }

        // Lockdown'ı otomatik kaldır
        setTimeout(() => {
            actionTracker.set(guildId, { locked: false, lockedAt: null });
            console.log(`✅ Lockdown kaldırıldı: ${guild.name}`);
        }, this.settings.lockdownDuration);
    },

    // Manuel lockdown
    async enableLockdown(guild, duration = 300000) {
        actionTracker.set(guild.id, { locked: true, lockedAt: Date.now() });
        
        // Tüm kanalları kilitle
        for (const [, channel] of guild.channels.cache) {
            if (channel.isTextBased() && channel.permissionsFor(guild.roles.everyone)) {
                try {
                    await channel.permissionOverwrites.edit(guild.roles.everyone, {
                        SendMessages: false
                    });
                } catch (e) {}
            }
        }

        // Otomatik aç
        setTimeout(() => this.disableLockdown(guild), duration);
        
        return true;
    },

    // Lockdown kaldır
    async disableLockdown(guild) {
        actionTracker.set(guild.id, { locked: false, lockedAt: null });
        
        // Kanalları aç
        for (const [, channel] of guild.channels.cache) {
            if (channel.isTextBased() && channel.permissionsFor(guild.roles.everyone)) {
                try {
                    await channel.permissionOverwrites.edit(guild.roles.everyone, {
                        SendMessages: null
                    });
                } catch (e) {}
            }
        }
        
        return true;
    },

    // Durum kontrolü
    isLocked(guildId) {
        return actionTracker.get(guildId)?.locked || false;
    }
};
