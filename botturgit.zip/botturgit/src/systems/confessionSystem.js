const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config/config.json');
const ConfessionModel = require('../models/Confession');
const embedUtil = require('../utils/embed');

module.exports = {
    name: 'confessionSystem',
    
    // İtiraf paneli gönder
    async sendPanel(channel) {
        const embed = embedUtil.panel('confession');
        
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('confession_create')
                    .setLabel('İtiraf Et')
                    .setEmoji('🤫')
                    .setStyle(ButtonStyle.Primary)
            );
        
        await channel.send({ embeds: [embed], components: [row] });
    },

    // İtiraf oluştur
    async create(userId, userTag, guildId, content, client) {
        if (!config.confession?.enabled) return { success: false, message: 'İtiraf sistemi devre dışı!' };
        
        // İçerik kontrolü
        if (content.length < 10) {
            return { success: false, message: 'İtiraf en az 10 karakter olmalı!' };
        }
        if (content.length > 1000) {
            return { success: false, message: 'İtiraf en fazla 1000 karakter olabilir!' };
        }
        
        // Yasaklı kelime kontrolü (basit)
        const bannedWords = ['discord.gg', 'http://', 'https://'];
        if (bannedWords.some(word => content.toLowerCase().includes(word))) {
            return { success: false, message: 'İtiraflarda link paylaşımı yasaktır!' };
        }
        
        try {
            // İtiraf oluştur
            const confession = ConfessionModel.create({
                content,
                authorId: userId,
                authorTag: userTag,
                guildId
            });
            
            // İtiraf kanalına gönder
            const confessionChannelId = config.confession.channelId;
            const confessionChannel = client.channels.cache.get(confessionChannelId);
            
            if (confessionChannel) {
                const embed = embedUtil.confession(confession.id, content);
                
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`confession_like_${confession.id}`)
                            .setLabel('0')
                            .setEmoji('❤️')
                            .setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder()
                            .setCustomId(`confession_dislike_${confession.id}`)
                            .setLabel('0')
                            .setEmoji('💔')
                            .setStyle(ButtonStyle.Secondary)
                    );
                
                const message = await confessionChannel.send({ embeds: [embed], components: [row] });
                
                // Mesaj ID'sini kaydet
                ConfessionModel.setMessageId(confession.id, message.id);
            }
            
            // Log gönder
            await this.sendLog(client, confession);
            
            return { success: true, confession };
            
        } catch (error) {
            console.error('İtiraf oluşturma hatası:', error);
            return { success: false, message: 'İtiraf gönderilirken bir hata oluştu!' };
        }
    },

    // Reaksiyon güncelle
    async updateReaction(confessionId, type, increment, client) {
        const confession = ConfessionModel.updateReaction(confessionId, type, increment);
        if (!confession) return;
        
        try {
            const confessionChannelId = config.confession.channelId;
            const confessionChannel = client.channels.cache.get(confessionChannelId);
            
            if (confessionChannel && confession.messageId) {
                const message = await confessionChannel.messages.fetch(confession.messageId);
                
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`confession_like_${confession.id}`)
                            .setLabel(confession.reactions.likes.toString())
                            .setEmoji('❤️')
                            .setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder()
                            .setCustomId(`confession_dislike_${confession.id}`)
                            .setLabel(confession.reactions.dislikes.toString())
                            .setEmoji('💔')
                            .setStyle(ButtonStyle.Secondary)
                    );
                
                await message.edit({ components: [row] });
            }
        } catch (error) {
            // Mesaj silinmiş olabilir
        }
    },

    // İtiraf sil (yetkili komutu)
    async delete(confessionId, client) {
        const confession = ConfessionModel.get(confessionId);
        if (!confession) return { success: false, message: 'İtiraf bulunamadı!' };
        
        try {
            const confessionChannelId = config.confession.channelId;
            const confessionChannel = client.channels.cache.get(confessionChannelId);
            
            if (confessionChannel && confession.messageId) {
                try {
                    const message = await confessionChannel.messages.fetch(confession.messageId);
                    await message.delete();
                } catch (e) {}
            }
            
            ConfessionModel.delete(confessionId);
            
            return { success: true };
        } catch (error) {
            return { success: false, message: 'İtiraf silinirken bir hata oluştu!' };
        }
    },

    // İtiraf sahibini bul (yetkili komutu)
    findAuthor(confessionId) {
        return ConfessionModel.findAuthor(confessionId);
    },

    // Log gönder
    async sendLog(client, confession) {
        const logChannelId = config.confession.logChannelId;
        if (!logChannelId) return;
        
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;
        
        const embed = embedUtil.log('confession', {
            description: confession.content.substring(0, 500) + (confession.content.length > 500 ? '...' : ''),
            fields: [
                { name: '🆔 İtiraf No', value: `#${confession.id}`, inline: true },
                { name: '👤 Yazan', value: `${confession.authorTag} (<@${confession.authorId}>)`, inline: true },
                { name: '📅 Tarih', value: `<t:${Math.floor(confession.createdAt / 1000)}:F>`, inline: false }
            ],
            footer: `Kullanıcı ID: ${confession.authorId}`
        });
        
        await logChannel.send({ embeds: [embed] });
    }
};
