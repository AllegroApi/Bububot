const { 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    ChannelType,
    PermissionFlagsBits
} = require('discord.js');
const config = require('../config/config.json');
const TicketModel = require('../models/Ticket');
const embedUtil = require('../utils/embed');

module.exports = {
    name: 'ticketSystem',
    
    // Ticket paneli gönder
    async sendPanel(channel) {
        const embed = embedUtil.panel('ticket');
        
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_create_low')
                    .setLabel('Düşük')
                    .setEmoji('🟢')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('ticket_create_medium')
                    .setLabel('Orta')
                    .setEmoji('🟡')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('ticket_create_high')
                    .setLabel('Yüksek')
                    .setEmoji('🔴')
                    .setStyle(ButtonStyle.Danger)
            );
        
        await channel.send({ embeds: [embed], components: [row] });
    },

    // Ticket oluştur
    async create(member, priority, client) {
        if (!config.ticket?.enabled) return { success: false, message: 'Ticket sistemi devre dışı!' };
        
        // Açık ticket kontrolü
        const openTickets = TicketModel.getByUser(member.id, member.guild.id);
        if (openTickets.length >= 3) {
            return { success: false, message: 'Zaten 3 açık ticket\'ınız var!' };
        }
        
        const categoryId = config.ticket.categoryId;
        const staffRoleId = config.ticket.staffRoleId;
        
        try {
            // Permission overwrites hazırla
            const permissionOverwrites = [
                {
                    id: member.guild.id,
                    deny: [PermissionFlagsBits.ViewChannel]
                },
                {
                    id: member.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                        PermissionFlagsBits.AttachFiles
                    ]
                }
            ];
            
            // Staff role varsa ve geçerliyse ekle
            if (staffRoleId && staffRoleId !== 'TICKET_STAFF_ROLE_ID') {
                const staffRole = member.guild.roles.cache.get(staffRoleId);
                if (staffRole) {
                    permissionOverwrites.push({
                        id: staffRoleId,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.ManageMessages
                        ]
                    });
                }
            }
            
            // Kanal oluştur
            const channelOptions = {
                name: `${TicketModel.PRIORITY_COLORS[priority]}-ticket-${member.user.username}`,
                type: ChannelType.GuildText,
                permissionOverwrites
            };
            
            // Kategori varsa ve geçerliyse ekle
            if (categoryId && categoryId !== 'TICKET_CATEGORY_ID') {
                const category = member.guild.channels.cache.get(categoryId);
                if (category) {
                    channelOptions.parent = categoryId;
                }
            }
            
            const channel = await member.guild.channels.create(channelOptions);
            
            // Veritabanına kaydet
            const ticket = TicketModel.create({
                channelId: channel.id,
                guildId: member.guild.id,
                userId: member.id,
                userTag: member.user.tag,
                priority
            });
            
            // Hoş geldin mesajı
            const embed = embedUtil.ticket(ticket.id, priority, member);
            
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('ticket_close')
                        .setLabel('Ticket\'ı Kapat')
                        .setEmoji('🔒')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('ticket_claim')
                        .setLabel('Sahiplen')
                        .setEmoji('👋')
                        .setStyle(ButtonStyle.Primary)
                );
            
            await channel.send({ 
                content: `${member} <@&${staffRoleId}>`,
                embeds: [embed], 
                components: [row] 
            });
            
            // Log
            await this.sendLog(client, 'create', ticket, member);
            
            return { success: true, channel, ticket };
            
        } catch (error) {
            console.error('Ticket oluşturma hatası:', error);
            return { success: false, message: 'Ticket oluşturulurken bir hata oluştu!' };
        }
    },

    // Ticket kapat
    async close(channelId, closedBy, client) {
        const ticket = TicketModel.getByChannel(channelId);
        if (!ticket) return { success: false, message: 'Bu bir ticket kanalı değil!' };
        
        try {
            // Transcript oluştur
            const channel = client.channels.cache.get(channelId);
            const transcript = await this.createTranscript(channel);
            
            // Ticket'ı kapat
            TicketModel.close(ticket.id, { id: closedBy.id, tag: closedBy.tag });
            
            // Log gönder
            await this.sendLog(client, 'close', ticket, closedBy, transcript);
            
            // Kullanıcıya bildir
            try {
                const user = await client.users.fetch(ticket.userId);
                await user.send({
                    embeds: [embedUtil.info(
                        'Ticket Kapatıldı',
                        `**#${ticket.id}** numaralı destek talebiniz kapatıldı.\n\nKapatılan: ${closedBy.tag}`
                    )]
                });
            } catch (e) {}
            
            // Kanalı sil (5 saniye sonra)
            setTimeout(async () => {
                try {
                    await channel.delete();
                } catch (e) {}
            }, 5000);
            
            return { success: true };
            
        } catch (error) {
            console.error('Ticket kapatma hatası:', error);
            return { success: false, message: 'Ticket kapatılırken bir hata oluştu!' };
        }
    },

    // Ticket sahiplen
    async claim(channelId, staff, client) {
        const ticket = TicketModel.getByChannel(channelId);
        if (!ticket) return { success: false, message: 'Bu bir ticket kanalı değil!' };
        
        if (ticket.claimedBy) {
            return { success: false, message: `Bu ticket zaten <@${ticket.claimedBy.id}> tarafından sahiplenildi!` };
        }
        
        TicketModel.claim(ticket.id, staff.id, staff.tag);
        
        const channel = client.channels.cache.get(channelId);
        if (channel) {
            await channel.send({
                embeds: [embedUtil.success(
                    'Ticket Sahiplenildi',
                    `${staff} bu ticket'ı sahiplendi ve size yardımcı olacak.`
                )]
            });
        }
        
        return { success: true };
    },

    // Transcript oluştur
    async createTranscript(channel) {
        try {
            const messages = await channel.messages.fetch({ limit: 100 });
            
            let transcript = `Ticket Transcript - ${channel.name}\n`;
            transcript += `Tarih: ${new Date().toLocaleString('tr-TR')}\n`;
            transcript += `${'='.repeat(50)}\n\n`;
            
            const sortedMessages = [...messages.values()].reverse();
            
            for (const msg of sortedMessages) {
                const time = msg.createdAt.toLocaleString('tr-TR');
                transcript += `[${time}] ${msg.author.tag}: ${msg.content || '[Embed/Dosya]'}\n`;
            }
            
            return transcript;
        } catch (error) {
            return null;
        }
    },

    // Log gönder
    async sendLog(client, action, ticket, user, transcript = null) {
        const logChannelId = config.ticket.logChannelId;
        if (!logChannelId) return;
        
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;
        
        const actionTexts = {
            create: '✅ Oluşturuldu',
            close: '🔒 Kapatıldı',
            claim: '👋 Sahiplenildi'
        };
        
        const embed = embedUtil.log('ticket', {
            fields: [
                { name: '🎫 Ticket', value: `#${ticket.id}`, inline: true },
                { name: '👤 Kullanıcı', value: `<@${ticket.userId}>`, inline: true },
                { name: '🎯 İşlem', value: actionTexts[action], inline: true },
                { name: `${TicketModel.PRIORITY_COLORS[ticket.priority]} Öncelik`, value: TicketModel.PRIORITY_NAMES[ticket.priority], inline: true },
                { name: '👮 Yetkili', value: user.tag, inline: true },
                { name: '📅 Tarih', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
            ],
            footer: `Ticket ID: ${ticket.id}`
        });
        
        await logChannel.send({ embeds: [embed] });
    }
};
