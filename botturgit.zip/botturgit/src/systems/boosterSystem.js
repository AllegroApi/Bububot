const config = require('../config/config.json');
const embedUtil = require('../utils/embed');

module.exports = {
    name: 'boosterSystem',
    
    // Boost durumu değiştiğinde
    async handleBoostChange(oldMember, newMember, client) {
        if (!config.booster?.enabled) return;
        
        const wasBoosting = oldMember.premiumSince;
        const isBoosting = newMember.premiumSince;
        
        // Yeni boost başlattı
        if (!wasBoosting && isBoosting) {
            await this.onBoostStart(newMember, client);
        }
        // Boost bitti
        else if (wasBoosting && !isBoosting) {
            await this.onBoostEnd(newMember, client);
        }
    },

    // Boost başladığında
    async onBoostStart(member, client) {
        const roleId = config.booster.roleId;
        const logChannelId = config.booster.logChannelId;
        const thanksChannelId = config.booster.thanksChannelId;
        
        // Ekstra rol ver
        if (roleId) {
            const role = member.guild.roles.cache.get(roleId);
            if (role) {
                try {
                    await member.roles.add(role);
                } catch (error) {
                    console.error('Booster rol hatası:', error);
                }
            }
        }
        
        // Teşekkür mesajı gönder
        if (thanksChannelId) {
            const thanksChannel = client.channels.cache.get(thanksChannelId);
            if (thanksChannel) {
                const embed = embedUtil.create({
                    color: '#FF73FA',
                    title: '💎 YENİ BOOSTER!',
                    description: `${member} sunucumuzu **boost**ladı!\n\nTeşekkürler, sunucumuzu desteklediğin için! 💖`,
                    thumbnail: member.user.displayAvatarURL({ dynamic: true, size: 256 }),
                    fields: [
                        { name: '🚀 Sunucu Seviyesi', value: `**${member.guild.premiumTier}**`, inline: true },
                        { name: '💎 Toplam Boost', value: `**${member.guild.premiumSubscriptionCount}**`, inline: true }
                    ],
                    footer: 'Boost destekçilerimize teşekkürler!'
                });
                
                await thanksChannel.send({ 
                    content: `🎉 ${member}`,
                    embeds: [embed] 
                });
            }
        }
        
        // Log gönder
        if (logChannelId) {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = embedUtil.log('boost', {
                    fields: [
                        { name: '👤 Kullanıcı', value: `${member} (${member.user.tag})`, inline: true },
                        { name: '🎯 İşlem', value: '💎 Boost Başlattı', inline: true },
                        { name: '📅 Tarih', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                    ],
                    footer: `ID: ${member.id}`
                });
                
                await logChannel.send({ embeds: [embed] });
            }
        }
    },

    // Boost bittiğinde
    async onBoostEnd(member, client) {
        const roleId = config.booster.roleId;
        const logChannelId = config.booster.logChannelId;
        
        // Ekstra rolü al
        if (roleId) {
            const role = member.guild.roles.cache.get(roleId);
            if (role && member.roles.cache.has(roleId)) {
                try {
                    await member.roles.remove(role);
                } catch (error) {
                    console.error('Booster rol kaldırma hatası:', error);
                }
            }
        }
        
        // Log gönder
        if (logChannelId) {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                const embed = embedUtil.log('boost', {
                    fields: [
                        { name: '👤 Kullanıcı', value: `${member} (${member.user.tag})`, inline: true },
                        { name: '🎯 İşlem', value: '💔 Boost Bitti', inline: true },
                        { name: '📅 Tarih', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                    ],
                    footer: `ID: ${member.id}`
                });
                
                await logChannel.send({ embeds: [embed] });
            }
        }
    },

    // Tüm booster'ları kontrol et
    async syncBoosters(guild, client) {
        if (!config.booster?.enabled) return;
        
        const roleId = config.booster.roleId;
        if (!roleId) return;
        
        const role = guild.roles.cache.get(roleId);
        if (!role) return;
        
        const members = await guild.members.fetch();
        let added = 0, removed = 0;
        
        for (const [, member] of members) {
            const isBoosting = member.premiumSince;
            const hasRole = member.roles.cache.has(roleId);
            
            if (isBoosting && !hasRole) {
                try {
                    await member.roles.add(role);
                    added++;
                } catch (e) {}
            } else if (!isBoosting && hasRole) {
                try {
                    await member.roles.remove(role);
                    removed++;
                } catch (e) {}
            }
        }
        
        return { added, removed };
    }
};
