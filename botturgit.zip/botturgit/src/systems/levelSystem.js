const config = require('../config/config.json');
const UserModel = require('../models/User');
const embedUtil = require('../utils/embed');

// Cooldown map
const cooldowns = new Map();

module.exports = {
    name: 'levelSystem',
    
    // Mesaj geldiğinde XP ver
    async handleMessage(message, client) {
        if (!config.level?.enabled) return;
        if (message.author.bot) return;
        if (!message.guild) return;
        
        const userId = message.author.id;
        const now = Date.now();
        
        // Cooldown kontrolü
        const lastXp = cooldowns.get(userId) || 0;
        if (now - lastXp < config.level.xpCooldown) return;
        
        cooldowns.set(userId, now);
        
        // XP ekle
        const xpAmount = config.level.xpPerMessage + Math.floor(Math.random() * 10);
        const result = UserModel.addXp(userId, xpAmount);
        
        // Seviye atladıysa
        if (result.leveledUp) {
            await this.handleLevelUp(message, client, result);
        }
    },

    // Seviye atlama işlemleri
    async handleLevelUp(message, client, result) {
        const { newLevel } = result;
        const member = message.member;
        
        // Seviye rolü ver
        await this.giveRoleForLevel(member, newLevel);
        
        // Mesaj gönder
        const channelId = config.level.levelUpChannelId;
        const channel = channelId ? client.channels.cache.get(channelId) : message.channel;
        
        if (channel) {
            const rank = UserModel.getRank(member.id);
            const embed = embedUtil.levelUp(message.author, newLevel, rank);
            
            const msg = await channel.send({ 
                content: `${message.author}`,
                embeds: [embed] 
            });
            
            // 10 saniye sonra sil (isteğe bağlı)
            // setTimeout(() => msg.delete().catch(() => {}), 10000);
        }
    },

    // Seviye rolü ver
    async giveRoleForLevel(member, level) {
        const levelRoles = config.level.roles;
        if (!levelRoles) return;
        
        // Bu seviye için rol var mı kontrol et
        const roleId = levelRoles[level.toString()];
        if (!roleId) return;
        
        const role = member.guild.roles.cache.get(roleId);
        if (!role) return;
        
        try {
            // Önceki seviye rollerini kaldır (isteğe bağlı)
            for (const [lvl, rId] of Object.entries(levelRoles)) {
                if (parseInt(lvl) < level && member.roles.cache.has(rId)) {
                    await member.roles.remove(rId).catch(() => {});
                }
            }
            
            // Yeni rolü ver
            if (!member.roles.cache.has(roleId)) {
                await member.roles.add(role);
            }
        } catch (error) {
            console.error('Seviye rol hatası:', error);
        }
    },

    // Leaderboard al
    getLeaderboard(limit = 10) {
        return UserModel.getLeaderboard(limit);
    },

    // Kullanıcı bilgisi al
    getUserData(userId) {
        const user = UserModel.get(userId);
        const rank = UserModel.getRank(userId);
        const progress = UserModel.getProgress(userId);
        
        return {
            ...user,
            rank,
            progress
        };
    },

    // XP hesaplama
    calculateXpForLevel(level) {
        return UserModel.xpForLevel(level);
    }
};
