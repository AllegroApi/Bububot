const { EmbedBuilder } = require('discord.js');
const config = require('../config/config.json');

const colors = {
    join: '#57F287',      // Yeşil - Katılım
    leave: '#ED4245',     // Kırmızı - Ayrılma
    ban: '#FF0000',       // Koyu Kırmızı - Ban
    unban: '#00FF00',     // Parlak Yeşil - Unban
    kick: '#FFA500',      // Turuncu - Kick
    mute: '#FFD700',      // Altın - Mute
    warn: '#FEE75C',      // Sarı - Uyarı
    messageDelete: '#E74C3C',  // Kırmızı
    messageEdit: '#3498DB',    // Mavi
    roleAdd: '#9B59B6',        // Mor
    roleRemove: '#8E44AD',     // Koyu Mor
    nickChange: '#1ABC9C',     // Turkuaz
    voiceJoin: '#2ECC71',      // Yeşil
    voiceLeave: '#E67E22',     // Turuncu
    voiceMove: '#3498DB',      // Mavi
    channelCreate: '#2ECC71',  // Yeşil
    channelDelete: '#E74C3C',  // Kırmızı
    roleCreate: '#9B59B6',     // Mor
    roleDelete: '#8E44AD',     // Koyu Mor
    boost: '#FF73FA',          // Pembe
    timeout: '#FFD700'         // Altın
};

const emojis = {
    join: '📥',
    leave: '📤',
    ban: '🔨',
    unban: '🔓',
    kick: '👢',
    mute: '🔇',
    warn: '⚠️',
    messageDelete: '🗑️',
    messageEdit: '✏️',
    roleAdd: '➕',
    roleRemove: '➖',
    nickChange: '📝',
    voiceJoin: '🔊',
    voiceLeave: '🔇',
    voiceMove: '🔀',
    channelCreate: '📁',
    channelDelete: '🗂️',
    roleCreate: '🏷️',
    roleDelete: '🏷️',
    boost: '💎',
    timeout: '⏰'
};

module.exports = {
    name: 'logSystem',

    // Log kanalını al
    getLogChannel(client) {
        const logChannelId = config.logs?.channelId;
        if (!logChannelId || logChannelId === 'LOG_CHANNEL_ID') return null;
        return client.channels.cache.get(logChannelId);
    },

    // Genel log gönder
    async send(client, type, data) {
        const logChannel = this.getLogChannel(client);
        if (!logChannel) return;

        const embed = this.createEmbed(type, data);
        if (!embed) return;

        try {
            await logChannel.send({ embeds: [embed] });
        } catch (err) {
            console.error('Log gönderme hatası:', err.message);
        }
    },

    // Embed oluştur
    createEmbed(type, data) {
        const embed = new EmbedBuilder()
            .setTimestamp()
            .setFooter({ text: `Log Sistemi • ${new Date().toLocaleDateString('tr-TR')}` });

        switch (type) {
            case 'memberJoin':
                return embed
                    .setColor(colors.join)
                    .setAuthor({ 
                        name: `${emojis.join} Üye Katıldı`, 
                        iconURL: data.user.displayAvatarURL({ dynamic: true }) 
                    })
                    .setThumbnail(data.user.displayAvatarURL({ dynamic: true, size: 256 }))
                    .setDescription(`**${data.user.tag}** sunucuya katıldı!`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${data.user} (${data.user.id})`, inline: true },
                        { name: '📅 Hesap Oluşturma', value: `<t:${Math.floor(data.user.createdTimestamp / 1000)}:R>`, inline: true },
                        { name: '👥 Üye Sayısı', value: `**${data.memberCount}**`, inline: true }
                    );

            case 'memberLeave':
                return embed
                    .setColor(colors.leave)
                    .setAuthor({ 
                        name: `${emojis.leave} Üye Ayrıldı`, 
                        iconURL: data.user.displayAvatarURL({ dynamic: true }) 
                    })
                    .setThumbnail(data.user.displayAvatarURL({ dynamic: true, size: 256 }))
                    .setDescription(`**${data.user.tag}** sunucudan ayrıldı!`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${data.user} (${data.user.id})`, inline: true },
                        { name: '📅 Katılma Tarihi', value: data.joinedAt ? `<t:${Math.floor(data.joinedAt / 1000)}:R>` : 'Bilinmiyor', inline: true },
                        { name: '👥 Üye Sayısı', value: `**${data.memberCount}**`, inline: true },
                        { name: '🏷️ Rolleri', value: data.roles || 'Yok', inline: false }
                    );

            case 'memberBan':
                return embed
                    .setColor(colors.ban)
                    .setAuthor({ name: `${emojis.ban} Üye Yasaklandı` })
                    .setThumbnail(data.user.displayAvatarURL({ dynamic: true, size: 256 }))
                    .setDescription(`**${data.user.tag}** sunucudan yasaklandı!`)
                    .addFields(
                        { name: '👤 Yasaklanan', value: `${data.user} (${data.user.id})`, inline: true },
                        { name: '📝 Sebep', value: data.reason || 'Belirtilmedi', inline: true }
                    );

            case 'memberUnban':
                return embed
                    .setColor(colors.unban)
                    .setAuthor({ name: `${emojis.unban} Yasak Kaldırıldı` })
                    .setThumbnail(data.user.displayAvatarURL({ dynamic: true, size: 256 }))
                    .setDescription(`**${data.user.tag}** yasağı kaldırıldı!`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${data.user} (${data.user.id})`, inline: true }
                    );

            case 'memberTimeout':
                return embed
                    .setColor(colors.timeout)
                    .setAuthor({ name: `${emojis.timeout} Zaman Aşımı Verildi` })
                    .setThumbnail(data.user.displayAvatarURL({ dynamic: true, size: 256 }))
                    .setDescription(`**${data.user.tag}** zaman aşımına alındı!`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${data.user} (${data.user.id})`, inline: true },
                        { name: '⏰ Bitiş', value: `<t:${Math.floor(data.until / 1000)}:R>`, inline: true },
                        { name: '👮 Yetkili', value: data.moderator || 'Bilinmiyor', inline: true }
                    );

            case 'messageDelete':
                return embed
                    .setColor(colors.messageDelete)
                    .setAuthor({ 
                        name: `${emojis.messageDelete} Mesaj Silindi`,
                        iconURL: data.author?.displayAvatarURL({ dynamic: true })
                    })
                    .addFields(
                        { name: '👤 Yazan', value: data.author ? `${data.author} (${data.author.id})` : 'Bilinmiyor', inline: true },
                        { name: '📍 Kanal', value: `${data.channel}`, inline: true },
                        { name: '📝 İçerik', value: data.content?.substring(0, 1024) || '*İçerik alınamadı*', inline: false }
                    );

            case 'messageEdit':
                return embed
                    .setColor(colors.messageEdit)
                    .setAuthor({ 
                        name: `${emojis.messageEdit} Mesaj Düzenlendi`,
                        iconURL: data.author?.displayAvatarURL({ dynamic: true })
                    })
                    .addFields(
                        { name: '👤 Yazan', value: `${data.author} (${data.author.id})`, inline: true },
                        { name: '📍 Kanal', value: `${data.channel}`, inline: true },
                        { name: '🔗 Mesaj', value: `[Mesaja Git](${data.url})`, inline: true },
                        { name: '📝 Eski İçerik', value: data.oldContent?.substring(0, 1024) || '*İçerik alınamadı*', inline: false },
                        { name: '📝 Yeni İçerik', value: data.newContent?.substring(0, 1024) || '*İçerik alınamadı*', inline: false }
                    );

            case 'roleAdd':
                return embed
                    .setColor(colors.roleAdd)
                    .setAuthor({ 
                        name: `${emojis.roleAdd} Rol Eklendi`,
                        iconURL: data.user.displayAvatarURL({ dynamic: true })
                    })
                    .setDescription(`**${data.user.tag}** kullanıcısına rol eklendi`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${data.user}`, inline: true },
                        { name: '🏷️ Rol', value: `${data.role}`, inline: true }
                    );

            case 'roleRemove':
                return embed
                    .setColor(colors.roleRemove)
                    .setAuthor({ 
                        name: `${emojis.roleRemove} Rol Kaldırıldı`,
                        iconURL: data.user.displayAvatarURL({ dynamic: true })
                    })
                    .setDescription(`**${data.user.tag}** kullanıcısından rol kaldırıldı`)
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${data.user}`, inline: true },
                        { name: '🏷️ Rol', value: `${data.role}`, inline: true }
                    );

            case 'nickChange':
                return embed
                    .setColor(colors.nickChange)
                    .setAuthor({ 
                        name: `${emojis.nickChange} İsim Değiştirildi`,
                        iconURL: data.user.displayAvatarURL({ dynamic: true })
                    })
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${data.user}`, inline: true },
                        { name: '📝 Eski İsim', value: data.oldNick || '*Yok*', inline: true },
                        { name: '📝 Yeni İsim', value: data.newNick || '*Yok*', inline: true }
                    );

            case 'voiceJoin':
                return embed
                    .setColor(colors.voiceJoin)
                    .setAuthor({ 
                        name: `${emojis.voiceJoin} Sese Katıldı`,
                        iconURL: data.user.displayAvatarURL({ dynamic: true })
                    })
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${data.user}`, inline: true },
                        { name: '🔊 Kanal', value: `${data.channel}`, inline: true }
                    );

            case 'voiceLeave':
                return embed
                    .setColor(colors.voiceLeave)
                    .setAuthor({ 
                        name: `${emojis.voiceLeave} Sesten Ayrıldı`,
                        iconURL: data.user.displayAvatarURL({ dynamic: true })
                    })
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${data.user}`, inline: true },
                        { name: '🔊 Kanal', value: `${data.channel}`, inline: true }
                    );

            case 'voiceMove':
                return embed
                    .setColor(colors.voiceMove)
                    .setAuthor({ 
                        name: `${emojis.voiceMove} Ses Kanalı Değiştirildi`,
                        iconURL: data.user.displayAvatarURL({ dynamic: true })
                    })
                    .addFields(
                        { name: '👤 Kullanıcı', value: `${data.user}`, inline: false },
                        { name: '🔊 Eski Kanal', value: `${data.oldChannel}`, inline: true },
                        { name: '🔊 Yeni Kanal', value: `${data.newChannel}`, inline: true }
                    );

            case 'channelCreate':
                return embed
                    .setColor(colors.channelCreate)
                    .setAuthor({ name: `${emojis.channelCreate} Kanal Oluşturuldu` })
                    .addFields(
                        { name: '📁 Kanal', value: `${data.channel} (${data.channel.id})`, inline: true },
                        { name: '📂 Tür', value: data.type, inline: true }
                    );

            case 'channelDelete':
                return embed
                    .setColor(colors.channelDelete)
                    .setAuthor({ name: `${emojis.channelDelete} Kanal Silindi` })
                    .addFields(
                        { name: '📁 Kanal', value: `#${data.name} (${data.id})`, inline: true },
                        { name: '📂 Tür', value: data.type, inline: true }
                    );

            case 'roleCreate':
                return embed
                    .setColor(data.color || colors.roleCreate)
                    .setAuthor({ name: `${emojis.roleCreate} Rol Oluşturuldu` })
                    .addFields(
                        { name: '🏷️ Rol', value: `${data.role} (${data.role.id})`, inline: true },
                        { name: '🎨 Renk', value: data.role.hexColor, inline: true }
                    );

            case 'roleDelete':
                return embed
                    .setColor(colors.roleDelete)
                    .setAuthor({ name: `${emojis.roleDelete} Rol Silindi` })
                    .addFields(
                        { name: '🏷️ Rol', value: `${data.name} (${data.id})`, inline: true }
                    );

            case 'boost':
                return embed
                    .setColor(colors.boost)
                    .setAuthor({ 
                        name: `${emojis.boost} Sunucu Boost!`,
                        iconURL: data.user.displayAvatarURL({ dynamic: true })
                    })
                    .setThumbnail(data.user.displayAvatarURL({ dynamic: true, size: 256 }))
                    .setDescription(`🎉 **${data.user.tag}** sunucuyu boost'ladı!`)
                    .addFields(
                        { name: '💎 Toplam Boost', value: `**${data.boostCount}**`, inline: true },
                        { name: '🏆 Seviye', value: `**${data.boostTier}**`, inline: true }
                    );

            default:
                return null;
        }
    }
};
