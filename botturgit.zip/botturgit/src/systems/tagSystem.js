const { EmbedBuilder } = require('discord.js');
const config = require('../config/config.json');
const UserModel = require('../models/User');
const embedUtil = require('../utils/embed');

module.exports = {
    name: 'tagSystem',
    
    // Tag kontrolü yap ve rol ver/al
    async checkTag(member, client) {
        if (!config.tag?.enabled) return;
        
        const tag = config.tag.tag;
        const roleId = config.tag.roleId;
        const logChannelId = config.tag.logChannelId;
        
        const hasTag = member.user.username.includes(tag) || 
                       (member.nickname && member.nickname.includes(tag));
        
        const hasRole = member.roles.cache.has(roleId);
        const role = member.guild.roles.cache.get(roleId);
        
        if (!role) return;
        
        try {
            // Tag aldı ama rol yok
            if (hasTag && !hasRole) {
                await member.roles.add(role);
                
                // User model güncelle
                UserModel.update(member.id, { hasTag: true });
                
                // Log gönder
                await this.sendLog(client, member, 'add', logChannelId);
            }
            // Tag yok ama rol var
            else if (!hasTag && hasRole) {
                await member.roles.remove(role);
                
                // User model güncelle
                UserModel.update(member.id, { hasTag: false });
                
                // Log gönder
                await this.sendLog(client, member, 'remove', logChannelId);
            }
        } catch (error) {
            console.error('Tag sistem hatası:', error);
        }
    },

    // Log gönder
    async sendLog(client, member, action, logChannelId) {
        const logChannel = client.channels.cache.get(logChannelId);
        if (!logChannel) return;
        
        const embed = embedUtil.log('tag', {
            fields: [
                { name: '👤 Kullanıcı', value: `${member} (${member.user.tag})`, inline: true },
                { name: '🎯 İşlem', value: action === 'add' ? '✅ Tag Aldı' : '❌ Tag Çıkardı', inline: true },
                { name: '📅 Tarih', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
            ],
            footer: `ID: ${member.id}`
        });
        
        await logChannel.send({ embeds: [embed] });
    },

    // Tüm sunucuyu tara
    async scanGuild(guild, client) {
        if (!config.tag?.enabled) return;
        
        const members = await guild.members.fetch();
        let added = 0, removed = 0;
        
        for (const [, member] of members) {
            if (member.user.bot) continue;
            
            const tag = config.tag.tag;
            const roleId = config.tag.roleId;
            
            const hasTag = member.user.username.includes(tag) || 
                          (member.nickname && member.nickname.includes(tag));
            const hasRole = member.roles.cache.has(roleId);
            
            if (hasTag && !hasRole) {
                try {
                    await member.roles.add(roleId);
                    added++;
                } catch (e) {}
            } else if (!hasTag && hasRole) {
                try {
                    await member.roles.remove(roleId);
                    removed++;
                } catch (e) {}
            }
        }
        
        return { added, removed };
    }
};
