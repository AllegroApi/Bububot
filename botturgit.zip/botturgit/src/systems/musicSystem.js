const { 
    createAudioPlayer, 
    createAudioResource, 
    joinVoiceChannel, 
    AudioPlayerStatus,
    VoiceConnectionStatus,
    entersState,
    getVoiceConnection
} = require('@discordjs/voice');
const play = require('play-dl');
const { EmbedBuilder } = require('discord.js');

// Sunucu bazlı müzik kuyrukları
const queues = new Map();

class MusicQueue {
    constructor(guildId) {
        this.guildId = guildId;
        this.songs = [];
        this.player = createAudioPlayer();
        this.connection = null;
        this.voiceChannel = null;
        this.playing = false;
        this.paused = false;
        this.loop = false;
        this.loopQueue = false;
        this.volume = 100;
        this.textChannel = null;
        this.currentSong = null;

        // Player event listeners
        this.player.on(AudioPlayerStatus.Idle, () => {
            this.processQueue();
        });

        this.player.on('error', error => {
            console.error('Müzik oynatma hatası:', error);
            this.processQueue();
        });
    }

    async processQueue() {
        // Loop tek şarkı
        if (this.loop && this.currentSong) {
            await this.playSong(this.currentSong);
            return;
        }

        // Loop kuyruk
        if (this.loopQueue && this.currentSong) {
            this.songs.push(this.currentSong);
        }

        // Kuyrukta şarkı yoksa
        if (this.songs.length === 0) {
            this.playing = false;
            this.currentSong = null;
            
            // 5 dakika sonra bağlantıyı kes
            setTimeout(() => {
                if (!this.playing && this.connection) {
                    this.disconnect();
                    if (this.textChannel) {
                        this.textChannel.send('⏹️ **5 dakika boyunca şarkı çalınmadığı için ses kanalından ayrıldım.**');
                    }
                }
            }, 300000);
            return;
        }

        const song = this.songs.shift();
        await this.playSong(song);
    }

    async playSong(song) {
        try {
            // URL kontrolü
            if (!song || !song.url || typeof song.url !== 'string' || !song.url.startsWith('http')) {
                console.error('Geçersiz şarkı veya URL:', song);
                if (this.textChannel) {
                    const errorEmbed = new EmbedBuilder()
                        .setColor('#ED4245')
                        .setTitle('❌ Şarkı çalınamadı')
                        .setDescription('Geçersiz şarkı veya URL. Lütfen tekrar deneyin.')
                        .setTimestamp();
                    this.textChannel.send({ embeds: [errorEmbed] });
                }
                this.processQueue();
                return;
            }

            console.log('Çalınacak şarkı:', song);
            this.currentSong = song;
            this.playing = true;

            let resource;
            try {
                // ffmpeg yoksa fallback: audioonly webm
                const stream = await play.stream(song.url, { quality: 2 });
                if (stream.stream) {
                    resource = createAudioResource(stream.stream, {
                        inputType: stream.type,
                        inlineVolume: true
                    });
                } else if (stream.url) {
                    resource = createAudioResource(stream.url, {
                        inputType: stream.type,
                        inlineVolume: true
                    });
                } else {
                    throw new Error('Stream alınamadı!');
                }
            } catch (err) {
                console.error('play-dl stream hatası:', err);
                if (this.textChannel) {
                    const errorEmbed = new EmbedBuilder()
                        .setColor('#ED4245')
                        .setTitle('❌ Şarkı çalınamadı')
                        .setDescription('YouTube stream alınamadı. ffmpeg olmadan bazı şarkılar çalınamayabilir.')
                        .setTimestamp();
                    this.textChannel.send({ embeds: [errorEmbed] });
                }
                this.processQueue();
                return;
            }

            if (resource && resource.volume) {
                resource.volume.setVolume(this.volume / 100);
            }

            this.player.play(resource);
            this.connection.subscribe(this.player);

            // Şimdi çalıyor mesajı
            if (this.textChannel) {
                const embed = new EmbedBuilder()
                    .setColor('#57F287')
                    .setAuthor({ name: '🎵 Şimdi Çalıyor', iconURL: 'https://i.imgur.com/DfBTGGQ.gif' })
                    .setTitle(song.title)
                    .setURL(song.url)
                    .setThumbnail(song.thumbnail)
                    .addFields(
                        { name: '⏱️ Süre', value: song.duration || 'Bilinmiyor', inline: true },
                        { name: '👤 İsteyen', value: `<@${song.requestedBy}>`, inline: true },
                        { name: '📋 Sırada', value: `${this.songs.length} şarkı`, inline: true }
                    )
                    .setFooter({ text: `🔊 Ses: ${this.volume}%` })
                    .setTimestamp();
                this.textChannel.send({ embeds: [embed] });
            }

        } catch (error) {
            console.error('Şarkı çalma hatası:', error);
            if (this.textChannel) {
                this.textChannel.send(`❌ Şarkı çalınırken hata oluştu: ${song.title}`);
            }
            this.processQueue();
        }
    }

    addSong(song) {
        this.songs.push(song);
    }

    skip() {
        this.player.stop();
    }

    pause() {
        this.player.pause();
        this.paused = true;
    }

    resume() {
        this.player.unpause();
        this.paused = false;
    }

    setVolume(vol) {
        this.volume = vol;
    }

    shuffle() {
        for (let i = this.songs.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this.songs[i], this.songs[j]] = [this.songs[j], this.songs[i]];
        }
    }

    clear() {
        this.songs = [];
    }

    disconnect() {
        if (this.connection) {
            this.connection.destroy();
            this.connection = null;
        }
        this.playing = false;
        this.songs = [];
        this.currentSong = null;
        queues.delete(this.guildId);
    }
}

module.exports = {
    // Kuyruk al veya oluştur
    getQueue(guildId) {
        if (!queues.has(guildId)) {
            queues.set(guildId, new MusicQueue(guildId));
        }
        return queues.get(guildId);
    },

    // Kuyruk var mı kontrol
    hasQueue(guildId) {
        return queues.has(guildId);
    },

    // Kuyruğu sil
    deleteQueue(guildId) {
        const queue = queues.get(guildId);
        if (queue) {
            queue.disconnect();
        }
        queues.delete(guildId);
    },

    // Ses kanalına bağlan
    async connect(channel, textChannel) {
        const queue = this.getQueue(channel.guild.id);
        
        const connection = joinVoiceChannel({
            channelId: channel.id,
            guildId: channel.guild.id,
            adapterCreator: channel.guild.voiceAdapterCreator,
            selfDeaf: true
        });

        try {
            await entersState(connection, VoiceConnectionStatus.Ready, 30000);
            queue.connection = connection;
            queue.voiceChannel = channel;
            queue.textChannel = textChannel;

            // Bağlantı kesilirse
            connection.on(VoiceConnectionStatus.Disconnected, async () => {
                try {
                    await Promise.race([
                        entersState(connection, VoiceConnectionStatus.Signalling, 5000),
                        entersState(connection, VoiceConnectionStatus.Connecting, 5000),
                    ]);
                } catch {
                    this.deleteQueue(channel.guild.id);
                }
            });

            return queue;
        } catch (error) {
            connection.destroy();
            throw error;
        }
    },

    // YouTube'dan şarkı bilgisi al
    async getSongInfo(query) {
        try {
            let songInfo;

            // URL mi kontrol et
            if (play.yt_validate(query) === 'video') {
                const info = await play.video_info(query);
                songInfo = {
                    title: info.video_details.title,
                    url: info.video_details.url,
                    duration: info.video_details.durationRaw,
                    thumbnail: info.video_details.thumbnails[0]?.url || '',
                    channel: info.video_details.channel?.name || 'Bilinmiyor'
                };
            } else if (play.yt_validate(query) === 'playlist') {
                // Playlist
                const playlist = await play.playlist_info(query, { incomplete: true });
                const videos = await playlist.all_videos();
                return videos.map(v => ({
                    title: v.title,
                    url: v.url,
                    duration: v.durationRaw,
                    thumbnail: v.thumbnails[0]?.url || '',
                    channel: v.channel?.name || 'Bilinmiyor',
                    isPlaylist: true,
                    playlistName: playlist.title
                }));
            } else {
                // Arama yap
                const searched = await play.search(query, { limit: 1 });
                if (searched.length === 0) return null;

                songInfo = {
                    title: searched[0].title,
                    url: searched[0].url,
                    duration: searched[0].durationRaw,
                    thumbnail: searched[0].thumbnails[0]?.url || '',
                    channel: searched[0].channel?.name || 'Bilinmiyor'
                };
            }

            return songInfo;
        } catch (error) {
            console.error('Şarkı bilgisi alma hatası:', error);
            return null;
        }
    },

    // Arama yap
    async search(query, limit = 10) {
        try {
            const results = await play.search(query, { limit, source: { youtube: 'video' } });
            console.log('Arama sonuçları:', results.length > 0 ? results[0] : 'Sonuç yok');
            return results.map(r => ({
                title: r.title || 'Bilinmeyen',
                url: r.url || '',
                duration: r.durationRaw || '0:00',
                thumbnail: r.thumbnails?.[0]?.url || '',
                channel: r.channel?.name || 'Bilinmiyor'
            }));
        } catch (error) {
            console.error('Arama hatası:', error);
            return [];
        }
    }
};
