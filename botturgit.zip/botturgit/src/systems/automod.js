const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config/config.json');

// Yasaklı kelimeler (örnek - config'den de alınabilir)
const bannedWords = [
    // Küfürler ve argo
    'amk', 'aq', 'oç', 'orospu', 'piç', 'sik', 'yarak', 'göt',
    'amına', 'ananı', 'sikeyim', 'sikerim', 'yarrak', 'taşak', 'meme', 'am',
    'orosbu', 'pezevenk', 'kahpe', 'kaltak', 'sürtük', 'fahişe', 'şerefsiz',
    'namussuz', 'haysiyetsiz', 'alçak', 'ahlaksız', 'adi', 'aptal', 'gerizekalı',
    'salak', 'mal', 'dangalak', 'andaval', 'geri zekalı', 'embesil', 'moron',
    'amcık', 'götveren', 'ibne', 'top', 'puşt', 'gavat', 'boynuzlu', 'dümbük',
    'yavşak', 'dallama', 'dalyarak', 'siktir', 'siktiğim', 'amına koyim',
    'ananın amı', 'babanı', 'ecdadını', 'sülaleni', 'soyunu', 'sopunu',
    'kodumun', 'koyduğumun', 'piçkurusu', 'orosbuçocuğu', 'orospuevladı',
    'hıyar', 'manyak', 'deli', 'kafayı yemiş', 'züppe', 'şıllık', 'kevaşe',
    'it', 'köpek', 'domuz', 'hayvan', 'eşek', 'öküz', 'inek', 'maymun',
    's1k', 's!k', 'a.q', 'a.m.k', 'mk', 'mq', 'o.ç', 'p1ç', 'y4rr4k',
    '0rospu', '0ç', 'am1na', 's!kt!r', 'g0t', 'g.t', 'p!ç', 'yrk',
    // Spam kelimeleri
    'nitro free', 'free nitro', 'discord nitro',
    // İstersen buraya ekle
];

// Yasaklı linkler
const bannedDomains = [
    'grabify.link',
    'iplogger.org',
    'blasze.tk',
    'pornhub.com',
    'xvideos.com',
    'xhamster.com'
];

// Reklam patternleri
const adPatterns = [
    /discord\.gg\/[a-zA-Z0-9]+/gi,
    /discord\.com\/invite\/[a-zA-Z0-9]+/gi,
    /discordapp\.com\/invite\/[a-zA-Z0-9]+/gi
];

// Kullanıcı ihlal takibi
const userViolations = new Map();

module.exports = {
    name: 'autoMod',

    // Ayarlar
    settings: {
        enabled: true,
        
        // Modüller
        filterBadWords: true,
        filterLinks: true,
        filterInvites: true,
        filterScam: true,
        filterZalgo: true,
        filterMassMention: true,
        
        // Eşikler
        massMentionLimit: 5,
        warnThreshold: 3,
        muteThreshold: 5,
        muteDuration: 600000, // 10 dakika
        
        // Muaflar
        ignoredRoles: [],
        ignoredChannels: [],
        allowedInvites: [] // İzin verilen davet linkleri
    },

    // Ana kontrol fonksiyonu
    async checkMessage(message, client) {
        if (!this.settings.enabled) return { violation: false };
        if (message.author.bot) return { violation: false };
        if (!message.guild) return { violation: false };

        // Yetkili kontrolü
        if (message.member?.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return { violation: false };
        }

        // Muaf rol kontrolü
        if (this.settings.ignoredRoles.some(roleId => message.member?.roles.cache.has(roleId))) {
            return { violation: false };
        }

        // Muaf kanal kontrolü
        if (this.settings.ignoredChannels.includes(message.channel.id)) {
            return { violation: false };
        }

        const content = message.content.toLowerCase();
        const violations = [];

        // 1. Küfür/Kötü kelime kontrolü
        if (this.settings.filterBadWords) {
            const foundBadWord = bannedWords.find(word => content.includes(word.toLowerCase()));
            if (foundBadWord) {
                violations.push({ type: 'badword', detail: 'Yasaklı kelime kullanımı' });
            }
        }

        // 2. Link kontrolü
        if (this.settings.filterLinks) {
            const urlRegex = /(https?:\/\/[^\s]+)/gi;
            const urls = message.content.match(urlRegex) || [];
            
            for (const url of urls) {
                const domain = this.extractDomain(url);
                if (bannedDomains.some(banned => domain.includes(banned))) {
                    violations.push({ type: 'badlink', detail: 'Yasaklı link' });
                    break;
                }
            }
        }

        // 3. Davet linki kontrolü
        if (this.settings.filterInvites) {
            for (const pattern of adPatterns) {
                if (pattern.test(message.content)) {
                    // İzin verilen davet mi kontrol et
                    const inviteCode = message.content.match(/discord\.gg\/([a-zA-Z0-9]+)/i)?.[1];
                    if (inviteCode && !this.settings.allowedInvites.includes(inviteCode)) {
                        violations.push({ type: 'invite', detail: 'Discord davet linki' });
                    }
                    break;
                }
            }
        }

        // 4. Scam/Phishing kontrolü
        if (this.settings.filterScam) {
            const scamKeywords = ['free nitro', 'steam gift', 'free robux', 'click here to claim', 'airdrop'];
            if (scamKeywords.some(kw => content.includes(kw))) {
                violations.push({ type: 'scam', detail: 'Şüpheli scam içeriği' });
            }
        }

        // 5. Zalgo text kontrolü
        if (this.settings.filterZalgo) {
            const zalgoRegex = /[\u0300-\u036f\u0489]/g;
            const zalgoMatches = message.content.match(zalgoRegex) || [];
            if (zalgoMatches.length > 10) {
                violations.push({ type: 'zalgo', detail: 'Zalgo text kullanımı' });
            }
        }

        // 6. Toplu etiketleme kontrolü
        if (this.settings.filterMassMention) {
            const totalMentions = message.mentions.users.size + message.mentions.roles.size;
            if (message.mentions.everyone || totalMentions > this.settings.massMentionLimit) {
                violations.push({ type: 'massmention', detail: 'Toplu etiketleme' });
            }
        }

        // İhlal varsa işlem yap
        if (violations.length > 0) {
            await this.handleViolation(message, client, violations);
            return { violation: true, types: violations };
        }

        return { violation: false };
    },

    // İhlal işleme
    async handleViolation(message, client, violations) {
        const userId = message.author.id;
        
        // Mesajı sil
        try {
            await message.delete();
        } catch (e) {}

        // Kullanıcı ihlal sayısını güncelle
        const currentViolations = (userViolations.get(userId) || 0) + 1;
        userViolations.set(userId, currentViolations);

        // 30 dakika sonra ihlali sıfırla
        setTimeout(() => {
            const v = userViolations.get(userId);
            if (v) userViolations.set(userId, Math.max(0, v - 1));
        }, 1800000);

        const violationText = violations.map(v => v.detail).join(', ');

        // Log embed
        const logEmbed = new EmbedBuilder()
            .setColor('#ED4245')
            .setTitle('🛡️ AutoMod İhlali')
            .addFields(
                { name: '👤 Kullanıcı', value: `${message.author} (${message.author.id})`, inline: true },
                { name: '📍 Kanal', value: `${message.channel}`, inline: true },
                { name: '⚠️ İhlal Türü', value: violationText, inline: false },
                { name: '📝 Mesaj İçeriği', value: message.content.substring(0, 500) || '*Boş*', inline: false },
                { name: '⚡ Toplam İhlal', value: `${currentViolations}`, inline: true }
            )
            .setTimestamp();

        // Uyarı mesajı
        if (currentViolations < this.settings.muteThreshold) {
            try {
                await message.channel.send({
                    content: `⚠️ ${message.author}, bu tür içerikler yasak! (${currentViolations}/${this.settings.muteThreshold} ihlal)\n**Sebep:** ${violationText}`,
                }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
            } catch (e) {}
            
            logEmbed.addFields({ name: '🔨 Aksiyon', value: 'Uyarı', inline: true });
        }

        // Mute
        if (currentViolations >= this.settings.muteThreshold) {
            try {
                await message.member?.timeout(this.settings.muteDuration, `AutoMod: ${violationText}`);
                
                await message.channel.send({
                    content: `🔇 ${message.author} kurallara uymadığı için **${this.settings.muteDuration / 60000} dakika** susturuldu!`,
                }).then(m => setTimeout(() => m.delete().catch(() => {}), 10000));

                // Violation sıfırla
                userViolations.set(userId, 0);
                
                logEmbed.setColor('#FF0000');
                logEmbed.addFields({ name: '🔨 Aksiyon', value: `${this.settings.muteDuration / 60000} dk Mute`, inline: true });
            } catch (e) {
                console.error('AutoMod mute hatası:', e.message);
            }
        }

        // Log gönder
        const logChannelId = config.logs?.channelId;
        if (logChannelId && logChannelId !== 'LOG_CHANNEL_ID') {
            const logChannel = client.channels.cache.get(logChannelId);
            if (logChannel) {
                await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
            }
        }
    },

    // Domain çıkar
    extractDomain(url) {
        try {
            const urlObj = new URL(url);
            return urlObj.hostname.toLowerCase();
        } catch {
            return '';
        }
    },

    // Yasaklı kelime ekle
    addBannedWord(word) {
        if (!bannedWords.includes(word.toLowerCase())) {
            bannedWords.push(word.toLowerCase());
        }
    },

    // Yasaklı kelime kaldır
    removeBannedWord(word) {
        const index = bannedWords.indexOf(word.toLowerCase());
        if (index > -1) {
            bannedWords.splice(index, 1);
        }
    },

    // Yasaklı kelimeleri listele
    getBannedWords() {
        return bannedWords;
    },

    // Kullanıcı ihlalini sıfırla
    clearViolations(userId) {
        userViolations.delete(userId);
    }
};
