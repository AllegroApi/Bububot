require("dotenv").config();
const fs = require("fs");
const path = require("path");
const { Client, Collection, GatewayIntentBits, Partials, ActivityType } = require("discord.js");

// Sistemler
const giveawaySystem = require("./systems/giveawaySystem");
const privateVoiceSystem = require("./systems/privateVoiceSystem");
const tagSystem = require("./systems/tagSystem");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.DirectMessages
  ],
  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.Reaction,
    Partials.User,
    Partials.GuildMember
  ]
});

client.commands = new Collection();
const prefix = ".";

// 🔹 Komutları recursive yükle
function loadCommands(dir) {
  const files = fs.readdirSync(dir);

  for (const file of files) {
    const filePath = path.join(dir, file);

    if (fs.statSync(filePath).isDirectory()) {
      loadCommands(filePath);
    } else if (file.endsWith(".js")) {
      const command = require(filePath);

      // ⚡ Slash komut
      if (command.data && command.executeSlash) {
        client.commands.set(command.data.name, command);
      }

      // ⚡ Prefix komut
      if (command.name && command.executePrefix) {
        client.commands.set(command.name, command);
      }
    }
  }
}

loadCommands(path.join(__dirname, "commands"));

// 🔹 READY
client.once("ready", async () => {
  console.log(`✅ Bot hazır: ${client.user.tag}`);
  
  // Aktivite ayarla
  client.user.setActivity('💎 Flux Sunucusu', { type: ActivityType.Watching });
  
  // Aktif çekilişleri yükle
  await giveawaySystem.loadActiveGiveaways(client);
  
  // Boş özel odaları temizle
  await privateVoiceSystem.cleanEmptyRooms(client);
  
  // Her sunucuda tag kontrolü yap
  for (const [, guild] of client.guilds.cache) {
    console.log(`📡 ${guild.name} sunucusu yükleniyor...`);
  }
  
  console.log('🎉 Tüm sistemler aktif!');
});

// 🔹 EVENTLER (slash, prefix, buton, modal, select hepsi burada)
require("./handlers/eventHandler")(client);

// 🔹 Hata yakalayıcılar - botun çökmesini engeller
process.on('unhandledRejection', (reason, promise) => {
  console.error('⚠️ Unhandled Rejection:', reason);
});

process.on('uncaughtException', (error) => {
  console.error('⚠️ Uncaught Exception:', error);
});

client.on('error', (error) => {
  console.error('⚠️ Client Error:', error);
});

client.login(process.env.TOKEN);
