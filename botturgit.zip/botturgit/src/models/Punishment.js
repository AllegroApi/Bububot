const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/punishments.json');

function ensureDataFile() {
    const dir = path.dirname(dataPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(dataPath)) {
        fs.writeFileSync(dataPath, '{}');
    }
}

function loadData() {
    ensureDataFile();
    try {
        return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch {
        return {};
    }
}

function saveData(data) {
    ensureDataFile();
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

module.exports = {
    // Yeni ceza ekle
    add(userId, punishment) {
        const data = loadData();
        if (!data[userId]) {
            data[userId] = [];
        }
        
        const newPunishment = {
            id: Date.now().toString(36),
            type: punishment.type, // mute, ban, kick, warn, jail
            reason: punishment.reason || 'Belirtilmemiş',
            moderatorId: punishment.moderatorId,
            moderatorTag: punishment.moderatorTag,
            timestamp: Date.now(),
            duration: punishment.duration || null,
            active: punishment.active !== false,
            expiresAt: punishment.duration ? Date.now() + punishment.duration : null
        };
        
        data[userId].push(newPunishment);
        saveData(data);
        return newPunishment;
    },

    // Kullanıcının tüm cezalarını al
    getAll(userId) {
        const data = loadData();
        return data[userId] || [];
    },

    // Aktif cezaları al
    getActive(userId, type = null) {
        const punishments = this.getAll(userId);
        return punishments.filter(p => {
            if (!p.active) return false;
            if (p.expiresAt && p.expiresAt < Date.now()) {
                p.active = false;
                return false;
            }
            if (type && p.type !== type) return false;
            return true;
        });
    },

    // Belirli bir ceza türünü al
    getByType(userId, type) {
        const punishments = this.getAll(userId);
        return punishments.filter(p => p.type === type);
    },

    // Son cezayı al
    getLast(userId, type = null) {
        const punishments = type ? this.getByType(userId, type) : this.getAll(userId);
        return punishments.sort((a, b) => b.timestamp - a.timestamp)[0] || null;
    },

    // Cezayı kaldır (deaktif et)
    remove(userId, punishmentId) {
        const data = loadData();
        if (!data[userId]) return false;
        
        const punishment = data[userId].find(p => p.id === punishmentId);
        if (punishment) {
            punishment.active = false;
            punishment.removedAt = Date.now();
            saveData(data);
            return true;
        }
        return false;
    },

    // Tüm aktif cezaları kaldır
    removeAllActive(userId, type = null) {
        const data = loadData();
        if (!data[userId]) return 0;
        
        let count = 0;
        data[userId].forEach(p => {
            if (p.active && (!type || p.type === type)) {
                p.active = false;
                p.removedAt = Date.now();
                count++;
            }
        });
        
        saveData(data);
        return count;
    },

    // İstatistikler
    getStats(userId) {
        const punishments = this.getAll(userId);
        return {
            total: punishments.length,
            mutes: punishments.filter(p => p.type === 'mute').length,
            bans: punishments.filter(p => p.type === 'ban').length,
            kicks: punishments.filter(p => p.type === 'kick').length,
            warns: punishments.filter(p => p.type === 'warn').length,
            jails: punishments.filter(p => p.type === 'jail').length,
            active: punishments.filter(p => p.active).length
        };
    },

    // Sunucu geneli istatistikler
    getGlobalStats() {
        const data = loadData();
        let stats = {
            totalPunishments: 0,
            totalUsers: Object.keys(data).length,
            byType: { mute: 0, ban: 0, kick: 0, warn: 0, jail: 0 }
        };
        
        Object.values(data).forEach(userPunishments => {
            stats.totalPunishments += userPunishments.length;
            userPunishments.forEach(p => {
                if (stats.byType[p.type] !== undefined) {
                    stats.byType[p.type]++;
                }
            });
        });
        
        return stats;
    }
};
