const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/giveaways.json');

function ensureDataFile() {
    const dir = path.dirname(dataPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(dataPath)) {
        fs.writeFileSync(dataPath, '[]');
    }
}

function loadData() {
    ensureDataFile();
    try {
        return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch {
        return [];
    }
}

function saveData(data) {
    ensureDataFile();
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

module.exports = {
    // Yeni çekiliş oluştur
    create(giveaway) {
        const data = loadData();
        
        const newGiveaway = {
            id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
            messageId: giveaway.messageId,
            channelId: giveaway.channelId,
            guildId: giveaway.guildId,
            prize: giveaway.prize,
            winnerCount: giveaway.winnerCount || 1,
            hostId: giveaway.hostId,
            hostTag: giveaway.hostTag,
            startedAt: Date.now(),
            endsAt: giveaway.endsAt,
            ended: false,
            winners: [],
            participants: [],
            requiredRoleId: giveaway.requiredRoleId || null
        };
        
        data.push(newGiveaway);
        saveData(data);
        return newGiveaway;
    },

    // Çekiliş al
    get(messageId) {
        const data = loadData();
        return data.find(g => g.messageId === messageId);
    },

    // ID ile çekiliş al
    getById(id) {
        const data = loadData();
        return data.find(g => g.id === id);
    },

    // Aktif çekilişleri al
    getActive() {
        const data = loadData();
        return data.filter(g => !g.ended && g.endsAt > Date.now());
    },

    // Süresi dolan çekilişleri al
    getExpired() {
        const data = loadData();
        return data.filter(g => !g.ended && g.endsAt <= Date.now());
    },

    // Sunucunun çekilişlerini al
    getByGuild(guildId, activeOnly = false) {
        const data = loadData();
        return data.filter(g => {
            if (g.guildId !== guildId) return false;
            if (activeOnly && g.ended) return false;
            return true;
        });
    },

    // Katılımcı ekle
    addParticipant(messageId, userId) {
        const data = loadData();
        const giveaway = data.find(g => g.messageId === messageId);
        
        if (!giveaway) return null;
        if (giveaway.ended) return null;
        if (giveaway.participants.includes(userId)) return giveaway;
        
        giveaway.participants.push(userId);
        saveData(data);
        return giveaway;
    },

    // Katılımcı çıkar
    removeParticipant(messageId, userId) {
        const data = loadData();
        const giveaway = data.find(g => g.messageId === messageId);
        
        if (!giveaway) return null;
        
        giveaway.participants = giveaway.participants.filter(p => p !== userId);
        saveData(data);
        return giveaway;
    },

    // Çekilişi bitir ve kazanan seç
    end(messageId) {
        const data = loadData();
        const giveaway = data.find(g => g.messageId === messageId);
        
        if (!giveaway) return null;
        if (giveaway.ended) return giveaway;
        
        giveaway.ended = true;
        giveaway.endedAt = Date.now();
        
        // Rastgele kazanan seç
        const shuffled = [...giveaway.participants].sort(() => Math.random() - 0.5);
        giveaway.winners = shuffled.slice(0, giveaway.winnerCount);
        
        saveData(data);
        return giveaway;
    },

    // Yeniden çekiliş yap
    reroll(messageId, count = 1) {
        const data = loadData();
        const giveaway = data.find(g => g.messageId === messageId);
        
        if (!giveaway) return null;
        if (!giveaway.ended) return null;
        
        // Eski kazananları hariç tut
        const eligibleParticipants = giveaway.participants.filter(
            p => !giveaway.winners.includes(p)
        );
        
        if (eligibleParticipants.length === 0) {
            // Herkes kazandıysa tüm katılımcılardan seç
            const shuffled = [...giveaway.participants].sort(() => Math.random() - 0.5);
            return shuffled.slice(0, count);
        }
        
        const shuffled = [...eligibleParticipants].sort(() => Math.random() - 0.5);
        const newWinners = shuffled.slice(0, count);
        
        giveaway.winners = [...giveaway.winners, ...newWinners];
        giveaway.rerolledAt = Date.now();
        
        saveData(data);
        return newWinners;
    },

    // Çekilişi sil
    delete(messageId) {
        const data = loadData();
        const index = data.findIndex(g => g.messageId === messageId);
        
        if (index === -1) return false;
        
        data.splice(index, 1);
        saveData(data);
        return true;
    },

    // Çekilişi güncelle
    update(messageId, updates) {
        const data = loadData();
        const giveaway = data.find(g => g.messageId === messageId);
        
        if (!giveaway) return null;
        
        Object.assign(giveaway, updates);
        saveData(data);
        return giveaway;
    }
};
