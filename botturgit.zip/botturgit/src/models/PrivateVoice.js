const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/privateVoice.json');

function ensureDataFile() {
    const dir = path.dirname(dataPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(dataPath)) {
        fs.writeFileSync(dataPath, '{}');
    }
}

function loadData() {
    ensureDataFile();
    try {
        return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch {
        return {};
    }
}

function saveData(data) {
    ensureDataFile();
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

module.exports = {
    // Yeni özel oda oluştur
    create(room) {
        const data = loadData();
        
        const newRoom = {
            channelId: room.channelId,
            guildId: room.guildId,
            ownerId: room.ownerId,
            ownerTag: room.ownerTag,
            name: room.name || `${room.ownerTag}'ın Odası`,
            createdAt: Date.now(),
            settings: {
                locked: false,
                userLimit: 0,
                bitrate: 64000,
                allowedUsers: [],
                blockedUsers: []
            }
        };
        
        data[room.channelId] = newRoom;
        saveData(data);
        return newRoom;
    },

    // Oda al
    get(channelId) {
        const data = loadData();
        return data[channelId] || null;
    },

    // Kullanıcının odasını al
    getByOwner(ownerId, guildId) {
        const data = loadData();
        return Object.values(data).find(r => 
            r.ownerId === ownerId && r.guildId === guildId
        );
    },

    // Oda güncelle
    update(channelId, updates) {
        const data = loadData();
        if (!data[channelId]) return null;
        
        Object.assign(data[channelId], updates);
        saveData(data);
        return data[channelId];
    },

    // Oda ayarlarını güncelle
    updateSettings(channelId, settings) {
        const data = loadData();
        if (!data[channelId]) return null;
        
        Object.assign(data[channelId].settings, settings);
        saveData(data);
        return data[channelId];
    },

    // Kullanıcı izni ekle
    allowUser(channelId, userId) {
        const data = loadData();
        if (!data[channelId]) return null;
        
        if (!data[channelId].settings.allowedUsers.includes(userId)) {
            data[channelId].settings.allowedUsers.push(userId);
        }
        // Engellenenden çıkar
        data[channelId].settings.blockedUsers = 
            data[channelId].settings.blockedUsers.filter(id => id !== userId);
        
        saveData(data);
        return data[channelId];
    },

    // Kullanıcıyı engelle
    blockUser(channelId, userId) {
        const data = loadData();
        if (!data[channelId]) return null;
        
        if (!data[channelId].settings.blockedUsers.includes(userId)) {
            data[channelId].settings.blockedUsers.push(userId);
        }
        // İzin verilenlerden çıkar
        data[channelId].settings.allowedUsers = 
            data[channelId].settings.allowedUsers.filter(id => id !== userId);
        
        saveData(data);
        return data[channelId];
    },

    // Kullanıcı iznini kaldır
    removeUser(channelId, userId) {
        const data = loadData();
        if (!data[channelId]) return null;
        
        data[channelId].settings.allowedUsers = 
            data[channelId].settings.allowedUsers.filter(id => id !== userId);
        data[channelId].settings.blockedUsers = 
            data[channelId].settings.blockedUsers.filter(id => id !== userId);
        
        saveData(data);
        return data[channelId];
    },

    // Odayı kilitle/aç
    toggleLock(channelId) {
        const data = loadData();
        if (!data[channelId]) return null;
        
        data[channelId].settings.locked = !data[channelId].settings.locked;
        saveData(data);
        return data[channelId];
    },

    // Sahibi değiştir
    transferOwnership(channelId, newOwnerId, newOwnerTag) {
        const data = loadData();
        if (!data[channelId]) return null;
        
        data[channelId].ownerId = newOwnerId;
        data[channelId].ownerTag = newOwnerTag;
        saveData(data);
        return data[channelId];
    },

    // Odayı sil
    delete(channelId) {
        const data = loadData();
        if (!data[channelId]) return false;
        
        delete data[channelId];
        saveData(data);
        return true;
    },

    // Tüm odaları al
    getAll(guildId = null) {
        const data = loadData();
        if (!guildId) return Object.values(data);
        return Object.values(data).filter(r => r.guildId === guildId);
    },

    // Kullanıcının girebileceğini kontrol et
    canJoin(channelId, userId) {
        const room = this.get(channelId);
        if (!room) return true;
        
        // Sahibi her zaman girebilir
        if (room.ownerId === userId) return true;
        
        // Engelliyse giremez
        if (room.settings.blockedUsers.includes(userId)) return false;
        
        // Kilitliyse ve izin verilmemişse giremez
        if (room.settings.locked && !room.settings.allowedUsers.includes(userId)) {
            return false;
        }
        
        return true;
    }
};
