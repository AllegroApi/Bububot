const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/applications.json');

// Data dosyası yoksa oluştur
if (!fs.existsSync(dataPath)) {
    fs.writeFileSync(dataPath, '[]', 'utf8');
}

function loadData() {
    try {
        const data = fs.readFileSync(dataPath, 'utf8');
        return JSON.parse(data);
    } catch {
        return [];
    }
}

function saveData(data) {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2), 'utf8');
}

module.exports = {
    // Başvuru oluştur
    create(data) {
        const applications = loadData();
        
        const application = {
            id: applications.length + 1,
            ...data,
            status: 'pending',
            createdAt: Date.now(),
            reviewedAt: null,
            reviewedBy: null,
            reviewNote: null
        };
        
        applications.push(application);
        saveData(applications);
        
        return application;
    },

    // Başvuru getir
    get(id) {
        const applications = loadData();
        return applications.find(a => a.id === id);
    },

    // Kullanıcının başvurularını getir
    getByUser(userId) {
        const applications = loadData();
        return applications.filter(a => a.userId === userId);
    },

    // Duruma göre getir
    getByStatus(status) {
        const applications = loadData();
        return applications.filter(a => a.status === status);
    },

    // Tüm başvuruları getir
    getAll() {
        return loadData();
    },

    // Başvuru güncelle
    update(id, updates) {
        const applications = loadData();
        const index = applications.findIndex(a => a.id === id);
        
        if (index === -1) return null;
        
        applications[index] = { ...applications[index], ...updates };
        saveData(applications);
        
        return applications[index];
    },

    // Başvuru onayla
    approve(id, reviewerId, note = null) {
        return this.update(id, {
            status: 'approved',
            reviewedAt: Date.now(),
            reviewedBy: reviewerId,
            reviewNote: note
        });
    },

    // Başvuru reddet
    reject(id, reviewerId, note = null) {
        return this.update(id, {
            status: 'rejected',
            reviewedAt: Date.now(),
            reviewedBy: reviewerId,
            reviewNote: note
        });
    },

    // Bekletmeye al
    hold(id, reviewerId, note = null) {
        return this.update(id, {
            status: 'hold',
            reviewedAt: Date.now(),
            reviewedBy: reviewerId,
            reviewNote: note
        });
    },

    // Başvuru sil
    delete(id) {
        const applications = loadData();
        const filtered = applications.filter(a => a.id !== id);
        saveData(filtered);
        return true;
    },

    // Kullanıcının aktif başvurusu var mı kontrol et
    hasActiveApplication(userId) {
        const applications = loadData();
        return applications.some(a => a.userId === userId && a.status === 'pending');
    }
};
