const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/tickets.json');

function ensureDataFile() {
    const dir = path.dirname(dataPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(dataPath)) {
        fs.writeFileSync(dataPath, '{"tickets": [], "counter": 0}');
    }
}

function loadData() {
    ensureDataFile();
    try {
        return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch {
        return { tickets: [], counter: 0 };
    }
}

function saveData(data) {
    ensureDataFile();
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

const PRIORITY_COLORS = {
    low: '🟢',
    medium: '🟡',
    high: '🔴'
};

const PRIORITY_NAMES = {
    low: 'Düşük',
    medium: 'Orta',
    high: 'Yüksek'
};

module.exports = {
    PRIORITY_COLORS,
    PRIORITY_NAMES,

    // Yeni ticket oluştur
    create(ticket) {
        const data = loadData();
        data.counter++;
        
        const newTicket = {
            id: data.counter,
            channelId: ticket.channelId,
            guildId: ticket.guildId,
            userId: ticket.userId,
            userTag: ticket.userTag,
            priority: ticket.priority || 'medium',
            subject: ticket.subject || 'Genel Destek',
            status: 'open',
            createdAt: Date.now(),
            closedAt: null,
            closedBy: null,
            claimedBy: null,
            messages: [],
            transcript: null
        };
        
        data.tickets.push(newTicket);
        saveData(data);
        return newTicket;
    },

    // Ticket al
    get(ticketId) {
        const data = loadData();
        return data.tickets.find(t => t.id === ticketId);
    },

    // Kanal ID'si ile ticket al
    getByChannel(channelId) {
        const data = loadData();
        return data.tickets.find(t => t.channelId === channelId);
    },

    // Kullanıcının açık ticketlarını al
    getByUser(userId, guildId = null) {
        const data = loadData();
        return data.tickets.filter(t => {
            if (t.userId !== userId) return false;
            if (guildId && t.guildId !== guildId) return false;
            return t.status === 'open';
        });
    },

    // Açık ticketları al
    getOpen(guildId = null) {
        const data = loadData();
        return data.tickets.filter(t => {
            if (t.status !== 'open') return false;
            if (guildId && t.guildId !== guildId) return false;
            return true;
        });
    },

    // Ticket'ı güncelle
    update(ticketId, updates) {
        const data = loadData();
        const ticket = data.tickets.find(t => t.id === ticketId);
        
        if (!ticket) return null;
        
        Object.assign(ticket, updates);
        saveData(data);
        return ticket;
    },

    // Ticket'ı kapat
    close(ticketId, closedBy) {
        const data = loadData();
        const ticket = data.tickets.find(t => t.id === ticketId);
        
        if (!ticket) return null;
        
        ticket.status = 'closed';
        ticket.closedAt = Date.now();
        ticket.closedBy = closedBy;
        
        saveData(data);
        return ticket;
    },

    // Ticket'ı sahiplen
    claim(ticketId, staffId, staffTag) {
        const data = loadData();
        const ticket = data.tickets.find(t => t.id === ticketId);
        
        if (!ticket) return null;
        
        ticket.claimedBy = { id: staffId, tag: staffTag, at: Date.now() };
        
        saveData(data);
        return ticket;
    },

    // Mesaj ekle (transcript için)
    addMessage(ticketId, message) {
        const data = loadData();
        const ticket = data.tickets.find(t => t.id === ticketId);
        
        if (!ticket) return null;
        
        ticket.messages.push({
            author: message.author,
            content: message.content,
            timestamp: Date.now()
        });
        
        // Son 100 mesajı tut
        if (ticket.messages.length > 100) {
            ticket.messages = ticket.messages.slice(-100);
        }
        
        saveData(data);
        return ticket;
    },

    // Transcript ayarla
    setTranscript(ticketId, transcriptUrl) {
        const data = loadData();
        const ticket = data.tickets.find(t => t.id === ticketId);
        
        if (!ticket) return null;
        
        ticket.transcript = transcriptUrl;
        saveData(data);
        return ticket;
    },

    // İstatistikler
    getStats(guildId) {
        const data = loadData();
        const guildTickets = data.tickets.filter(t => t.guildId === guildId);
        
        return {
            total: guildTickets.length,
            open: guildTickets.filter(t => t.status === 'open').length,
            closed: guildTickets.filter(t => t.status === 'closed').length,
            byPriority: {
                high: guildTickets.filter(t => t.priority === 'high').length,
                medium: guildTickets.filter(t => t.priority === 'medium').length,
                low: guildTickets.filter(t => t.priority === 'low').length
            }
        };
    },

    // Ticket sil
    delete(ticketId) {
        const data = loadData();
        const index = data.tickets.findIndex(t => t.id === ticketId);
        
        if (index === -1) return false;
        
        data.tickets.splice(index, 1);
        saveData(data);
        return true;
    }
};
