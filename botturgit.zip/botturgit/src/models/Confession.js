const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/confessions.json');

function ensureDataFile() {
    const dir = path.dirname(dataPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(dataPath)) {
        fs.writeFileSync(dataPath, '{"confessions": [], "counter": 0}');
    }
}

function loadData() {
    ensureDataFile();
    try {
        return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch {
        return { confessions: [], counter: 0 };
    }
}

function saveData(data) {
    ensureDataFile();
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

module.exports = {
    // Yeni itiraf oluştur
    create(confession) {
        const data = loadData();
        data.counter++;
        
        const newConfession = {
            id: data.counter,
            content: confession.content,
            authorId: confession.authorId, // Gizli tutulacak ama log için
            authorTag: confession.authorTag,
            guildId: confession.guildId,
            messageId: confession.messageId || null,
            createdAt: Date.now(),
            approved: true, // Otomatik onay (moderasyon eklenebilir)
            reactions: {
                likes: 0,
                dislikes: 0
            }
        };
        
        data.confessions.push(newConfession);
        saveData(data);
        return newConfession;
    },

    // İtiraf al
    get(confessionId) {
        const data = loadData();
        return data.confessions.find(c => c.id === confessionId);
    },

    // Mesaj ID'si ile al
    getByMessage(messageId) {
        const data = loadData();
        return data.confessions.find(c => c.messageId === messageId);
    },

    // Kullanıcının itiraflarını al (sadece log için)
    getByUser(authorId) {
        const data = loadData();
        return data.confessions.filter(c => c.authorId === authorId);
    },

    // Son itirafları al
    getRecent(guildId, limit = 10) {
        const data = loadData();
        return data.confessions
            .filter(c => c.guildId === guildId && c.approved)
            .sort((a, b) => b.createdAt - a.createdAt)
            .slice(0, limit);
    },

    // Mesaj ID'sini güncelle
    setMessageId(confessionId, messageId) {
        const data = loadData();
        const confession = data.confessions.find(c => c.id === confessionId);
        
        if (!confession) return null;
        
        confession.messageId = messageId;
        saveData(data);
        return confession;
    },

    // Reaksiyon güncelle
    updateReaction(confessionId, type, increment = true) {
        const data = loadData();
        const confession = data.confessions.find(c => c.id === confessionId);
        
        if (!confession) return null;
        
        if (type === 'like') {
            confession.reactions.likes += increment ? 1 : -1;
        } else if (type === 'dislike') {
            confession.reactions.dislikes += increment ? 1 : -1;
        }
        
        saveData(data);
        return confession;
    },

    // İtirafı sil (sadece adminler için)
    delete(confessionId) {
        const data = loadData();
        const index = data.confessions.findIndex(c => c.id === confessionId);
        
        if (index === -1) return false;
        
        data.confessions.splice(index, 1);
        saveData(data);
        return true;
    },

    // İstatistikler
    getStats(guildId) {
        const data = loadData();
        const guildConfessions = data.confessions.filter(c => c.guildId === guildId);
        
        return {
            total: guildConfessions.length,
            today: guildConfessions.filter(c => 
                Date.now() - c.createdAt < 24 * 60 * 60 * 1000
            ).length,
            thisWeek: guildConfessions.filter(c => 
                Date.now() - c.createdAt < 7 * 24 * 60 * 60 * 1000
            ).length
        };
    },

    // Kimin yazdığını bul (sadece yetkili komutu için)
    findAuthor(confessionId) {
        const data = loadData();
        const confession = data.confessions.find(c => c.id === confessionId);
        
        if (!confession) return null;
        
        return {
            id: confession.authorId,
            tag: confession.authorTag,
            createdAt: confession.createdAt
        };
    }
};
