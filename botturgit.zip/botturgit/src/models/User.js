const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/users.json');

// Data klasörünü ve dosyayı oluştur
function ensureDataFile() {
    const dir = path.dirname(dataPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(dataPath)) {
        fs.writeFileSync(dataPath, '{}');
    }
}

function loadUsers() {
    ensureDataFile();
    try {
        return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    } catch {
        return {};
    }
}

function saveUsers(users) {
    ensureDataFile();
    fs.writeFileSync(dataPath, JSON.stringify(users, null, 2));
}

// Seviye için gereken XP hesapla
function xpForLevel(level) {
    return Math.floor(100 * Math.pow(level, 1.5));
}

// Toplam XP'den seviye hesapla
function calculateLevel(xp) {
    let level = 0;
    let totalXpNeeded = 0;
    while (totalXpNeeded <= xp) {
        level++;
        totalXpNeeded += xpForLevel(level);
    }
    return level - 1;
}

module.exports = {
    // Kullanıcı bilgisi al
    get(userId) {
        const users = loadUsers();
        if (!users[userId]) {
            users[userId] = {
                xp: 0,
                level: 0,
                messages: 0,
                lastXpTime: 0,
                warnings: [],
                hasTag: false,
                voiceTime: 0
            };
            saveUsers(users);
        }
        return users[userId];
    },

    // Kullanıcı güncelle
    update(userId, data) {
        const users = loadUsers();
        users[userId] = { ...this.get(userId), ...data };
        saveUsers(users);
        return users[userId];
    },

    // XP ekle ve seviye atlama kontrolü
    addXp(userId, amount) {
        const users = loadUsers();
        const user = this.get(userId);
        const oldLevel = user.level;
        
        user.xp += amount;
        user.messages += 1;
        user.level = calculateLevel(user.xp);
        user.lastXpTime = Date.now();
        
        users[userId] = user;
        saveUsers(users);

        return {
            user,
            leveledUp: user.level > oldLevel,
            oldLevel,
            newLevel: user.level
        };
    },

    // Leaderboard al
    getLeaderboard(limit = 10) {
        const users = loadUsers();
        return Object.entries(users)
            .map(([id, data]) => ({ id, ...data }))
            .sort((a, b) => b.xp - a.xp)
            .slice(0, limit);
    },

    // Sıralama al
    getRank(userId) {
        const users = loadUsers();
        const sorted = Object.entries(users)
            .map(([id, data]) => ({ id, ...data }))
            .sort((a, b) => b.xp - a.xp);
        
        return sorted.findIndex(u => u.id === userId) + 1;
    },

    // Seviye için gereken XP
    getXpForNextLevel(userId) {
        const user = this.get(userId);
        let totalXpNeeded = 0;
        for (let i = 1; i <= user.level + 1; i++) {
            totalXpNeeded += xpForLevel(i);
        }
        return totalXpNeeded - user.xp;
    },

    // Progress hesapla
    getProgress(userId) {
        const user = this.get(userId);
        let xpForCurrentLevel = 0;
        for (let i = 1; i <= user.level; i++) {
            xpForCurrentLevel += xpForLevel(i);
        }
        const xpInCurrentLevel = user.xp - xpForCurrentLevel;
        const xpNeededForNext = xpForLevel(user.level + 1);
        return {
            current: xpInCurrentLevel,
            needed: xpNeededForNext,
            percentage: Math.floor((xpInCurrentLevel / xpNeededForNext) * 100)
        };
    },

    xpForLevel,
    calculateLevel
};
