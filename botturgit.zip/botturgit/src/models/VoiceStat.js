const { Schema, model } = require("mongoose");

const voiceStatSchema = new Schema({
  userId: { type: String, required: true, unique: true },
  totalVoice: { type: Number, default: 0 }, // saniye
  lastJoin: { type: Number, default: null }
});

module.exports = model("VoiceStat", voiceStatSchema);
