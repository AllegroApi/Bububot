const tagSystem = require('../systems/tagSystem');
const boosterSystem = require('../systems/boosterSystem');
const logSystem = require('../systems/logSystem');

module.exports = {
    name: 'guildMemberUpdate',
    async execute(oldMember, newMember, client) {
        // İsim/Nickname değişikliği - Tag kontrolü
        const oldName = oldMember.nickname || oldMember.user.username;
        const newName = newMember.nickname || newMember.user.username;
        
        if (oldName !== newName) {
            await tagSystem.checkTag(newMember, client);
            
            // Nick değişikliği logu
            await logSystem.send(client, 'nickChange', {
                user: newMember.user,
                oldNick: oldMember.nickname || oldMember.user.username,
                newNick: newMember.nickname || newMember.user.username
            });
        }

        // Rol değişikliği kontrolü
        const oldRoles = oldMember.roles.cache;
        const newRoles = newMember.roles.cache;
        
        // Eklenen roller
        newRoles.forEach(role => {
            if (!oldRoles.has(role.id)) {
                logSystem.send(client, 'roleAdd', {
                    user: newMember.user,
                    role: role
                });
            }
        });
        
        // Kaldırılan roller
        oldRoles.forEach(role => {
            if (!newRoles.has(role.id)) {
                logSystem.send(client, 'roleRemove', {
                    user: newMember.user,
                    role: role
                });
            }
        });

        // Timeout kontrolü
        if (!oldMember.communicationDisabledUntil && newMember.communicationDisabledUntil) {
            await logSystem.send(client, 'memberTimeout', {
                user: newMember.user,
                until: newMember.communicationDisabledUntilTimestamp
            });
        }

        // Boost durumu kontrolü
        const wasBooster = oldMember.premiumSince;
        const isBooster = newMember.premiumSince;
        
        if (!wasBooster && isBooster) {
            await logSystem.send(client, 'boost', {
                user: newMember.user,
                boostCount: newMember.guild.premiumSubscriptionCount,
                boostTier: newMember.guild.premiumTier
            });
        }

        await boosterSystem.handleBoostChange(oldMember, newMember, client);
    }
};
