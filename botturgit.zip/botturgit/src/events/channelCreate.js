const logSystem = require('../systems/logSystem');

const channelTypes = {
    0: 'Metin Kanalı',
    2: 'Ses Kanalı',
    4: 'Kategori',
    5: 'Duyuru Kanalı',
    10: 'Duyuru Thread',
    11: 'Public Thread',
    12: 'Private Thread',
    13: 'Stage Kanalı',
    14: 'Dizin',
    15: 'Forum Kanalı'
};

module.exports = {
    name: 'channelCreate',
    async execute(channel, client) {
        if (!channel.guild) return; // DM kanallarını atla

        await logSystem.send(client, 'channelCreate', {
            channel,
            type: channelTypes[channel.type] || 'Bilinmeyen'
        });
    }
};
