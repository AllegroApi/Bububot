const logSystem = require('../systems/logSystem');

module.exports = {
    name: 'guildBanAdd',
    async execute(ban, client) {
        await logSystem.send(client, 'memberBan', {
            user: ban.user,
            reason: ban.reason
        });
    }
};
