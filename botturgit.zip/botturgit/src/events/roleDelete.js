const logSystem = require('../systems/logSystem');

module.exports = {
    name: 'roleDelete',
    async execute(role, client) {
        await logSystem.send(client, 'roleDelete', {
            name: role.name,
            id: role.id
        });
    }
};
