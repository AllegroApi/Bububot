const fs = require("fs");
const path = require("path");
const privateVoiceSystem = require('../systems/privateVoiceSystem');
const UserModel = require('../models/User');
const logSystem = require('../systems/logSystem');

const statsPath = path.join(__dirname, "../utils/voiceStats.json");

function loadStats() {
  if (!fs.existsSync(statsPath)) fs.writeFileSync(statsPath, "{}");
  return JSON.parse(fs.readFileSync(statsPath));
}

function saveStats(stats) {
  fs.writeFileSync(statsPath, JSON.stringify(stats, null, 2));
}

module.exports = {
  name: "voiceStateUpdate",
  async execute(oldState, newState, client) {
    const member = newState.member || oldState.member;
    if (!member || member.user.bot) return;
    
    const userId = newState.id;
    const stats = loadStats();

    // Kullanıcı yoksa ekle
    if (!stats[userId]) {
      stats[userId] = {
        totalVoice: 0,
        lastJoin: null
      };
    }

    // 🔹 Sese girdi
    if (!oldState.channel && newState.channel) {
      stats[userId].lastJoin = Date.now();
      saveStats(stats);
      
      // Log gönder
      await logSystem.send(client, 'voiceJoin', {
        user: member.user,
        channel: newState.channel
      });
      
      // Özel oda sistemi
      await privateVoiceSystem.handleVoiceJoin(member, newState.channel, client);
    }

    // 🔹 Sesten çıktı
    if (oldState.channel && !newState.channel) {
      const data = stats[userId];
      if (data.lastJoin) {
        const duration = Math.floor((Date.now() - data.lastJoin) / 1000);
        data.totalVoice += duration;
        data.lastJoin = null;
        saveStats(stats);
        
        // User model'e de kaydet (ms cinsinden)
        const userData = UserModel.get(userId);
        UserModel.update(userId, { voiceTime: (userData.voiceTime || 0) + (duration * 1000) });
      }
      
      // Log gönder
      await logSystem.send(client, 'voiceLeave', {
        user: member.user,
        channel: oldState.channel
      });
      
      // Özel oda sistemi
      await privateVoiceSystem.handleVoiceLeave(member, oldState.channel, client);
    }

    // 🔹 Kanal değiştirdi
    if (oldState.channel && newState.channel && oldState.channelId !== newState.channelId) {
      // Log gönder
      await logSystem.send(client, 'voiceMove', {
        user: member.user,
        oldChannel: oldState.channel,
        newChannel: newState.channel
      });
      
      // Eski kanaldan çıkış işlemi
      await privateVoiceSystem.handleVoiceLeave(member, oldState.channel, client);
      // Yeni kanala giriş işlemi
      await privateVoiceSystem.handleVoiceJoin(member, newState.channel, client);
    }
  }
};
