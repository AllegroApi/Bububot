const logSystem = require('../systems/logSystem');

module.exports = {
    name: 'roleCreate',
    async execute(role, client) {
        await logSystem.send(client, 'roleCreate', {
            role,
            color: role.hexColor
        });
    }
};
