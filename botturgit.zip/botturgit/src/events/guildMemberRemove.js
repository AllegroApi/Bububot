const logSystem = require('../systems/logSystem');

module.exports = {
    name: 'guildMemberRemove',
    async execute(member, client) {
        // Rolleri al
        const roles = member.roles.cache
            .filter(r => r.id !== member.guild.id)
            .map(r => r.toString())
            .slice(0, 10)
            .join(', ') || 'Yok';

        await logSystem.send(client, 'memberLeave', {
            user: member.user,
            memberCount: member.guild.memberCount,
            joinedAt: member.joinedTimestamp,
            roles
        });
    }
};
