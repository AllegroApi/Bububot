const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");
const logSystem = require('../systems/logSystem');
const antiRaid = require('../systems/antiraid');

module.exports = {
  name: "guildMemberAdd",
  async execute(member, client) {

    // 🛡️ Anti-Raid kontrolü
    const raidCheck = await antiRaid.checkJoin(member, client);
    if (!raidCheck.safe) {
      console.log(`⚠️ Şüpheli katılım: ${member.user.tag} - Sebep: ${raidCheck.reason}`);
      
      // Yeni hesapsa uyarı logu
      if (raidCheck.reason === 'new_account') {
        await logSystem.send(client, 'memberJoin', {
          user: member.user,
          memberCount: member.guild.memberCount,
          warning: `⚠️ Yeni hesap! (${raidCheck.accountAge?.toFixed(1)} gün)`
        });
      }
      
      // Raid algılandıysa zaten antiraid sistemi işlem yapmış olacak
      if (raidCheck.reason === 'raid_detected') return;
    }

    // Log gönder
    await logSystem.send(client, 'memberJoin', {
      user: member.user,
      memberCount: member.guild.memberCount
    });

    // 🔧 AYARLAR
    const WELCOME_CHANNEL_ID = "1235987843587772418";
    const RULES_CHANNEL_ID = "1385186245877170219";
    const AUTO_ROLE_ID = "1381391335642366043";

    const channel = member.guild.channels.cache.get(WELCOME_CHANNEL_ID);
    if (!channel) return;

    // 🕒 Hesap açılma tarihi
    const accountCreated = `<t:${Math.floor(member.user.createdAt.getTime() / 1000)}:R>`;

    // 🔘 Kurallar butonu
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel("📜 Kurallara Git")
        .setStyle(ButtonStyle.Link)
        .setURL(
          `https://discord.com/channels/${member.guild.id}/${RULES_CHANNEL_ID}`
        )
    );

    // 📤 Mesaj (embedsiz)
    await channel.send({
      content:
        `🎉 **Sunucumuza Hoş Geldin!**\n\n` +
        `👋 Hoş geldin ${member}!\n\n` +
        `📌 Sunucuda keyifli vakit geçirmek için **kuralları okumayı unutma**.\n\n` +
        `🕒 **Hesap Oluşturulma:** ${accountCreated}`,
      components: [row]
    });

    // 🎭 Otomatik rol
    try {
      await member.roles.add(AUTO_ROLE_ID);
    } catch (err) {
      console.error("Rol verilemedi:", err);
    }
  }
};
