const logSystem = require('../systems/logSystem');

module.exports = {
    name: 'guildBanRemove',
    async execute(ban, client) {
        await logSystem.send(client, 'memberUnban', {
            user: ban.user
        });
    }
};
