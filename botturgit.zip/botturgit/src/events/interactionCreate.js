const fs = require('fs');
const path = require('path');
const confessionSystem = require('../systems/confessionSystem');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        // Slash komutlar
        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command?.executeSlash) return;

            try {
                await command.executeSlash(interaction, client);
            } catch (err) {
                console.error(`Slash komut hatası (${interaction.commandName}):`, err);
                try {
                    const errorResponse = { content: '❌ Bir hata oluştu.', flags: 64 };
                    if (interaction.replied || interaction.deferred) {
                        await interaction.followUp(errorResponse).catch(() => {});
                    } else {
                        await interaction.reply(errorResponse).catch(() => {});
                    }
                } catch (e) {
                    // Interaction expired, ignore
                }
            }
            return;
        }

        // Buton etkileşimleri
        if (interaction.isButton()) {
            // İtiraf like/dislike kontrolü
            if (interaction.customId.startsWith('confession_like_')) {
                const confessionId = parseInt(interaction.customId.split('_')[2]);
                await confessionSystem.updateReaction(confessionId, 'like', true, client);
                return interaction.deferUpdate();
            }
            if (interaction.customId.startsWith('confession_dislike_')) {
                const confessionId = parseInt(interaction.customId.split('_')[2]);
                await confessionSystem.updateReaction(confessionId, 'dislike', true, client);
                return interaction.deferUpdate();
            }

            // Button handler
            const buttonsPath = path.join(__dirname, '../interactions/buttons');
            if (fs.existsSync(buttonsPath)) {
                const buttonFiles = fs.readdirSync(buttonsPath).filter(f => f.endsWith('.js'));
                
                for (const file of buttonFiles) {
                    const button = require(path.join(buttonsPath, file));
                    
                    // Tek customId veya customIds array kontrolü
                    let matches = false;
                    if (button.customId === interaction.customId) {
                        matches = true;
                    } else if (button.data?.customIds && button.data.customIds.includes(interaction.customId)) {
                        matches = true;
                    } else if (button.data?.customId === interaction.customId) {
                        matches = true;
                    }
                    
                    if (matches) {
                        try {
                            await button.execute(interaction, client);
                        } catch (err) {
                            console.error(`Buton hatası (${interaction.customId}):`, err);
                            if (!interaction.replied && !interaction.deferred) {
                                await interaction.reply({ content: '❌ Bir hata oluştu.', flags: 64 }).catch(() => {});
                            }
                        }
                        return;
                    }
                }
            }
            return;
        }

        // Modal etkileşimleri
        if (interaction.isModalSubmit()) {
            // Dinamik başvuru red modal kontrolü
            if (interaction.customId.startsWith('basvuru_red_sebep_')) {
                const appId = parseInt(interaction.customId.split('_')[3]);
                const redSebepModal = require('../interactions/modals/redSebepModal');
                try {
                    await redSebepModal.execute(interaction, client, appId);
                } catch (err) {
                    console.error('Red sebep modal hatası:', err);
                }
                return;
            }

            const modalsPath = path.join(__dirname, '../interactions/modals');
            if (fs.existsSync(modalsPath)) {
                const modalFiles = fs.readdirSync(modalsPath).filter(f => f.endsWith('.js'));
                
                for (const file of modalFiles) {
                    const modal = require(path.join(modalsPath, file));
                    if (modal.customId === interaction.customId) {
                        try {
                            await modal.execute(interaction, client);
                        } catch (err) {
                            console.error(`Modal hatası (${interaction.customId}):`, err);
                            if (!interaction.replied && !interaction.deferred) {
                                await interaction.reply({ content: '❌ Bir hata oluştu.', flags: 64 }).catch(() => {});
                            }
                        }
                        return;
                    }
                }
            }
            return;
        }

        // Select menu etkileşimleri
        if (interaction.isUserSelectMenu() || interaction.isStringSelectMenu() || interaction.isRoleSelectMenu()) {
            const selectsPath = path.join(__dirname, '../interactions/selects');
            if (fs.existsSync(selectsPath)) {
                const selectFiles = fs.readdirSync(selectsPath).filter(f => f.endsWith('.js'));
                
                for (const file of selectFiles) {
                    const select = require(path.join(selectsPath, file));
                    
                    // Tek customId veya data.customId kontrolü
                    const selectCustomId = select.customId || select.data?.customId;
                    
                    if (selectCustomId === interaction.customId) {
                        try {
                            await select.execute(interaction, client);
                        } catch (err) {
                            console.error(`Select hatası (${interaction.customId}):`, err);
                            if (!interaction.replied && !interaction.deferred) {
                                await interaction.reply({ content: '❌ Bir hata oluştu.', flags: 64 }).catch(() => {});
                            }
                        }
                        return;
                    }
                }
            }
            return;
        }
    }
};
