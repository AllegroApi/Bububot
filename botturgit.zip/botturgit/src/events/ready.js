module.exports = {
  name: "ready",
  once: true,
  execute(client) {
    console.log(`🤖 Giriş yapıldı: ${client.user.tag}`);
  }
};
