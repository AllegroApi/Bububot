const game = require("../game/sonHarf");
const levelSystem = require("../systems/levelSystem");
const antiSpam = require("../systems/antispam");
const autoMod = require("../systems/automod");

const prefix = ".";

module.exports = {
  name: "messageCreate",
  async execute(message, client) {
    if (message.author.bot) return;

    // 🛡️ Anti-Spam kontrolü
    const spamResult = await antiSpam.checkMessage(message, client);
    if (spamResult.spam) return; // Spam ise devam etme

    // 🛡️ AutoMod kontrolü
    const modResult = await autoMod.checkMessage(message, client);
    if (modResult.violation) return; // İhlal varsa devam etme

    // Seviye sistemi - her mesajda XP ver
    await levelSystem.handleMessage(message, client);

    // 🔹 PREFIX KOMUTLAR
    if (message.content.startsWith(prefix)) {
      const args = message.content.slice(prefix.length).trim().split(/ +/);
      const commandName = args.shift().toLowerCase();
      
      // Komut veya alias'a bak
      const command = client.commands.get(commandName) ||
                      client.commands.find(c => c.aliases && c.aliases.includes(commandName));
      
      if (command?.executePrefix) {
        try {
          await command.executePrefix(message, args, client);
        } catch (err) {
          console.error(`Prefix komut hatası (${commandName}):`, err);
          message.reply("❌ Bir hata oluştu.").catch(() => {});
        }
        return;
      }
    }

    // Kelime oyunu
    if (!game.active) return;
    if (message.channelId !== game.channelId) return;

    const word = message.content.toLowerCase().trim();

    if (!/^[a-zçğıöşü]+$/i.test(word)) return;

    // ğ ile bitiyorsa
    if (word.endsWith("ğ")) {
      return message.reply("❌ Kelime **ğ** ile bitemez.");
    }

    // tekrar kontrolü
    if (game.usedWords.has(word)) {
      return message.reply("❌ Bu kelime zaten kullanıldı.");
    }

    // son harf kontrolü
    if (game.lastWord) {
      const lastChar = game.lastWord.slice(-1);
      if (!word.startsWith(lastChar)) {
        return message.reply(
          `❌ Kelime **${lastChar}** harfiyle başlamalı.`
        );
      }
    }

    // kabul
    game.usedWords.add(word);
    game.lastWord = word;

    game.scores[message.author.id] =
      (game.scores[message.author.id] || 0) + 1;

    message.react("✅");
  }
};
