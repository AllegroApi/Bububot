const logSystem = require('../systems/logSystem');

module.exports = {
    name: 'messageDelete',
    async execute(message, client) {
        // Bot mesajlarını ve partial mesajları atla
        if (!message.author || message.author.bot) return;
        if (message.partial) return;

        await logSystem.send(client, 'messageDelete', {
            author: message.author,
            channel: message.channel,
            content: message.content || '*Embed/Dosya*'
        });
    }
};
