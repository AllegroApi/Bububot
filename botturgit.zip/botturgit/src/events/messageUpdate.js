const logSystem = require('../systems/logSystem');

module.exports = {
    name: 'messageUpdate',
    async execute(oldMessage, newMessage, client) {
        // Bot mesajlarını ve partial mesajları atla
        if (!oldMessage.author || oldMessage.author.bot) return;
        if (oldMessage.partial || newMessage.partial) return;
        
        // İçerik değişmediyse atla (sadece embed güncellemesi olabilir)
        if (oldMessage.content === newMessage.content) return;

        await logSystem.send(client, 'messageEdit', {
            author: newMessage.author,
            channel: newMessage.channel,
            url: newMessage.url,
            oldContent: oldMessage.content || '*Boş*',
            newContent: newMessage.content || '*Boş*'
        });
    }
};
