const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const PrivateVoiceModel = require('../../models/PrivateVoice');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_limit',
    
    async execute(interaction, client) {
        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        const modal = new ModalBuilder()
            .setCustomId('pv_limit_modal')
            .setTitle('👤 Kullanıcı Limiti');

        const limitInput = new TextInputBuilder()
            .setCustomId('limit_value')
            .setLabel('Kullanıcı limiti (0 = sınırsız)')
            .setPlaceholder('0-99 arası bir sayı girin')
            .setStyle(TextInputStyle.Short)
            .setMaxLength(2)
            .setRequired(true);

        const row = new ActionRowBuilder().addComponents(limitInput);
        modal.addComponents(row);

        await interaction.showModal(modal);
    }
};
