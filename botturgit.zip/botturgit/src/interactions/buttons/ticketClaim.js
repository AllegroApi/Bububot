const ticketSystem = require('../../systems/ticketSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'ticket_claim',
    
    async execute(interaction, client) {
        const result = await ticketSystem.claim(interaction.channel.id, interaction.user, client);
        
        if (!result.success) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', result.message)],
                ephemeral: true
            });
        }

        await interaction.reply({
            embeds: [embedUtil.success('Sahiplenildi', `Bu ticket ${interaction.user} tarafından sahiplenildi.`)]
        });
    }
};
