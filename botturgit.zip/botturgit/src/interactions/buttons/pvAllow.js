const { UserSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const PrivateVoiceModel = require('../../models/PrivateVoice');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_allow',
    
    async execute(interaction, client) {
        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        const selectMenu = new UserSelectMenuBuilder()
            .setCustomId('pv_allow_select')
            .setPlaceholder('İzin vermek istediğiniz kullanıcıları seçin')
            .setMinValues(1)
            .setMaxValues(10);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        await interaction.reply({
            content: '👥 Odanıza izin vermek istediğiniz kullanıcıları seçin:',
            components: [row],
            ephemeral: true
        });
    }
};
