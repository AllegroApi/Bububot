const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const ApplicationModel = require('../../models/Application');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'basvuru_red',
    
    async execute(interaction, client) {
        // Başvuru ID'sini mesajdan al
        const appId = parseInt(interaction.message.embeds[0]?.footer?.text?.match(/ID: (\d+)/)?.[1]);
        
        if (!appId) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Başvuru ID\'si bulunamadı!')],
                flags: 64
            });
        }

        const application = ApplicationModel.get(appId);
        
        if (!application || application.status !== 'pending') {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Başvuru bulunamadı veya zaten işlenmiş!')],
                flags: 64
            });
        }

        // Sebep modalı göster
        const modal = new ModalBuilder()
            .setCustomId(`basvuru_red_sebep_${appId}`)
            .setTitle('📝 Red Sebebi');

        const sebepInput = new TextInputBuilder()
            .setCustomId('sebep')
            .setLabel('Red Sebebi')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Başvurunun neden reddedildiğini yazın')
            .setMinLength(10)
            .setMaxLength(500)
            .setRequired(true);

        modal.addComponents(new ActionRowBuilder().addComponents(sebepInput));

        await interaction.showModal(modal);
    }
};
