const { UserSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const PrivateVoiceModel = require('../../models/PrivateVoice');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_block',
    
    async execute(interaction, client) {
        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        const selectMenu = new UserSelectMenuBuilder()
            .setCustomId('pv_block_select')
            .setPlaceholder('Engellemek istediğiniz kullanıcıları seçin')
            .setMinValues(1)
            .setMaxValues(10);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        await interaction.reply({
            content: '🚫 Odanızdan engellemek istediğiniz kullanıcıları seçin:',
            components: [row],
            ephemeral: true
        });
    }
};
