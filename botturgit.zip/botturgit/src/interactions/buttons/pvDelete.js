const PrivateVoiceModel = require('../../models/PrivateVoice');
const privateVoiceSystem = require('../../systems/privateVoiceSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_delete',
    
    async execute(interaction, client) {
        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        await privateVoiceSystem.deletePrivateRoom(room.channelId, client);

        await interaction.reply({
            embeds: [embedUtil.success('Oda Silindi', 'Özel odanız başarıyla silindi.')],
            ephemeral: true
        });
    }
};
