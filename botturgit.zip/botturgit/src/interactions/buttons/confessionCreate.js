const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
    customId: 'confession_create',
    
    async execute(interaction, client) {
        const modal = new ModalBuilder()
            .setCustomId('confession_modal')
            .setTitle('🤫 Anonim İtiraf');

        const confessionInput = new TextInputBuilder()
            .setCustomId('confession_content')
            .setLabel('İtirafını yaz')
            .setPlaceholder('İçini dök... Kimse bilmeyecek.')
            .setStyle(TextInputStyle.Paragraph)
            .setMinLength(10)
            .setMaxLength(1000)
            .setRequired(true);

        const row = new ActionRowBuilder().addComponents(confessionInput);
        modal.addComponents(row);

        await interaction.showModal(modal);
    }
};
