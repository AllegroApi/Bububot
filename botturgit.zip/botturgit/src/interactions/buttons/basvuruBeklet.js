const { EmbedBuilder } = require('discord.js');
const ApplicationModel = require('../../models/Application');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'basvuru_beklet',
    
    async execute(interaction, client) {
        await interaction.deferReply({ flags: 64 });

        // Başvuru ID'sini mesajdan al
        const appId = parseInt(interaction.message.embeds[0]?.footer?.text?.match(/ID: (\d+)/)?.[1]);
        
        if (!appId) {
            return interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Başvuru ID\'si bulunamadı!')]
            });
        }

        const application = ApplicationModel.get(appId);
        
        if (!application) {
            return interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Başvuru bulunamadı!')]
            });
        }

        if (application.status !== 'pending') {
            return interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Bu başvuru zaten işlenmiş!')]
            });
        }

        // Başvuruyu bekletmeye al
        ApplicationModel.hold(appId, interaction.user.id);

        // Mesajı güncelle
        const embed = EmbedBuilder.from(interaction.message.embeds[0])
            .setColor('#FEE75C')
            .setTitle('⏳ Başvuru Beklemede');
        
        await interaction.message.edit({ embeds: [embed], components: [] });

        await interaction.editReply({
            embeds: [embedUtil.success('Başarılı', 'Başvuru bekletmeye alındı!')]
        });
    }
};
