const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const ApplicationModel = require('../../models/Application');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'basvuru_ac',
    
    async execute(interaction, client) {
        // Zaten aktif başvurusu var mı kontrol et
        if (ApplicationModel.hasActiveApplication(interaction.user.id)) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Zaten bekleyen bir başvurunuz var!')],
                flags: 64
            });
        }

        // Modal oluştur
        const modal = new ModalBuilder()
            .setCustomId('basvuru_form')
            .setTitle('📝 Yetkili Başvuru Formu');

        const yasInput = new TextInputBuilder()
            .setCustomId('yas')
            .setLabel('Yaşınız')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Örn: 18')
            .setMinLength(1)
            .setMaxLength(3)
            .setRequired(true);

        const deneyimInput = new TextInputBuilder()
            .setCustomId('deneyim')
            .setLabel('Discord Yetkililik Deneyiminiz')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Daha önce yetkili oldunuz mu? Hangi sunucularda?')
            .setMinLength(20)
            .setMaxLength(500)
            .setRequired(true);

        const nedenInput = new TextInputBuilder()
            .setCustomId('neden')
            .setLabel('Neden Yetkili Olmak İstiyorsunuz?')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Motivasyonunuzu ve sunucuya nasıl katkı sağlayacağınızı yazın')
            .setMinLength(50)
            .setMaxLength(1000)
            .setRequired(true);

        const aktiflikInput = new TextInputBuilder()
            .setCustomId('aktiflik')
            .setLabel('Günlük Aktiflik Süreniz')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Örn: 4-5 saat')
            .setMinLength(3)
            .setMaxLength(50)
            .setRequired(true);

        const ekInput = new TextInputBuilder()
            .setCustomId('ek')
            .setLabel('Eklemek İstediğiniz Bir Şey Var mı?')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('İsteğe bağlı')
            .setMaxLength(500)
            .setRequired(false);

        modal.addComponents(
            new ActionRowBuilder().addComponents(yasInput),
            new ActionRowBuilder().addComponents(deneyimInput),
            new ActionRowBuilder().addComponents(nedenInput),
            new ActionRowBuilder().addComponents(aktiflikInput),
            new ActionRowBuilder().addComponents(ekInput)
        );

        await interaction.showModal(modal);
    }
};
