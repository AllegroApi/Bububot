const { 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle, 
    ActionRowBuilder,
    UserSelectMenuBuilder 
} = require('discord.js');
const PrivateVoiceModel = require('../../models/PrivateVoice');
const privateVoiceSystem = require('../../systems/privateVoiceSystem');
const embedUtil = require('../../utils/embed');

// Kilitle/Aç butonu
module.exports = {
    customId: 'pv_lock',
    
    async execute(interaction, client) {
        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        const updatedRoom = await privateVoiceSystem.lockRoom(room.channelId, client);
        
        await interaction.reply({
            embeds: [embedUtil.success(
                updatedRoom.settings.locked ? '🔒 Oda Kilitlendi' : '🔓 Kilit Açıldı',
                updatedRoom.settings.locked 
                    ? 'Artık sadece izin verdiğiniz kişiler girebilir.'
                    : 'Artık herkes odanıza girebilir.'
            )],
            ephemeral: true
        });
    }
};
