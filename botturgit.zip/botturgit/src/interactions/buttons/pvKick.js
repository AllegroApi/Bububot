const { UserSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const PrivateVoiceModel = require('../../models/PrivateVoice');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_kick',
    
    async execute(interaction, client) {
        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        const channel = client.channels.cache.get(room.channelId);
        if (!channel || channel.members.size <= 1) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Odada atacak kimse yok!')],
                ephemeral: true
            });
        }

        const selectMenu = new UserSelectMenuBuilder()
            .setCustomId('pv_kick_select')
            .setPlaceholder('Atmak istediğiniz kullanıcıları seçin')
            .setMinValues(1)
            .setMaxValues(Math.min(channel.members.size - 1, 10));

        const row = new ActionRowBuilder().addComponents(selectMenu);

        await interaction.reply({
            content: '👢 Odanızdan atmak istediğiniz kullanıcıları seçin:',
            components: [row],
            ephemeral: true
        });
    }
};
