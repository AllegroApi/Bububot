const ticketSystem = require('../../systems/ticketSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'ticket_create_low',
    
    async execute(interaction, client) {
        await interaction.deferReply({ flags: 64 });
        
        try {
            const result = await ticketSystem.create(interaction.member, 'low', client);
            
            if (!result.success) {
                return interaction.editReply({
                    embeds: [embedUtil.error('Hata', result.message)]
                });
            }

            await interaction.editReply({
                embeds: [embedUtil.success('Ticket Oluşturuldu', `Ticket'ınız oluşturuldu: ${result.channel}`)]
            });
        } catch (err) {
            console.error('Ticket oluşturma hatası:', err);
            await interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Ticket oluşturulurken bir hata oluştu.')]
            }).catch(() => {});
        }
    }
};
