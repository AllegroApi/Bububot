const { EmbedBuilder } = require('discord.js');
const musicSystem = require('../../systems/musicSystem');

module.exports = {
    data: {
        customIds: ['music_pause', 'music_skip', 'music_stop', 'music_queue', 'music_loop', 'music_resume']
    },

    async execute(interaction, client) {
        const guild = interaction.guild;
        const member = interaction.member;
        const customId = interaction.customId;

        // Ses kanalı kontrolü
        if (!member.voice.channel) {
            return interaction.reply({ 
                content: '❌ Önce bir ses kanalına katılmalısın!', 
                flags: 64 
            });
        }

        const queue = musicSystem.getQueue(guild.id);

        // Bot aynı kanalda mı?
        if (queue.voiceChannel && member.voice.channel.id !== queue.voiceChannel.id) {
            return interaction.reply({ 
                content: '❌ Bot ile aynı ses kanalında olmalısın!', 
                flags: 64 
            });
        }

        switch (customId) {
            case 'music_pause': {
                if (!queue.playing) {
                    return interaction.reply({ content: '❌ Çalan şarkı yok!', flags: 64 });
                }

                if (queue.paused) {
                    queue.resume();
                    await interaction.reply({ 
                        embeds: [
                            new EmbedBuilder()
                                .setColor('#57F287')
                                .setDescription('▶️ Müzik devam ediyor!')
                        ]
                    });
                } else {
                    queue.pause();
                    await interaction.reply({ 
                        embeds: [
                            new EmbedBuilder()
                                .setColor('#FEE75C')
                                .setDescription('⏸️ Müzik duraklatıldı!')
                        ]
                    });
                }
                break;
            }

            case 'music_skip': {
                if (!queue.playing) {
                    return interaction.reply({ content: '❌ Çalan şarkı yok!', flags: 64 });
                }

                const skipped = queue.currentSong;
                queue.skip();

                await interaction.reply({ 
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#FFA500')
                            .setDescription(`⏭️ **${skipped?.title || 'Şarkı'}** geçildi!`)
                    ]
                });
                break;
            }

            case 'music_stop': {
                musicSystem.deleteQueue(guild.id);

                await interaction.reply({ 
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#ED4245')
                            .setDescription('⏹️ Müzik durduruldu ve kuyruk temizlendi!')
                    ]
                });
                break;
            }

            case 'music_queue': {
                if (!queue.playing && queue.songs.length === 0) {
                    return interaction.reply({ content: '📋 Kuyruk boş!', flags: 64 });
                }

                const songs = queue.songs.slice(0, 10);
                const current = queue.currentSong;

                let description = '';
                
                if (current) {
                    description += `**🎵 Şimdi Çalıyor:**\n[${current.title}](${current.url})\n\n`;
                }

                if (songs.length > 0) {
                    description += '**📋 Sıradakiler:**\n';
                    description += songs.map((song, i) => 
                        `**${i + 1}.** ${song.title.substring(0, 40)}... - \`${song.duration}\``
                    ).join('\n');
                }

                if (queue.songs.length > 10) {
                    description += `\n\n*...ve ${queue.songs.length - 10} şarkı daha*`;
                }

                await interaction.reply({ 
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#FF0000')
                            .setTitle(`🎶 Kuyruk (${queue.songs.length} şarkı)`)
                            .setDescription(description || 'Kuyruk boş!')
                    ],
                    flags: 64
                });
                break;
            }

            case 'music_loop': {
                // Toggle loop modes
                if (!queue.loop && !queue.loopQueue) {
                    queue.loop = true;
                } else if (queue.loop) {
                    queue.loop = false;
                    queue.loopQueue = true;
                } else {
                    queue.loopQueue = false;
                }

                const status = queue.loop ? '🔂 Tek şarkı tekrarı açık' : 
                               (queue.loopQueue ? '🔁 Kuyruk tekrarı açık' : '▶️ Tekrar kapalı');

                await interaction.reply({ 
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#57F287')
                            .setDescription(status)
                    ]
                });
                break;
            }

            case 'music_resume': {
                if (!queue.paused) {
                    return interaction.reply({ content: '❌ Müzik zaten çalıyor!', flags: 64 });
                }

                queue.resume();
                await interaction.reply({ 
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#57F287')
                            .setDescription('▶️ Müzik devam ediyor!')
                    ]
                });
                break;
            }
        }
    }
};
