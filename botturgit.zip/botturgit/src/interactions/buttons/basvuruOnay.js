const { EmbedBuilder } = require('discord.js');
const ApplicationModel = require('../../models/Application');
const embedUtil = require('../../utils/embed');
const config = require('../../config/config.json');

module.exports = {
    customId: 'basvuru_onay',
    
    async execute(interaction, client) {
        await interaction.deferReply({ flags: 64 });

        // Başvuru ID'sini mesajdan al
        const appId = parseInt(interaction.message.embeds[0]?.footer?.text?.match(/ID: (\d+)/)?.[1]);
        
        if (!appId) {
            return interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Başvuru ID\'si bulunamadı!')]
            });
        }

        const application = ApplicationModel.get(appId);
        
        if (!application) {
            return interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Başvuru bulunamadı!')]
            });
        }

        if (application.status !== 'pending') {
            return interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Bu başvuru zaten işlenmiş!')]
            });
        }

        // Başvuruyu onayla
        ApplicationModel.approve(appId, interaction.user.id);

        // Mesajı güncelle
        const embed = EmbedBuilder.from(interaction.message.embeds[0])
            .setColor('#57F287')
            .setTitle('✅ Başvuru Onaylandı');
        
        await interaction.message.edit({ embeds: [embed], components: [] });

        // Kullanıcıya DM gönder
        try {
            const user = await client.users.fetch(application.userId);
            await user.send({
                embeds: [embedUtil.success('Başvurunuz Onaylandı! 🎉', 
                    `Tebrikler! **${interaction.guild.name}** sunucusundaki yetkili başvurunuz onaylandı.\n\n` +
                    `Ekibimize hoş geldin! Seninle iletişime geçeceğiz.`
                )]
            });
        } catch (e) {}

        await interaction.editReply({
            embeds: [embedUtil.success('Başarılı', 'Başvuru onaylandı ve kullanıcıya bildirildi!')]
        });
    }
};
