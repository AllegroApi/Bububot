const giveawaySystem = require('../../systems/giveawaySystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'giveaway_join',
    
    async execute(interaction, client) {
        const result = await giveawaySystem.join(
            interaction.message.id, 
            interaction.user.id,
            interaction.member
        );

        await interaction.reply({
            embeds: [result.success 
                ? embedUtil.success('Katıldın!', result.message)
                : embedUtil.error('Hata', result.message)
            ],
            ephemeral: true
        });
    }
};
