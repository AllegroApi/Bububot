const ticketSystem = require('../../systems/ticketSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'ticket_close',
    
    async execute(interaction, client) {
        const result = await ticketSystem.close(interaction.channel.id, interaction.user, client);
        
        if (!result.success) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', result.message)],
                ephemeral: true
            });
        }

        await interaction.reply({
            embeds: [embedUtil.success('Ticket Kapatılıyor', 'Bu kanal 5 saniye içinde silinecek...')]
        });
    }
};
