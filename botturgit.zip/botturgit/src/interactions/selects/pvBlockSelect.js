const PrivateVoiceModel = require('../../models/PrivateVoice');
const privateVoiceSystem = require('../../systems/privateVoiceSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_block_select',
    
    async execute(interaction, client) {
        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        const selectedUsers = interaction.values;
        
        for (const userId of selectedUsers) {
            if (userId === interaction.user.id) continue; // Kendini engellemesin
            await privateVoiceSystem.blockUser(room.channelId, userId, client);
        }

        const userMentions = selectedUsers.filter(id => id !== interaction.user.id).map(id => `<@${id}>`).join(', ');

        await interaction.update({
            content: null,
            embeds: [embedUtil.success('Engellendi', `${userMentions} artık odanıza giremez.`)],
            components: []
        });
    }
};
