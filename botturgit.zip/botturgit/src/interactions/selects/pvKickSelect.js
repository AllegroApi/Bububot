const PrivateVoiceModel = require('../../models/PrivateVoice');
const privateVoiceSystem = require('../../systems/privateVoiceSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_kick_select',
    
    async execute(interaction, client) {
        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        const selectedUsers = interaction.values;
        
        for (const userId of selectedUsers) {
            if (userId === interaction.user.id) continue;
            await privateVoiceSystem.kickUser(room.channelId, userId, client);
        }

        const userMentions = selectedUsers.filter(id => id !== interaction.user.id).map(id => `<@${id}>`).join(', ');

        await interaction.update({
            content: null,
            embeds: [embedUtil.success('Atıldı', `${userMentions} odadan atıldı.`)],
            components: []
        });
    }
};
