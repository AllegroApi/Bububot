const PrivateVoiceModel = require('../../models/PrivateVoice');
const privateVoiceSystem = require('../../systems/privateVoiceSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_transfer_select',
    
    async execute(interaction, client) {
        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        const newOwnerId = interaction.values[0];
        
        if (newOwnerId === interaction.user.id) {
            return interaction.update({
                content: null,
                embeds: [embedUtil.error('Hata', 'Kendinize devredemezsiniz!')],
                components: []
            });
        }

        await privateVoiceSystem.transferOwnership(room.channelId, newOwnerId, client);

        await interaction.update({
            content: null,
            embeds: [embedUtil.success('Sahiplik Devredildi', `Oda sahipliği <@${newOwnerId}> kullanıcısına devredildi.`)],
            components: []
        });
    }
};
