const PrivateVoiceModel = require('../../models/PrivateVoice');
const privateVoiceSystem = require('../../systems/privateVoiceSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_allow_select',
    
    async execute(interaction, client) {
        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        const selectedUsers = interaction.values;
        
        for (const userId of selectedUsers) {
            await privateVoiceSystem.allowUser(room.channelId, userId, client);
        }

        const userMentions = selectedUsers.map(id => `<@${id}>`).join(', ');

        await interaction.update({
            content: null,
            embeds: [embedUtil.success('İzin Verildi', `${userMentions} artık odanıza girebilir.`)],
            components: []
        });
    }
};
