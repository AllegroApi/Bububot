const PrivateVoiceModel = require('../../models/PrivateVoice');
const privateVoiceSystem = require('../../systems/privateVoiceSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_limit_modal',
    
    async execute(interaction, client) {
        const limitStr = interaction.fields.getTextInputValue('limit_value');
        const limit = parseInt(limitStr);

        if (isNaN(limit) || limit < 0 || limit > 99) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', '0-99 arası bir sayı girmelisiniz!')],
                ephemeral: true
            });
        }

        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        await privateVoiceSystem.setLimit(room.channelId, limit, client);

        await interaction.reply({
            embeds: [embedUtil.success('Limit Güncellendi', 
                limit === 0 
                    ? 'Kullanıcı limiti kaldırıldı.'
                    : `Kullanıcı limiti **${limit}** olarak ayarlandı.`
            )],
            ephemeral: true
        });
    }
};
