const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ApplicationModel = require('../../models/Application');
const embedUtil = require('../../utils/embed');
const config = require('../../config/config.json');

module.exports = {
    customId: 'basvuru_form',
    
    async execute(interaction, client) {
        await interaction.deferReply({ flags: 64 });

        const yas = interaction.fields.getTextInputValue('yas');
        const deneyim = interaction.fields.getTextInputValue('deneyim');
        const neden = interaction.fields.getTextInputValue('neden');
        const aktiflik = interaction.fields.getTextInputValue('aktiflik');
        const ek = interaction.fields.getTextInputValue('ek') || 'Belirtilmedi';

        // Yaş kontrolü
        const yasNum = parseInt(yas);
        if (isNaN(yasNum) || yasNum < 13 || yasNum > 99) {
            return interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Geçerli bir yaş giriniz (13-99)!')]
            });
        }

        // Başvuru oluştur
        const application = ApplicationModel.create({
            userId: interaction.user.id,
            userTag: interaction.user.tag,
            guildId: interaction.guild.id,
            answers: {
                yas,
                deneyim,
                neden,
                aktiflik,
                ek
            }
        });

        // İnceleme kanalına gönder
        const reviewChannelId = config.staffApplication?.reviewChannelId;
        const reviewChannel = reviewChannelId ? client.channels.cache.get(reviewChannelId) : null;

        if (reviewChannel) {
            const embed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle('📝 Yeni Yetkili Başvurusu')
                .setAuthor({ 
                    name: interaction.user.tag, 
                    iconURL: interaction.user.displayAvatarURL({ dynamic: true }) 
                })
                .addFields(
                    { name: '👤 Kullanıcı', value: `${interaction.user} (${interaction.user.id})`, inline: true },
                    { name: '📅 Hesap Oluşturma', value: `<t:${Math.floor(interaction.user.createdTimestamp / 1000)}:R>`, inline: true },
                    { name: '📅 Sunucuya Katılma', value: `<t:${Math.floor(interaction.member.joinedTimestamp / 1000)}:R>`, inline: true },
                    { name: '🎂 Yaş', value: yas, inline: true },
                    { name: '⏰ Aktiflik', value: aktiflik, inline: true },
                    { name: '\u200b', value: '\u200b', inline: true },
                    { name: '📚 Deneyim', value: deneyim.substring(0, 1024), inline: false },
                    { name: '❓ Neden Yetkili Olmak İstiyor', value: neden.substring(0, 1024), inline: false },
                    { name: '📝 Ek Bilgi', value: ek.substring(0, 1024), inline: false }
                )
                .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true, size: 256 }))
                .setFooter({ text: `Başvuru ID: ${application.id}` })
                .setTimestamp();

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('basvuru_onay')
                        .setLabel('Onayla')
                        .setEmoji('✅')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('basvuru_red')
                        .setLabel('Reddet')
                        .setEmoji('❌')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('basvuru_beklet')
                        .setLabel('Beklet')
                        .setEmoji('⏳')
                        .setStyle(ButtonStyle.Secondary)
                );

            await reviewChannel.send({ embeds: [embed], components: [row] });
        }

        await interaction.editReply({
            embeds: [embedUtil.success('Başvuru Gönderildi! ✅', 
                `Başvurunuz başarıyla alındı.\n\n` +
                `**Başvuru No:** #${application.id}\n\n` +
                `İncelendikten sonra size DM üzerinden bilgi verilecektir.`
            )]
        });
    }
};
