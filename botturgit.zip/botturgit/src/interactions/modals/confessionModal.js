const confessionSystem = require('../../systems/confessionSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'confession_modal',
    
    async execute(interaction, client) {
        const content = interaction.fields.getTextInputValue('confession_content');

        const result = await confessionSystem.create(
            interaction.user.id,
            interaction.user.tag,
            interaction.guild.id,
            content,
            client
        );

        if (!result.success) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', result.message)],
                ephemeral: true
            });
        }

        await interaction.reply({
            embeds: [embedUtil.success('İtiraf Gönderildi', 
                `İtirafın **#${result.confession.id}** numarasıyla gönderildi!\n\nKimliğin tamamen gizli kalacak. 🤫`
            )],
            ephemeral: true
        });
    }
};
