const PrivateVoiceModel = require('../../models/PrivateVoice');
const privateVoiceSystem = require('../../systems/privateVoiceSystem');
const embedUtil = require('../../utils/embed');

module.exports = {
    customId: 'pv_rename_modal',
    
    async execute(interaction, client) {
        const newName = interaction.fields.getTextInputValue('room_name');

        const room = PrivateVoiceModel.getByOwner(interaction.user.id, interaction.guild.id);
        
        if (!room) {
            return interaction.reply({
                embeds: [embedUtil.error('Hata', 'Aktif bir özel odanız yok!')],
                ephemeral: true
            });
        }

        await privateVoiceSystem.renameRoom(room.channelId, `🔊 ${newName}`, client);

        await interaction.reply({
            embeds: [embedUtil.success('İsim Güncellendi', `Oda ismi **${newName}** olarak değiştirildi.`)],
            ephemeral: true
        });
    }
};
