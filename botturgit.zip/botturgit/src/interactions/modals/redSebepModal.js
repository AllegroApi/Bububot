const { EmbedBuilder } = require('discord.js');
const ApplicationModel = require('../../models/Application');
const embedUtil = require('../../utils/embed');

module.exports = {
    // Bu modal dinamik ID kullanıyor: basvuru_red_sebep_${appId}
    // interactionCreate'de özel kontrol gerekiyor
    customId: 'basvuru_red_sebep',
    
    async execute(interaction, client, appId) {
        await interaction.deferReply({ flags: 64 });

        const sebep = interaction.fields.getTextInputValue('sebep');

        const application = ApplicationModel.get(appId);
        
        if (!application) {
            return interaction.editReply({
                embeds: [embedUtil.error('Hata', 'Başvuru bulunamadı!')]
            });
        }

        // Başvuruyu reddet
        ApplicationModel.reject(appId, interaction.user.id, sebep);

        // Orijinal mesajı güncelle
        try {
            const embed = EmbedBuilder.from(interaction.message.embeds[0])
                .setColor('#ED4245')
                .setTitle('❌ Başvuru Reddedildi')
                .addFields({ name: '📝 Red Sebebi', value: sebep });
            
            await interaction.message.edit({ embeds: [embed], components: [] });
        } catch (e) {}

        // Kullanıcıya DM gönder
        try {
            const user = await client.users.fetch(application.userId);
            await user.send({
                embeds: [embedUtil.error('Başvurunuz Reddedildi 😔', 
                    `**${interaction.guild.name}** sunucusundaki yetkili başvurunuz maalesef reddedildi.\n\n` +
                    `**Sebep:** ${sebep}\n\n` +
                    `Daha sonra tekrar başvurabilirsiniz.`
                )]
            });
        } catch (e) {}

        await interaction.editReply({
            embeds: [embedUtil.success('Başarılı', 'Başvuru reddedildi ve kullanıcıya bildirildi!')]
        });
    }
};
